import fs from "node:fs";
import path from "node:path";
import {
  Document,Packer,Paragraph,TextRun,HeadingLevel,Table,TableRow,TableCell,
  WidthType,Header,Footer,AlignmentType,PageNumber,ImageRun,BorderStyle,
  ExternalHyperlink,FootnoteReferenceRun,TableOfContents,LevelFormat,PageBreak
} from "docx";
import sharp from "sharp";

const root=path.dirname(new URL(import.meta.url).pathname);
const out=path.join(root,"output");
const base="OMNICELLULAR-Independent-Eight-Architecture-Execution-v1.0";
const markdown=fs.readFileSync(path.join(out,base+".md"),"utf8");
const footnotes={};
let note=0;
function inline(text,options={}){
  const runs=[];
  const re=/(\*\*[^*]+\*\*|\[[^\]]+\]\(https?:\/\/[^)]+\))/g;
  let last=0,m;
  while((m=re.exec(text))){
    if(m.index>last)runs.push(new TextRun({text:text.slice(last,m.index),...options}));
    if(m[0].startsWith("**")){
      runs.push(new TextRun({text:m[0].slice(2,-2),bold:true,...options}));
    }else{
      const [,name,url]=m[0].match(/^\[([^\]]+)\]\((.+)\)$/);
      const n=++note;
      runs.push(new TextRun({text:name,...options}),new FootnoteReferenceRun(n));
      footnotes[n]={children:[new Paragraph({style:"FootnoteText",children:[
        new TextRun({text:name+": ",size:18}),
        new ExternalHyperlink({link:url,children:[new TextRun({text:url,color:"01696F",size:18})]})
      ]})]};
    }
    last=re.lastIndex;
  }
  if(last<text.length)runs.push(new TextRun({text:text.slice(last),...options}));
  return runs.length?runs:[new TextRun("")];
}
const rows=markdown.split(/\r?\n/);
const children=[
  new Paragraph({spacing:{before:1100,after:300},children:[new TextRun({text:"OMNICELLULAR",bold:true,size:48,color:"01696F"})]}),
  new Paragraph({spacing:{after:180},children:[new TextRun({text:"PHYSIOLOGY",bold:true,size:40})]}),
  new Paragraph({spacing:{after:420},children:[new TextRun({text:"Independent Eight-Architecture\nResearch Execution",size:30})]}),
  new Paragraph({children:[new TextRun({text:"Version 1.0  |  October 29, 2026",bold:true,size:24})]}),
  new Paragraph({children:[new TextRun("Prepared for Nathan Lewis II\nArchitect, Omniversal Architect Labs")]}),
  new Paragraph({children:[new TextRun("Prepared by Perplexity Computer\nModel: GPT 6.1 Sol  |  Platform: Perplexity")]}),
  new Paragraph({spacing:{before:380},children:[new TextRun({text:"OAL-PPLX-OMNI-EXEC-001",size:20,color:"5A625F"})]}),
  new Paragraph({spacing:{before:380},children:[new TextRun({text:"Eight peer Generation 1 concepts. Literature-supported research, explicit finite limits, reproducible analytical calculations and preserved failures. Not constructed hardware, deployment certification or proof of immortality.",size:23})]}),
  new Paragraph({children:[new PageBreak()]}),
  new Paragraph({heading:HeadingLevel.HEADING_1,children:[new TextRun("Contents")]}),
  new TableOfContents("Research report and visual appendix",{hyperlink:true,headingStyleRange:"1-1"}),
  new Paragraph({children:[new PageBreak()]})
];
let appendix=false;
for(let i=2;i<rows.length;){
  const line=rows[i].trim();
  if(!line){i++;continue;}
  const head=line.match(/^(#{1,4}) (.+)$/);
  if(head){
    const level=head[1].length;
    if(head[2]==="Visual appendix")appendix=true;
    const heading=level<=2?HeadingLevel.HEADING_1:level===3?HeadingLevel.HEADING_2:HeadingLevel.HEADING_3;
    const pageBreak=/^P[1-8] .+: Generation 1$/.test(head[2])||head[2]==="Visual appendix";
    children.push(new Paragraph({heading,pageBreakBefore:pageBreak,keepNext:true,children:inline(head[2])}));
    i++;continue;
  }
  const img=line.match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
  if(img){
    const file=path.join(out,img[2]);
    const meta=await sharp(file).metadata();
    const width=650;
    const height=width*meta.height/meta.width;
    children.push(new Paragraph({alignment:AlignmentType.CENTER,spacing:{before:100,after:140},
      children:[new ImageRun({type:"png",data:fs.readFileSync(file),transformation:{width,height},altText:{title:img[1],description:img[1],name:img[1]}})]}));
    i++;continue;
  }
  if(line.startsWith("|")){
    const lines=[];
    while(i<rows.length&&rows[i].trim().startsWith("|"))lines.push(rows[i++].trim());
    const cells=lines.filter(x=>!x.match(/^\|[ :|-]+\|$/)).map(x=>x.slice(1,-1).split("|").map(y=>y.trim()));
    const cols=cells[0].length;
    const widths=cols===2?[2400,7680]:cols===3?[1500,3900,4680]:cols===4?[1500,2800,2600,3180]:Array(cols).fill(Math.floor(10080/cols));
    children.push(new Table({
      width:{size:100, type:WidthType.PERCENTAGE},
      columnWidths:widths,
      rows:cells.map((row,r)=>new TableRow({tableHeader:r===0,cantSplit:true,
        children:row.map((s,c)=>new TableCell({width:{size:widths[c],type:WidthType.DXA},
          margins:{top:70,bottom:70,left:90,right:90},
          shading:r===0?{fill:"E7EFED"}:undefined,
          children:[new Paragraph({style:"TableText",keepNext:false,children:inline(s,{size:18,bold:r===0})})]
        }))
      })),
      borders:{
        top:{style:BorderStyle.SINGLE,size:4,color:"CCD3CF"},
        bottom:{style:BorderStyle.SINGLE,size:4,color:"CCD3CF"},
        left:{style:BorderStyle.NONE},right:{style:BorderStyle.NONE},
        insideHorizontal:{style:BorderStyle.SINGLE,size:2,color:"D9DFDB"},
        insideVertical:{style:BorderStyle.NONE}
      }
    }));
    children.push(new Paragraph({spacing:{after:50},children:[new TextRun("")]}));
    continue;
  }
  if(line.startsWith("- ")){
    children.push(new Paragraph({numbering:{reference:"bullets",level:0},children:inline(line.slice(2))}));
    i++;continue;
  }
  let paragraph=line;
  i++;
  while(i<rows.length&&rows[i].trim()&&!/^(#{1,4} |!\[|\||- )/.test(rows[i].trim())){
    paragraph+=" "+rows[i++].trim();
  }
  children.push(new Paragraph({children:inline(paragraph)}));
}

const doc=new Document({
  creator:"Perplexity Computer",lastModifiedBy:"Perplexity Computer",
  title:"OMNICELLULAR Physiology: Independent Eight-Architecture Research Execution",
  description:"Independent Generation 1 conceptual research, analytical limits and full record appendix. No physical qualification.",
  subject:"OAL-PPLX-OMNI-EXEC-001 v1.0",
  features:{updateFields:true},
  footnotes,
  styles:{
    default:{document:{run:{font:"Arial",size:23,color:"202623"},paragraph:{spacing:{after:130,line:300},widowControl:true}}},
    paragraphStyles:[
      {id:"Normal",name:"Normal",run:{font:"Arial",size:23},paragraph:{spacing:{after:130,line:300},widowControl:true}},
      {id:"Heading1",name:"Heading 1",basedOn:"Normal",next:"Normal",quickFormat:true,
        run:{font:"Arial",size:32,bold:true,color:"202623"},paragraph:{outlineLevel:0,spacing:{before:340,after:160},keepNext:true}},
      {id:"Heading2",name:"Heading 2",basedOn:"Normal",next:"Normal",quickFormat:true,
        run:{font:"Arial",size:27,bold:true},paragraph:{outlineLevel:1,spacing:{before:250,after:120},keepNext:true}},
      {id:"Heading3",name:"Heading 3",basedOn:"Normal",next:"Normal",quickFormat:true,
        run:{font:"Arial",size:24,bold:true},paragraph:{outlineLevel:2,spacing:{before:190,after:100},keepNext:true}},
      {id:"TableText",name:"Table Text",basedOn:"Normal",run:{size:18},paragraph:{spacing:{after:35,line:240},widowControl:true}},
      {id:"FootnoteText",name:"Footnote Text",basedOn:"Normal",run:{size:18},paragraph:{spacing:{after:20,line:220},widowControl:true}},
      {id:"TOC1",name:"TOC 1",basedOn:"Normal",run:{size:20},paragraph:{spacing:{after:45,line:255}}}
    ]
  },
  numbering:{config:[{reference:"bullets",levels:[{level:0,format:LevelFormat.BULLET,text:"\u2022",alignment:AlignmentType.LEFT,
    style:{paragraph:{indent:{left:300,hanging:180}}}}]}]},
  sections:[{
    properties:{page:{size:{width:12240,height:15840},margin:{top:1020,right:1080,bottom:1080,left:1080,header:420,footer:420}}},
    headers:{default:new Header({children:[new Paragraph({children:[new TextRun({text:"OMNICELLULAR  |  INDEPENDENT RESEARCH EXECUTION v1.0",size:17,color:"59635E"})]})]})},
    footers:{default:new Footer({children:[new Paragraph({alignment:AlignmentType.RIGHT,children:[
      new TextRun({text:"Perplexity Computer  |  ",size:17,color:"59635E"}),
      new TextRun({children:[PageNumber.CURRENT],size:17}),
      new TextRun({text:" / ",size:17}),
      new TextRun({children:[PageNumber.TOTAL_PAGES],size:17})
    ]})]})},
    children
  }]
});
fs.writeFileSync(path.join(out,base+".docx"),await Packer.toBuffer(doc));
console.log(JSON.stringify({docx:path.join(out,base+".docx"),footnotes:note,paragraphs:children.length,appendix},null,2));
