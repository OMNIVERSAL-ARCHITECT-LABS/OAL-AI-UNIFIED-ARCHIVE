#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

root=Path(__file__).resolve().parent
out=root/"output"
release=root/"release"
release.mkdir(exist_ok=True)
base="OMNICELLULAR-Independent-Eight-Architecture-Execution-v1.0"
for ext in ["pdf","docx","md"]:
    shutil.copyfile(out/(base+"."+ext),release/(base+"."+ext))
boot="OMNICELLULAR-AI-Collaboration-Bootstrap-v1.0.md"
shutil.copyfile(root/boot,release/boot)
files=[root/n for n in ["README.md","contract.md","prototypes.json","analyze.py","build_document.mjs",
                        "update_export.py","qa_document.py","package_release.py",
                        "report_opening.md","report_closing.md",boot]]
files += [p for p in out.rglob("*") if p.is_file()]
files += [root/"qa"/"qa_results.json"]
manifest=[]
for p in files:
    manifest.append({"path":str(p.relative_to(root)),"bytes":p.stat().st_size,
                     "sha256":hashlib.sha256(p.read_bytes()).hexdigest()})
(release/"release_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
zipname=release/"OMNICELLULAR-Execution-Reproducibility-Package-v1.0.zip"
with zipfile.ZipFile(zipname,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files: z.write(p,Path("OMNICELLULAR-Execution-v1.0")/p.relative_to(root))
    z.write(release/"release_manifest.json","OMNICELLULAR-Execution-v1.0/release_manifest.json")
with zipfile.ZipFile(zipname) as z:
    assert z.testzip() is None
print(json.dumps({"archive":str(zipname),"files":len(files)+1,"archive_bytes":zipname.stat().st_size,
                  "release_files":[p.name for p in release.iterdir()]},indent=2))
