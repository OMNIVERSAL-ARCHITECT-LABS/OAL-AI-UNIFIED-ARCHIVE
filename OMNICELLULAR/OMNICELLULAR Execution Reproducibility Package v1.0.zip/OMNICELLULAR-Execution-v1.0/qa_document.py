#!/usr/bin/env python3
"""Render every page, preserve full renders and contact sheets, inspect structure."""
from pathlib import Path
import json
import re
import zipfile
import xml.etree.ElementTree as ET
import pymupdf
from PIL import Image,ImageDraw

root=Path(__file__).resolve().parent
out=root/"output"
qa=root/"qa"
renders=qa/"pages"
renders.mkdir(exist_ok=True)
base="OMNICELLULAR-Independent-Eight-Architecture-Execution-v1.0"
pdf=pymupdf.open(out/(base+".pdf"))
text="\n".join(page.get_text() for page in pdf)
violations=[]
for j,page in enumerate(pdf):
    pix=page.get_pixmap(matrix=pymupdf.Matrix(1,1),alpha=False)
    pix.save(renders/f"page-{j+1:03d}.png")
    for block in page.get_text("dict")["blocks"]:
        if "lines" not in block: continue
        x0,y0,x1,y1=block["bbox"]
        if x0 < 25 or x1>587 or y0<15 or y1>780:
            violations.append({"page":j+1,"bbox":block["bbox"],"text":" ".join(s["text"] for l in block["lines"] for s in l["spans"])[:160]})

for start in range(0,len(pdf),16):
    sheet=Image.new("RGB",(4*320,4*440),"#d9ddda")
    draw=ImageDraw.Draw(sheet)
    for k in range(16):
        n=start+k
        if n>=len(pdf):break
        im=Image.open(renders/f"page-{n+1:03d}.png").convert("RGB")
        im.thumbnail((306,405))
        x=(k%4)*320+(320-im.width)//2
        y=(k//4)*440+25
        sheet.paste(im,(x,y))
        draw.text(((k%4)*320+12,(k//4)*440+6),f"Page {n+1}",fill="black")
    sheet.save(qa/f"contact-{start//16+1:02d}.jpg",quality=90)
with zipfile.ZipFile(out/(base+".docx")) as z:
    main=z.read("word/document.xml")
    foot=z.read("word/footnotes.xml")
    ET.fromstring(main);ET.fromstring(foot)
    ns={"w":"http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    tree=ET.fromstring(main)
    tables=len(tree.findall(".//w:tbl",ns))
    counts=json.loads((out/"counts.json").read_text())
    report={"pdf_pages":len(pdf),"rendered_pages":len(list(renders.glob("page-*.png"))),
      "pdf_author":pdf.metadata.get("author"),"pdf_title":pdf.metadata.get("title"),
      "pdf_external_links":sum(1 for page in pdf for l in page.get_links() if l.get("uri")),
      "native_tables":tables,"footnote_references":len(tree.findall(".//w:footnoteReference",ns)),
      "xml_well_formed":True,"out_of_page_text_blocks":violations,"replacement_characters":text.count("\ufffd"),
      "content_counts":counts,
      "native_headings":sum(x.get("{"+ns["w"]+"}val","").lower() in ["heading1","heading2","heading3"]
                            for x in tree.findall(".//w:pStyle",ns))}
    assert tables>=70
    assert report["footnote_references"]>=30
    assert report["pdf_external_links"]>=30
    assert pdf.metadata.get("author")=="Perplexity Computer"
    assert not violations
    assert not report["replacement_characters"]
    assert "Cairn" in pdf[1].get_text() or "Executive" in pdf[1].get_text(),"Contents not populated"
    for i in range(1,9):
        assert f"P{i}" in text
    assert all("Visual appendix" in text for _ in [1])
(qa/"qa_results.json").write_text(json.dumps(report,indent=2)+"\n")
(qa/"readback.txt").write_text(text)
print(json.dumps({k:v for k,v in report.items() if k not in ["content_counts","out_of_page_text_blocks"]},indent=2))
