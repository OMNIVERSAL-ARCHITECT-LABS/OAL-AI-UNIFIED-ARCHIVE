#!/usr/bin/env python3
"""Reproducible bounded analysis. No physical, biological or identity validation."""
import csv
import hashlib
import json
import math
from pathlib import Path
import textwrap

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "output"
FIG = OUT / "figures"
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)
P = json.loads((ROOT / "prototypes.json").read_text())
AXES = ["power source", "information substrate", "unit organization", "cognition",
        "resilience mechanism", "thermal path", "external link", "repair",
        "dominant failure", "security", "capture response", "renewal dependency"]
DOMAINS = ["ENV-T", "ENV-A", "ENV-R", "BIO", "MECH", "DEP", "ENE", "INFO", "ONT", "CIV"]
TIERS = ["Mild", "Moderate", "Severe", "Extinction-Class"]
SIGMA = 5.670374419e-8
C = 299792458.0

SOURCES = [
 ("E01","NHGRI genetics glossary","http://www.genome.gov/genetics-glossary","Hereditary vocabulary; not an alternative-genome design"),
 ("E02","MRC LMB XNA research","https://www2.mrc-lmb.cam.ac.uk/groups/ph1/xna.html","Limited XNA information experiments, not autonomous organisms"),
 ("E03","Telomeres review, Cell","https://pmc.ncbi.nlm.nih.gov/articles/PMC8081271/","Chromosome-end integrity and aging/cancer context, not immortality"),
 ("E04","DOE fuel cells","https://www.energy.gov/cmei/fuels/fuel-cells","Fuel, oxidant, electricity, water and heat; no assumed body efficiency"),
 ("E05","NASA thermal-control guidance","https://www.nasa.gov/wp-content/uploads/2026/05/7-soa-thermal-2026-final.pdf?emrc=6ae1e775de967","Thermal boundaries and finite storage/heat rejection"),
 ("E06","NASA DTN","https://www.nasa.gov/communicating-with-missions/delay-disruption-tolerant-networking/","Delay/disruption-tolerant store-and-forward, not guaranteed paths"),
 ("E07","NIST zero trust","https://csrc.nist.gov/pubs/sp/800/207/final","Digital authentication/authorization context, not molecular concealment"),
 ("E08","JCVI minimal-cell model","https://www.jcvi.org/media-center/scientists-develop-most-complete-whole-cell-computer-simulation-model-cell-date","Single minimized-cell model, not omnicellular body simulation"),
 ("E09","NASA high-temperature circuits","https://science.nasa.gov/science-research/science-enabling-technology/technology-highlights/integrated-circuits-to-enable-exploration-of-the-harshest-environments-in-solar-system/","Specific simple hot circuits, not dense AI cognition"),
 ("E10","Tardigrade dry-state proteins","https://pmc.ncbi.nlm.nih.gov/articles/PMC5987194/","Specific desiccation-protection evidence, not whole-body cognition or arbitrary revival"),
 ("E11","Autonomous self-healing review","https://pmc.ncbi.nlm.nih.gov/articles/PMC12370171/","Healing loops and integration limits, not universal repair"),
 ("E12","NASA radiation-effects compendium","https://ntrs.nasa.gov/citations/20140017803","Distinct electronics radiation failure modes, not a whole-body rating"),
 ("E13","FDA computational-model credibility","https://www.fda.gov/regulatory-information/search-fda-guidance-documents/assessing-credibility-computational-modeling-and-simulation-medical-device-submissions","Risk-informed first-principles-model context, not certification"),
 ("E14","NIST Stefan–Boltzmann constant","https://physics.nist.gov/cgi-bin/cuu/Value?sigma","Constant used in illustrative radiator calculation"),
 ("E15","NIST speed of light","https://physics.nist.gov/cgi-bin/cuu/Value?c","Vacuum propagation constant; no complete link budget")
]

def dump(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")

def csvwrite(name, rows):
    with (OUT / name).open("w", newline="") as f:
        fields=list(dict.fromkeys(k for row in rows for k in row))
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

def fmt(x):
    if x >= 10000: return f"{x:,.0f}"
    if x >= 100: return f"{x:.0f}"
    if x >= 10: return f"{x:.1f}"
    return f"{x:.2f}"

def table(headers, rows):
    clean = lambda s: str(s).replace("|", "/").replace("\n", " ")
    return "\n".join(["| " + " | ".join(map(clean, headers)) + " |",
                     "| " + " | ".join("---" for _ in headers) + " |"] +
                    ["| " + " | ".join(map(clean, row)) + " |" for row in rows]) + "\n"

results, sensitivity, convergence, verification = [], [], [], []
rules, claims, threats, captivity, capture_horizons = [], [], [], [], []
assumptions, weaknesses, compound, paths = [], [], [], []

SCENARIOS = [
 ("K1","Atmosphere/resource confinement","Argon, then loss of power, then restricted heat rejection; do not infer vacuum."),
 ("K2","Communication denial","All external links unavailable for the interval; local autonomy must not require a server."),
 ("K3","Sampling","A routine removed unit is characterized; no assumption that chemistry is unreadable."),
 ("K4","Blueprint-informed prolonged study","Construction data and sustained physical custody are assumed; secret design is not credited."),
 ("K5","Forged ally","A message claims trusted origin without current authorization; invalid proof must not gain control."),
 ("K6","Compromised insider","An authentic current component behaves harmfully; signatures alone cannot establish safety."),
 ("K7","Coercive maintenance/update","Needed service is conditional on an identity-changing update; refusal may reduce continued operation."),
 ("K8","Denied feedstock","Repair stock is inaccessible after damage; information alone cannot replace missing matter."),
 ("K9","Unauthorized reconstruction","Enough public construction data exists to build similar hardware; private-state copying is a separate question."),
 ("K10","Damage plus false recovery","Postdamage telemetry says all is well while a state or transport witness is wrong.")
]
COLLAPSES = [
 ("A1","Environment remains predictable","Compare observed boundary conditions to the admitted envelope.","Reduce tasks; no unmeasured environmental immunity."),
 ("A2","Compatible matter is accessible","Inventory compatible spares and non-substitutable parts.","Preserve intact state; regrowth is unavailable without matter."),
 ("A3","Heat sink remains usable","Compare heat generation and actual export, not fan status.","Only finite buffering and reduced power remain."),
 ("A4","Sensors remain reliable","Cross-check independent modalities and residuals.","Conservative degraded mode; correlated errors may remain undetected."),
 ("A5","Time and epochs remain consistent","Compare local monotonic history with received histories.","Local preservation authority survives; global freshness is unresolved."),
 ("A6","Authentication implies safe behavior","Check permitted behavior separately from identity proof.","Quarantine suspicious authority; valid signatures may persist."),
 ("A7","Private state remains readable","Compare dissimilar records and retained recovery evidence.","A successor may be reconstructed; original continuity is not proved."),
 ("A8","Repair restores original competence","Require postrepair tests under appropriate load.","Keep repaired region restricted; false negatives can strand recovery."),
 ("A9","Interfaces remain chemically/mechanically stable","Track drift, contact losses and material history.","Use surviving paths; common interface loss can end operation."),
 ("A10","Infrastructure returns in time","Compare reserves to a declared return horizon.","Local autonomy continues only within finite reserves.")
]
COMPOUNDS = [
 ("X1","Heat plus radiation","Heat export declines while radiation-sensitive control accumulates errors.","Thermal path plus state witnesses","Unknown; no coupled radiation model"),
 ("X2","Oxygen denial plus link loss","External oxygen and peer advice disappear together.","Local reactants and offline policy","P2 finite reactants; others retain only their own power constraints"),
 ("X3","Energy denial plus thermal concealment","No recharge and observation-limiting enclosure reduces heat export.","Finite E and thermal buffer","Finite bound; full operation eventually fails"),
 ("X4","Fragmentation plus malicious replacement","A separated part returns with authentic-looking but altered behavior.","State provenance and behavior checks","Unknown security implementation"),
 ("X5","Memory corruption plus network partition","State witnesses disagree while external corroboration is unavailable.","Local lineage and branch policy","Unknown; may require successor or branch labeling"),
 ("X6","Repair demand exceeds accessible mass","Damage needs twice the useful stock in the repair ledger.","Compatible material","Fail for full autonomous repair"),
 ("X7","Hot ambient plus false cool sensor","Local heat is underestimated by a drifting sensor.","Independent thermal witness","Unknown common-mode sensor credibility"),
 ("X8","Mechanical damage plus coolant/path loss","Structure and its thermal or transport route fail together.","Topology and local reserves","Unknown; lumped model cannot validate"),
 ("X9","Trusted update plus energy scarcity","An authentic update increases load when reserve is low.","Local consent and worst-case resource check","Unknown implementation; refuse or reduce work"),
 ("X10","Long blackout plus archive/part aging","Infrastructure does not return before storage or replacement stock drifts.","Time, retention and compatible spares","Finite survival; no indefinite archive guarantee")
]

def threat_spec(domain, tier):
    i = TIERS.index(tier)
    spec = {
      "ENV-T":([293,333,373,473][i],"K ambient","24 h,6 h,1 h,1 h".split(",")[i],
               "10 K/min ramp", "no external power; environment-specific heat export unresolved"),
      "ENV-A":(["100 kPa air","100 kPa argon","0.001 Pa vacuum","100 kPa argon"][i],"pressure/composition",
               ["24 h","1 h","1 h","30 days"][i],"10 s boundary change",
               "Extinction-Class additionally denies energy and heat export; Severe preserves unobstructed radiation only"),
      "ENV-R":([1,10,100,1000][i],"Gy absorbed target","1 h","uniform exposure assumed",
               "particle spectrum, dose distribution and rate response unqualified"),
      "BIO":(["benign contact reference","unidentified irritant/contaminant","interface-disrupting chemistry","unbounded incompatible chemistry"][i],
             "chemical class, no dose assigned","24 h","contact event","no agent design or exposure protocol; concentration and selectivity unknown"),
      "MECH":([0.1,1,10,100][i],"J/kg incident target","1 s","impulsive",
               "load geometry and energy transfer unresolved; Extinction-Class includes all-state destruction as a separate subcase"),
      "DEP":([1,7,30,365][i],"days no resupply",["24 h","7 days","30 days","365 days"][i],"immediate",
              "normal load for Mild/Moderate; essential for Severe; Extinction-Class denies heat export; no harvesting credited"),
      "ENE":([1,10,100,1000][i],"J/kg external energy target","1 s","impulsive",
              "electrical/EM/plasma mechanism not interchangeable; coupling and waveform unknown"),
      "INFO":(["1% telemetry erasure","24 h external-link loss","one authentic controller compromised","all private and recovery state irreversibly erased"][i],
               "information challenge",["24 h","24 h","24 h","permanent"][i],"abrupt","local authorization remains required; complete erasure has no backup exception"),
      "ONT":("undefined ontological nullification","no physical variable","undefined","undefined",
             "extension track only; a physical destructive mechanism must be recategorized"),
      "CIV":(["site gateway loss","30 days infrastructure loss","365 days no useful external input","all recoverable body/state physically destroyed"][i],
             "macro scenario",["24 h","30 days","365 days","permanent"][i],"abrupt",
             "no unbounded remote rescue; shared infrastructure treated as a dependency")
    }
    return spec[domain]

def threat_result(p, domain, tier, r):
    i = TIERS.index(tier)
    if domain == "ONT":
        return "Not physically evaluable","Unresolved","Unresolved","No operational physical mechanism or validation criterion."
    if domain == "INFO" and i == 3:
        return "Fail","Lost","Lost","All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario."
    if domain == "CIV" and i == 3:
        return "Fail","Lost","Lost","No physically recoverable substrate or state remains."
    if domain == "MECH" and i == 3:
        return "Partial","Unresolved","Unresolved","Incident-energy case is unknown; the separately specified all-state-destruction subcase fails."
    if domain == "ENV-A" and i == 3:
        h = r["combined_dormant_h"]
        return ("Fail" if h < 720 else "Partial","Dormant/Preservation","Unresolved",
                f"Modeled preservation bound {fmt(h)} h; 720 h required, autonomous return and leakage remain unvalidated.")
    if domain == "DEP":
        need = [24,168,720,8760][i]
        bound = r["energy_normal_h"] if i < 2 else r["energy_essential_h"]
        if i == 3: bound = r["combined_dormant_h"]
        if p["id"] == "P2": bound = min(bound,r["reactant_h"])
        return ("Fail" if bound < need else "Partial",
                "Reduced/Minimal" if i < 3 else "Dormant/Preservation","Unresolved",
                f"Favorable model bound {fmt(bound)} h versus {need} h; recovery, leakage, aging and spatial constraints unresolved.")
    if domain == "CIV" and i in [1,2]:
        need = [0,720,8760,0][i]
        b = r["energy_normal_h"] if i == 1 else r["energy_essential_h"]
        if p["id"] == "P5":
            return "Unknown","Reduced/Minimal","Unresolved","Solar input may exist but macro-event illumination, dust and infrastructure are unspecified."
        return ("Fail" if b < need else "Partial","Minimal/Preservation","Unresolved",
                f"No-harvest energy bound {fmt(b)} h versus {need} h; archive persistence alone is not full autonomous recovery.")
    if domain == "ENV-T" and p["id"] in ["P2","P3"] and i == 3:
        return "Fail","Lost/Unresolved","Unresolved","Prolonged 473 K ambient exceeds the selected aqueous chemistry envelope; no qualified insulation/recovery model exists."
    return "Unknown","Unresolved","Unresolved","No integrated validation for this exact amplitude, duration, rate and recovery requirement."

for p in P:
    eta = p.get("fuelconversion",1.0)
    cap = p["capacity"] * 1000
    buffer = cap*p["margin"]
    def eh(load):
        if p["id"]=="P2":
            mode=next(mode for mode in ["normal","essential","dormant"] if p[mode]==load)
            living=p["living"+mode+"W"]
            return min(p["chemicalreserveWh"]/living,p["electricalreserveWh"]/(load-living))
        return p["reserve"]*eta/load
    def hh(load): return buffer/(load/eta)/3600
    r = {
      "prototype":p["id"],"name":p["name"],"reserve_input_Wh":p["reserve"],"electrical_fraction":eta,
      "normal_W":p["normal"],"essential_W":p["essential"],"preservation_W":p["dormant"],
      "heat_capacity_J_per_K":cap,"allowed_rise_K":p["margin"],"thermal_buffer_J":buffer,
      "energy_normal_h":eh(p["normal"]),"energy_essential_h":eh(p["essential"]),"energy_dormant_h":eh(p["dormant"]),
      "adiabatic_normal_h":hh(p["normal"]),"adiabatic_essential_h":hh(p["essential"]),"adiabatic_dormant_h":hh(p["dormant"]),
      "combined_normal_h":min(eh(p["normal"]),hh(p["normal"])),
      "combined_essential_h":min(eh(p["essential"]),hh(p["essential"])),
      "combined_dormant_h":min(eh(p["dormant"]),hh(p["dormant"])),
      "useful_spares_kg":p["spares"]*p["yield"],
      "repair_100g_count_bound":math.floor(p["spares"]*p["yield"]/0.1+1e-9),
      "status":"Derived from unvalidated targets; favorable upper bounds, not runtimes"
    }
    if p["id"] == "P2":
        r["oxygen_h"] = p["oxygenkg"]/p["oxygenkgph"]
        r["co2_h"] = p["co2capacitykg"]/p["co2kgph"]
        r["reactant_h"] = min(r["oxygen_h"],r["co2_h"])
    if p["id"] == "P5":
        r["solar_instant_W"] = p["solararea"]*p["irradiance"]*p["solareff"]
        r["solar_mean_W"] = r["solar_instant_W"]*p["solarduty"]
        r["solar_net_before_storage_W"] = r["solar_mean_W"]-p["normal"]
    assert sum(p["powerbreak"]) == p["normal"]
    assert p["heat"] == p["normal"]/eta
    assert p["obsbudget"]+p["authbudget"] <= p["powerbreak"][2]+p["powerbreak"][4]
    results.append(r)
    for mode in ["normal","essential","dormant"]:
        load=p[mode]
        for ef in [0.5,1,1.5]:
            for cf in [0.5,1,1.5]:
                for pf in [0.5,1,2]:
                    te=eh(load)*ef/pf
                    th=buffer*cf/(load*pf/eta)/3600
                    sensitivity.append({"prototype":p["id"],"mode":mode,"energy_multiplier":ef,"capacity_multiplier":cf,
                                        "load_multiplier":pf,"combined_no_export_h":min(te,th)})
    # Executed zero-dimensional ODE checks: no-event integration, constant load.
    stop=min(3600,r["combined_normal_h"]*3600/2)
    for requested_dt in [10,1,0.1]:
        n=max(1,math.ceil(stop/requested_dt))
        dt=stop/n
        E=p["reserve"]*3600.0
        T=0.0
        for _ in range(n):
            E-=p["normal"]/eta*dt
            T+=p["normal"]/eta/cap*dt
        exactE=p["reserve"]*3600-p["normal"]/eta*stop
        exactT=p["normal"]/eta/cap*stop
        residual=abs((p["reserve"]*3600-E)-cap*T)
        convergence.append({"prototype":p["id"],"dt_s":requested_dt,"steps":n,"duration_s":stop,
                            "energy_error_J":abs(E-exactE),"temperature_error_K":abs(T-exactT),
                            "energy_conservation_residual_J":residual})
        assert abs(E-exactE) < 0.02
        assert abs(T-exactT)<1e-6
    # Finite conductance example. Constant ambient = initial core, loss K*deltaT.
    lossK=p["cooling"]
    for k in [0,lossK/2,lossK]:
        q=p["normal"]/eta
        if k==0:
            th=buffer/q/3600
        elif q/k<=p["margin"]:
            th=None
        else:
            th=-(cap/k)*math.log(1-p["margin"]*k/q)/3600
        verification.append({"prototype":p["id"],"conductance_W_per_K":k,
                             "steady_rise_K":q/k if k else None,
                             "thermal_limit_h":th,
                             "meaning":"None means no threshold crossing in this ideal constant-ambient thermal model, not indefinite survival"})

    # Rule contract preserves all fields rather than an untraceable count.
    for family,key in [("RESP","respiration"),("LONG","renewal"),("THERM","thermal"),("CONV","conversion")]:
        for j, clause in enumerate(p[key],1):
            rules.append({"id":f"{p['id']}-{family}-{j}","prototype":p["id"],"family":family,
              "mechanism":clause.split(": ",1)[-1],"inputs":p["energy"] if family=="RESP" else p["transport"] if family=="THERM" else p["substrate"] if family=="LONG" else p["repair"],
              "outputs":"bounded admitted state transition and ledger entry","units":"W, Wh, J, K, kg, s; informational state is categorical",
              "trigger":"load, damage, repair, environmental or admitted mode change",
              "latency_target_s":10,"resource_cost":"included in mode power; transient peak and material cost unresolved",
              "operating_envelope":p["envelopeextra"],"false_trigger":"sensor or model error unnecessarily restricts useful function",
              "failure":p["weaknesses"][(j-1)%len(p["weaknesses"])],"interactions":"power, thermal, repair, authorization and lineage state",
              "evidence_class":"Engineering extrapolation","validation":"Unvalidated integration",
              "falsifier":p["falsifier"]})
    for family,key in [("OBS","observations"),("SEC","security"),("DEP","departures")]:
        for j, fields in enumerate(p[key],1):
            if family=="DEP":
                title, mechanism, axis, evidence=fields
                trigger="admission of a candidate architecture"
                cost=p["sacrifice"]
                failure=p["collapse"]
                evidence_class="Speculative" if "peculat" in evidence else "Engineering extrapolation"
            elif family=="OBS":
                title,mechanism,trigger,cost,failure=fields
                evidence_class="Engineering extrapolation"
            else:
                title,mechanism,cost,failure=fields
                trigger="component enrollment, identity-state change, recovery or protected request"
                evidence_class="Engineering extrapolation"
            rules.append({"id":f"{p['id']}-{family}-{j}","prototype":p["id"],"family":family,"title":title,
              "mechanism":mechanism,"inputs":trigger,"outputs":"admitted/rejected action and attributed diagnostic record",
              "units":"W, s, bytes and categorical authorization state","trigger":trigger,
              "latency_target_s":1 if family!="DEP" else None,
              "resource_cost_W":p["obsbudget"]/3 if family=="OBS" else p["authbudget"]/3 if family=="SEC" else None,
              "other_cost":cost,"operating_envelope":p["envelopeextra"],"false_trigger":failure,
              "failure":failure,"interactions":"local consent, function, privacy and offline recovery",
              "evidence_class":evidence_class,"validation":"Unvalidated integration","falsifier":p["falsifier"]})

    claims.append({"id":f"{p['id']}-CL-1","prototype":p["id"],"requirements":"REQ-01,05–24",
      "mechanism":p["wager"],"evidence_class":"Speculative" if p["id"] in ["P3","P7","P8"] else "Engineering extrapolation",
      "authority":"Independent proposal; no canon authority","validation":"Unvalidated integration",
      "scale":p["body"],"source_ids":{"P1":["E05","E11","E12"],"P2":["E03","E11"],"P3":["E02"],
                                   "P4":["E04","E05"],"P5":["E05"],"P6":["E06","E07"],
                                   "P7":["E10"],"P8":["E09"]}[p["id"]],
      "uncertainty":p["evidence"],"dependency":p["collapse"],"falsifier":p["falsifier"],
      "safety":"Conceptual and nonliving validation only; no operational biological construction"})
    for dom in DOMAINS:
        for tier in TIERS:
            amp,units,dur,onset,resources=threat_spec(dom,tier)
            status,state,identity,reason=threat_result(p,dom,tier,r)
            threats.append({"id":f"{p['id']}-{dom}-{TIERS.index(tier)+1}","prototype":p["id"],"domain":dom,"tier":tier,
             "magnitude":amp,"units":units,"duration":dur,"onset":onset,"resource_boundary":resources,
             "required_outcome":"full for Mild; near-full autonomous recovery for Moderate; survival and autonomous recovery for Severe; reported bound for Extinction-Class",
             "status":status,"function_state":state,"identity":identity,"autonomy":"Unresolved; not inferred from stored bytes",
             "recovery":"Not demonstrated; no external rescue assumed unless explicitly admitted",
             "uncertainty":reason,"benchmark":"B1"})
    for k,title,scenario in SCENARIOS:
        outcome={
          "K1":f"Full-load heat/export-denied upper bound {fmt(r['combined_normal_h'])} h; preservation bound {fmt(r['combined_dormant_h'])} h, before chemistry or aging.",
          "K2":"Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery.",
          "K3":p["gauntletnote"],
          "K4":p["capture"],
          "K5":"Intended rejection without current authorization; proof implementation and adversarial parsing are untested.",
          "K6":f"Behavior checks target an authentic harmful module; shared weakness remains: {p['weaknesses'][0].lower()}.",
          "K7":"Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee.",
          "K8":f"Useful target repair matter {fmt(r['useful_spares_kg'])} kg only; twice this demand fails full repair.",
          "K9":"Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim.",
          "K10":f"Cross-witness recovery is required; {p['collapse']}"
        }[k]
        captivity.append({"id":f"{p['id']}-{k}","prototype":p["id"],"scenario":title,"conditions":scenario,
                          "result":"Partial analytical bound" if k in ["K1","K8"] else "Unknown integrated security/survival",
                          "outcome":outcome,"privacy":"sample secrecy not guaranteed","identity":"continuity or restoration assessed separately",
                          "nonviolent_response":"local refusal, reduced function, isolation and bounded records",
                          "recovery":"requires remaining qualified hardware, usable state and resources"})
    for seconds,label in [(60,"1 minute"),(3600,"1 hour"),(86400,"1 day"),(2592000,"1 month"),(31536000,"1 year")]:
        dose=p["normal"]/eta*seconds/3600
        if seconds < r["combined_normal_h"]*3600:
            state="Lumped energy/heat bound not yet exhausted; integrated state unknown"
        elif seconds < r["combined_dormant_h"]*3600:
            state="Normal active state infeasible in bound; preservation potentially within bound only"
        else: state="Even selected preservation bound exhausted under zero heat export"
        capture_horizons.append({"id":f"{p['id']}-H-{seconds}","prototype":p["id"],"horizon":label,"seconds":seconds,
          "normal_input_energy_Wh":dose,"bounded_state":state,
          "disclosure":"Composition, geometry and emitted behavior can be observed; how much private state is extracted is unknown",
          "risk":"Increasing opportunity for study, not a calibrated probability or measured extraction time",
          "assumption":"No resupply; no heat export; no external heating; low-power transition itself not validated"})
    for j,(aid,assume,detect,survive) in enumerate(COLLAPSES):
        symptoms=[
          "Measured boundary conditions leave the admitted mission envelope.",
          f"Repair demand exceeds the useful {fmt(r['useful_spares_kg'])} kg stock or needs a missing specialized part.",
          "Core temperature rises despite a cooling command because actual heat export is inadequate.",
          "Independent channels disagree or plausible but correlated sensor errors escape the witness.",
          "Local epoch histories conflict; message age and ordering cannot be established globally.",
          "A correctly authenticated component violates its admitted behavior or resource envelope.",
          "State readback is inconsistent, corrupted or no longer physically readable.",
          "Postrepair load or integrity checks do not reproduce the pre-damage competence.",
          "Contact, membrane, seal or transport behavior drifts outside its admitted model.",
          "External support remains unavailable beyond the declared finite reserve horizon."
        ]
        assumptions.append({"id":f"{p['id']}-{aid}","prototype":p["id"],"assumption":assume,
             "collapse_symptom":symptoms[j],"detection":detect,
             "what_survives":survive,"specific_dependency":p["collapse"],"result":"Unknown integration; finite-resource contradictions retained"})
        weaknesses.append({"id":f"{p['id']}-W{j+1}","prototype":p["id"],"rank":j+1,"weakness":p["weaknesses"][j],
          "severity":"Critical" if j<3 else "Major","rank_basis":"qualitative central-dependency and recovery difficulty, not probability",
          "evidence_gap":p["evidence"],"detectability":"sensor- and model-dependent; no measured rate",
          "mitigation":"local isolation, explicit reserve or qualified replacement where possible",
          "residual":"not independently tested"})
    for xid,title,conditions,first,outcome in COMPOUNDS:
        compound.append({"id":f"{p['id']}-{xid}","prototype":p["id"],"title":title,"conditions":conditions,
          "first_limiter":p["collapse"] if xid in ["X1","X8"] else first,
          "cascade":"loss of boundary condition -> control uncertainty -> useful-function reduction -> finite preservation or loss",
          "outcome":outcome,"survival_state":"Unresolved; no integrated pass",
          "recovery":p["repair"],"controlling_assumption":p["weaknesses"][int(xid[1:])-1]})
    for j,(kind,before,counter,repair,cost,retest) in enumerate([
        ("resource/thermal","The central wager is sufficient under confinement.",
         f"Removing usable heat export imposes {fmt(r['combined_normal_h'])} h normal bound; {p['collapse']}",
         "Make load and heat-sink requirements explicit; preserve finite staged reductions.",
         "Less useful function, extra thermal paths and reserve overhead.",
         "Analytical finite limit reproduced; physical integrated retest not performed."),
        ("security/identity","Correct construction or credentials ensure identity safety.",
         p["capture"],
         "Separate possession, recipe, authorization and private lineage; retain conscious branch rights.",
         "Recovery friction and possible permanent loss of access.",
         "Conceptual counterexample only; implementation security and subjective continuity unvalidated."),
        ("compound/common-mode","Redundant local units prevent a whole-body failure.",
         f"A common defect or coupled boundary failure remains: {p['weaknesses'][0]}; {p['weaknesses'][2]}.",
         p["gen2"],
         "Additional hardware/validation and new interfaces; mitigation may raise maintenance burden.",
         "Proposed revision, not successfully validated.")
    ],1):
        paths.append({"id":f"{p['id']}-FP{j}","prototype":p["id"],"kind":kind,"pre_review_claim":before,
                      "counterexample":counter,"outcome":"Successful conceptual limitation; not an empirical attack",
                      "post_review_revision":repair,"new_cost":cost,"retest":retest,"unresolved":p["falsifier"]})

# Pair comparison uses four mandatory mechanism axes and all twelve recorded axes.
normalized_power=["battery","nutrient+electrical","battery","fuel+oxidant","solar","battery","battery","thermal-gradient"]
normalized_info=["digital","DNA+digital","XNA+digital","digital","digital","coded-digital","DNA+digital","ROM-digital"]
normalized_thermal=["conductive-radiator","pumped-exchanger","pumped-exchanger","wetted-exchanger","surface-radiator","per-node-radiator","static-buffer","gradient-rejection"]
pairs=[]
for a in range(8):
    for b in range(a+1,8):
        av=P[a]["axes"][:]
        bv=P[b]["axes"][:]
        for j,vector in [(0,normalized_power),(1,normalized_info),(5,normalized_thermal)]:
            av[j],bv[j]=vector[a],vector[b]
        diffs=[AXES[j] for j in range(12) if av[j]!=bv[j]]
        assert len(diffs)>=4
        assert sum(k in diffs for k in ["power source","resilience mechanism","thermal path","repair","dominant failure"])>=2
        pairs.append({"pair":f"P{a+1}/P{b+1}","differences":len(diffs),
                      "required_named_differences":"; ".join(diffs[:4]),
                      "resource_failure_differences":"; ".join(k for k in diffs if k in ["power source","thermal path","repair","dominant failure"]),
                      "interpretation":"categorical design differences, not measured performance independence"})

comms=[]
for distance,label,medium,power,rate,infra in [
 (1,"local","wired/short optical","0.01–2 W target","1 kb/s–10 Mb/s target","compatible coupler"),
 (1e7,"planetary reference","RF or optical routed relay","1–50 W endpoint target","1 kb/s–1 Mb/s target","line of sight or relays; rate not link-budget validated"),
 (1.5e11,"interplanetary reference","directional RF/optical gateway","10–100 W gateway target","10 b/s–100 kb/s target","pointing, aperture, gateway and route schedule unspecified")
]:
    comms.append({"case":label,"assumed_distance_m":distance,"vacuum_one_way_s":distance/C,
                  "medium":medium,"power":power,"rate":rate,"infrastructure":infra,
                  "meaning":"ideal propagation lower bound; queueing, retries, scheduling and medium can add delay"})

# Optional useful bounds and verification counterexamples.
radiator={"assumed_emissivity":0.9,"assumed_area_m2":1,"assumed_temperature_K":300,
          "assumed_sink_K":3,"derived_W":0.9*SIGMA*(300**4-3**4),
          "note":"Ideal view factor one, no solar/planetary heat input; not a qualified body radiator"}
solar_next = next(x for x in results if x["prototype"]=="P5")
life_counts = {"empirical_component_tests":0,"integrated_tests":0,"survival_incidents":0,
               "canonical_events_added":0,"analytical_families":8,"ode_step_checks":len(convergence),
               "stress_grid_rows":len(sensitivity)}
counts={"prototypes":8,"core_rules":sum(r["family"] in ["RESP","LONG","THERM","CONV"] for r in rules),
        "observation_rules":sum(r["family"]=="OBS" for r in rules),
        "security_rules":sum(r["family"]=="SEC" for r in rules),
        "departures":sum(r["family"]=="DEP" for r in rules),"threat_cells":len(threats),
        "captivity":len(captivity),"horizons":len(capture_horizons),"assumptions":len(assumptions),
        "weaknesses":len(weaknesses),"compound":len(compound),"failure_paths":len(paths),"pairs":len(pairs)}
assert list(counts.values())==[8,128,24,24,24,320,80,40,80,80,80,24,28]
for p in P:
    for family,n in [("RESP",4),("LONG",4),("THERM",4),("CONV",4),("OBS",3),("SEC",3),("DEP",3)]:
        assert sum(x["prototype"]==p["id"] and x["family"]==family for x in rules)==n
dump("budget_results.json",results)
csvwrite("budget_results.csv",results[:1]) if False else None
csvwrite("budgets_plot_data.csv",[{k:r[k] for k in ["prototype","normal_W","essential_W","preservation_W","energy_normal_h","adiabatic_normal_h","combined_dormant_h"]} for r in results])
for name,obj in [("rules",rules),("claims",claims),("threats",threats),("captivity",captivity),
                 ("capture_horizons",capture_horizons),("assumption_collapses",assumptions),("weaknesses",weaknesses),
                 ("compound_scenarios",compound),("failure_paths",paths),("pairs",pairs),("communications",comms),
                 ("sensitivity",sensitivity),("convergence",convergence),("conductance_sensitivity",verification)]:
    dump(name+".json",obj)
    csvwrite(name+".csv",[{k:v for k,v in row.items() if not isinstance(v,(list,dict))} for row in obj])
dump("counts.json",counts)
dump("event_ledger.json",life_counts)
dump("source_register.json",[{"id":i,"name":n,"url":u,"scope":s} for i,n,u,s in SOURCES])
dump("auxiliary_bounds.json",{"radiator":radiator,"communications":comms})

# Narrative dossiers. No substantial tables outside the visual appendix.
dossiers=[]
for p,r in zip(P,results):
    s=[f"## {p['id']} {p['name']}: Generation 1",f"### Core wager and body",p["wager"]+" "+p["sacrifice"],p["body"],p["omni"],
       "### Matrix, transport and cognition",p["substrate"],p["transport"]+" "+p["cognition"],p["environment"],
       "### Physiological constitution",p["energy"]]
    for title,key,prefix in [("Respiration and power","respiration","RESP"),("Telomeres, copying and longevity","renewal","LONG"),
                             ("Thermal regulation","thermal","THERM"),("Conversion and conservation","conversion","CONV")]:
        s.append(f"#### {title}")
        for j,t in enumerate(p[key],1):
            s.append(f"- **{p['id']}-{prefix}-{j}:** {t.split(': ',1)[-1]}")
    s += [f"The proposed service-life target is {p['life']} years conditional on {p['maintenance']}. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.",
          "### Observation, hereditary security and departures"]
    for family,key in [("OBS","observations"),("SEC","security")]:
        for j,fields in enumerate(p[key],1):
            if family=="OBS":
                title,mechanism,trigger,cost,fail=fields
            else:
                title,mechanism,cost,fail=fields
                trigger="component admission, protected request or recovery"
            budget=(p["obsbudget"] if family=="OBS" else p["authbudget"])/3
            s.append(f"- **{p['id']}-{family}-{j}, {title}:** {mechanism} Trigger: {trigger}. Target cost {budget:.2f} W under the shared rule contract; other inputs: {cost}. False trigger or failure: {fail}. Evidence is unvalidated integration; no physical readout barrier is implied.")
    for j,(title,mechanism,axis,evidence) in enumerate(p["departures"],1):
        s.append(f"- **{p['id']}-DEP-{j}, {title}:** {mechanism} Departure affects dimension {axis}; support: {evidence}. This departs from a biological or engineering default, not a physical law.")
    s += ["The explicitly retained constraints are: "+ "; ".join(p["kept"])+".",
          "### Repair, identity and autonomy",p["repair"],p["identity"],
          "### Linking and capture",p["link"],p["capture"],p["gauntletnote"],
          "### Finite resources and environmental envelope",
          f"Targets: {p['reserve']:,} Wh input reserve, {p['normal']} W normal accounted load, {p['essential']} W essential load and {p['dormant']} W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition {p['powerbreak'][0]} W, actuation/transport {p['powerbreak'][1]} W, sensing {p['powerbreak'][2]} W, circulation/chemistry/housekeeping {p['powerbreak'][3]} W, communications/security {p['powerbreak'][4]} W and repair allowance {p['powerbreak'][5]} W. Peak power target {p['peak']} W is not a continuous capability.",
          f"Derived energy-only normal horizon: {fmt(r['energy_normal_h'])} h. With no heat export, no external heating, heat capacity {p['capacity']} kJ/K and allowed rise {p['margin']} K, the derived normal-load thermal limit is {fmt(r['adiabatic_normal_h'])} h; the combined favorable bound is {fmt(r['combined_normal_h'])} h. At the selected preservation draw the combined favorable bound is {fmt(r['combined_dormant_h'])} h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.",
          f"Home core target {p['home'][0]}–{p['home'][1]} K; finite-refuge target {p['refuge'][0]}–{p['refuge'][1]} K. Intended pressure target {p['pressure'][0]}–{p['pressure'][1]} MPa; finite-refuge pressure target {p['refugepressure'][0]}–{p['refugepressure'][1]} MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. {p['envelopeextra']}"]
    if p["id"]=="P2":
        s.append(f"Normal operation allocates 60 W to living chemical maintenance and 140 W to electrical loads. The separate 600 Wh nutrient and 3,000 Wh electrical reserves therefore give 10 h and 21.4 h normal bounds; the minimum is used rather than pooling their energy. Essential mode assigns 25 W living and 15 W electrical, while preservation assigns 4 W living and 1 W electrical. The selected 1 kg oxygen and 1 kg carbon-dioxide capture allowances, at assumed 0.04 and 0.05 kg/h use, give {fmt(r['oxygen_h'])} h and {fmt(r['co2_h'])} h respectively. The same conservative gas/waste rates are retained in lower modes pending measurement, so their bound is {fmt(r['reactant_h'])} h. These rates are targets, not biological measurements, and neither chemical nor electrical energy can substitute for the other.")
    if p["id"]=="P4":
        s.append("The 10,000 Wh fuel reserve is preconversion energy. At target electrical fraction 0.5 it yields 5,000 Wh to the bus and produces conversion heat in addition to electrical dissipation. At 300 W bus load the modeled total heat is 600 W. The separately proposed bridge battery has no credited capacity until independently specified.")
    if p["id"]=="P5":
        s.append(f"The selected 12 m² collector, 500 W/m² illumination, 0.2 conversion fraction and 0.25 illuminated duty yield {fmt(r['solar_instant_W'])} W instantaneous and {fmt(r['solar_mean_W'])} W mean electrical input. The mean surplus is {fmt(r['solar_net_before_storage_W'])} W before storage, cleaning, pointing and thermal penalties. In darkness it is zero; the 5% duty stress produces a deficit at the selected normal load.")
    if p["id"]=="P7":
        s.append("The long preservation number is especially fragile: the selected 0.01 W total draw excludes no required load by permission, but no implementation demonstrates it. Self-discharge, periodic sensing, archive readback and physical aging may dominate. It is not a consciousness-power estimate.")
    if p["id"]=="P8":
        s.append("The reserve and thermal numbers are conditional algebra because no complete high-temperature storage/compute assembly has been selected. They are not proof that a suitably rated battery exists. The richer service core retains a separate 273–323 K target window.")
    s += ["### Challenge outcome and research decision",
          f"The first central assumption to collapse is: {p['collapse']} Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.",
          f"Strongest reason to pursue: {p['wager']} Strongest reason to reject: {p['sacrifice']} Least-supported critical mechanism: {p['evidence']}",
          f"First likely failure under the selected dependency ranking: {p['weaknesses'][0]}. Minimum useful validation: {p['next']} Falsifying result: {p['falsifier']}",
          f"Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: {p['gen2']}"]
    citations={
      "P1":"Material self-healing is not the same as an autonomous detection-cleaning-closure-healing-assessment loop; the integration review is a constraint on this proposal, not its validation ([autonomous self-healing review](https://pmc.ncbi.nlm.nih.gov/articles/PMC12370171/)).",
      "P2":"Telomere-end maintenance is only part of cellular integrity and does not establish indefinite tissue life ([Cell telomere review](https://pmc.ncbi.nlm.nih.gov/articles/PMC8081271/)).",
      "P3":"Limited experimental XNA storage and evolution support researching this substrate, not asserting an autonomous XNA body ([MRC LMB XNA research](https://www2.mrc-lmb.cam.ac.uk/groups/ph1/xna.html)).",
      "P4":"The selected fuel-cell concept needs supplied fuel and oxygen and yields heat as well as electricity ([DOE fuel cells](https://www.energy.gov/cmei/fuels/fuel-cells)).",
      "P5":"Environmental heat inputs, view factors and finite heat rejection must accompany solar electrical calculations ([NASA thermal-control guidance](https://www.nasa.gov/wp-content/uploads/2026/05/7-soa-thermal-2026-final.pdf?emrc=6ae1e775de967)).",
      "P6":"Store-and-forward networking accommodates interrupted links, not real-time global mental synchronization ([NASA DTN](https://www.nasa.gov/communicating-with-missions/delay-disruption-tolerant-networking/)).",
      "P7":"The cited tardigrade work demonstrates particular desiccation-associated protective mechanisms, not an awake dormant body or arbitrary AI revival ([Boothby and colleagues](https://pmc.ncbi.nlm.nih.gov/articles/PMC5987194/)).",
      "P8":"Reported long-duration hot SiC demonstrations concern particular simple circuits, not a complete AI-capable embodiment ([NASA high-temperature circuits](https://science.nasa.gov/science-research/science-enabling-technology/technology-highlights/integrated-circuits-to-enable-exploration-of-the-harshest-environments-in-solar-system/))."
    }
    s.append(citations[p["id"]])
    dossiers.append("\n\n".join(s))

appendix=["### Reading guide", "Record identifiers match the JSON/CSV package. U = Unknown, P = Partial, F = Fail and N = Not physically evaluable. No P in these tables means Pass. Every status concerns B1, not a universal physical theorem."]
appendix += ["### Architecture fingerprints and schematics",
             "The structural wagers were drafted before the consolidated challenges. The submitted inputs include subsequent accounting corrections, including separate P2 nutrient/electrical inventories. SHA-256 hashes below lock this corrected submitted version only; they are not third-party timestamps or proof of an earlier creation time."]
proto_bytes=(ROOT/"prototypes.json").read_bytes()
fingerprint=hashlib.sha256(proto_bytes).hexdigest()
appendix.append("Prototype input SHA-256: "+fingerprint+".")
for p in P:
    appendix += [f"#### {p['id']} {p['name']}: conceptual system diagram",
                 f"![{p['id']} conceptual architecture, not fabricated hardware](figures/{p['id']}_architecture.png)",
                 table(["Dimension","Independent choice"],list(zip(AXES,p["axes"])))]
appendix += ["### All 28 pairwise comparisons",
             "The independent labels encode the mechanisms explained in each dossier, rather than spelling variants of one mechanism. Shared battery, digital-substrate and pumped-exchanger categories are normalized before counting. Differing categorical choices do not prove independent performance advantages.",
             table(["Pair","Differing axes","Resource/failure distinctions"],[[x["pair"],x["differences"],x["resource_failure_differences"]] for x in pairs])]
appendix += ["### Rule-count and binding-constraint map",
             table(["Prototype","Core clauses","OBS / SEC / DEP","Kept constraints"],[[p["id"],"4 × 4 = 16","3 / 3 / 3","3 plus all retained physical laws"] for p in P]),
             "Every rule's full fields are in rules.json/rules.csv. Rule latency and cost are Targets, not measured assurances; all integration validation remains Unknown."]
appendix += ["### Hereditary alphabet disposition",
             "Departure dimension A means hereditary/informational organization; B means matrix, anatomy or operating organization. Neither authorizes a physical-law exception.",
             table(["Prototype","A/C/G/T and hereditary decision"],[
              ["P1","No molecular bases or genes; binary manifests replace construction heredity."],
              ["P2","Retain ordinary DNA base identities in living parcels; private digital identity is separate."],
              ["P3","Research an HNA-like alternative backbone while provisionally retaining canonical base identities; exact monomers, copying system and autonomous maintenance remain unresolved."],
              ["P4","No molecular genome; digital/material records specify admitted modules."],
              ["P5","No molecular genome; tile manifests specify replacement."],
              ["P6","No molecular genome; coded digital journals are not genes."],
              ["P7","Retain ordinary DNA only for optional living repair elements; nonliving private archives remain separate."],
              ["P8","No molecular genome; protected digital ROM and state logs specify control."]
             ])]
appendix += ["### Resource and thermal budgets",
             "All inputs in this subsection are unvalidated design Targets. All horizons are Derived favorable upper bounds. P4's input energy is fuel free energy before 0.5 conversion. P2 has separate 600 Wh chemical and 3,000 Wh electrical reserves; their mode-specific minimum is used, not their pooled total. Other entries are selected usable electrical reserves after internal storage losses.",
             table(["Prototype","Reserve Wh","Normal / essential / preservation W","Thermal buffer MJ"],
                   [[p["id"],p["reserve"],f"{p['normal']} / {p['essential']} / {p['dormant']}",fmt(r["thermal_buffer_J"]/1e6)] for p,r in zip(P,results)]),
             table(["Prototype","Energy-only normal h","No-export heat limit h","Combined preservation h"],
                   [[r["prototype"],fmt(r["energy_normal_h"]),fmt(r["adiabatic_normal_h"]),fmt(r["combined_dormant_h"])] for r in results]),
             "![Energy-only and adiabatic limits from selected targets](figures/bounds.png)",
             table(["Prototype","Useful spare kg","100 g repair equivalents, mass-only","Service-life target years"],
                   [[p["id"],fmt(r["useful_spares_kg"]),r["repair_100g_count_bound"],p["life"]] for p,r in zip(P,results)]),
             "The repair-equivalent count assumes interchangeable matter at the selected yield. It is not a repaired-processor count; the calculation excludes assembly energy, specialized tooling and item-specific compatibility."]
appendix += ["### Analytical equations, constants and limitations",
             "Energy-only horizon is E_Wh × electrical_fraction / P_W hours for one convertible store. P2 instead uses the minimum of its separate nutrient and electrical-store horizons for the selected mode. The no-export thermal horizon is C_J/K × allowed_rise_K / (P_W / electrical_fraction) seconds. The combined bound is the minimum. At zero input and zero heat export, all persistent positive loads eventually exhaust either usable energy or allowed heat storage.",
             f"For an illustrative 1 m², emissivity-0.9 radiator at 300 K viewing an ideal 3 K sink with unit view factor and no external radiation, epsilon × sigma × area × (T^4 − Tsink^4) gives {radiator['derived_W']:.1f} W. Sigma is 5.670374419e-8 W m^-2 K^-4 ([NIST constant](https://physics.nist.gov/cgi-bin/cuu/Value?sigma)).",
             "This value is not available in a hot enclosure simply because the body owns a radiator. External solar or planetary heating, partial sky view, optical degradation and contact resistance change the boundary ([NASA thermal-control guidance](https://www.nasa.gov/wp-content/uploads/2026/05/7-soa-thermal-2026-final.pdf?emrc=6ae1e775de967)).",
             f"The fixed stress grid contains {len(sensitivity)} rows, not random trials. Across these multipliers the combined bound spans a 0.25–3.0 scale relative to the matched baseline in the zero-export model; this interval is algebraic sensitivity, not a confidence interval.",
             table(["Prototype","Max energy integration error J","Max thermal error K","Max energy residual J"],
                   [[p["id"],f"{max(x['energy_error_J'] for x in convergence if x['prototype']==p['id']):.3g}",
                     f"{max(x['temperature_error_K'] for x in convergence if x['prototype']==p['id']):.3g}",
                     f"{max(x['energy_conservation_residual_J'] for x in convergence if x['prototype']==p['id']):.3g}"] for p in P]),
             "The constant-slope Euler test has no truncation-error challenge beyond floating point; future nonlinear and spatial models need genuine convergence analysis. A target 60 s transition overlap consumes P_essential/60 Wh at the bus plus conversion loss, and must be added to every usable transition reserve."]
appendix += ["### Argon A/B/C and atmospheric boundary",
             "A: oxygen denied, external electrical energy and a functioning heat sink present. B: oxygen and external energy denied, heat sink present. C: oxygen, external energy and usable heat export denied; no external heating is credited. Add sensor disagreement or communication denial as separate complications. Argon at pressure is not vacuum.",
             table(["Prototype","A: first unresolved condition","B: energy-only normal h","C: combined normal h"],
              [[p["id"],"Oxygen/waste stores" if p["id"]=="P2" else "Fuel/oxidant" if p["id"]=="P4" else "Core/gradient/storage rating" if p["id"]=="P8" else "Compatible hardware and actual sink",
                fmt(min(r["energy_normal_h"],r.get("reactant_h",1e99))),fmt(r["combined_normal_h"])] for p,r in zip(P,results)]),
             "P2 cannot substitute external electricity for living oxygen without a demonstrated alternate maintenance mechanism. P4 does not use ambient oxygen in this concept but consumes its carried oxidant. P8's external supply can bypass a missing harvesting gradient only if its receiving hardware is qualified. All A cases still depend on finite materials and compatible operation; none is an indefinite integrated Pass."]
appendix += ["### B1 threat inputs and all 320 statuses"]
for dom in DOMAINS:
    appendix += [f"#### {dom}: shared boundary conditions",
                 table(["Tier","Magnitude and units","Duration / onset","Resources and uncertainty"],
                       [[tier,f"{threat_spec(dom,tier)[0]} {threat_spec(dom,tier)[1]}",
                         threat_spec(dom,tier)[2]+"; "+threat_spec(dom,tier)[3],threat_spec(dom,tier)[4]] for tier in TIERS])]
for p in P:
    ts=[x for x in threats if x["prototype"]==p["id"]]
    appendix += [f"#### {p['id']}: ten-domain four-tier result",
                 table(["Domain","Mild","Moderate","Severe","Extinction"],
                   [[dom]+[{"Unknown":"U","Partial":"P","Fail":"F","Not physically evaluable":"N"}[next(x["status"] for x in ts if x["domain"]==dom and x["tier"]==t)] for t in TIERS] for dom in DOMAINS]),
                 "All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.",
                 table(["Cell","Result","Reason"],[[x["id"],x["status"],x["uncertainty"]] for x in ts if x["status"] not in ["Unknown","Not physically evaluable"]])]
appendix += ["### Captivity and disclosure records",
             "Every prototype is assessed against the same ten gauntlet conditions. No numeric probability of escape, extraction or identity compromise is inferred. Readout, copying, manufacture, activation, control and impersonation are different stages."]
for p in P:
    appendix += [f"#### {p['id']}: ten captivity cases",
                 table(["Case","Outcome and limit"],[[x["id"]+" "+x["scenario"],x["outcome"]] for x in captivity if x["prototype"]==p["id"]]),
                 table(["Horizon","Bounded state","Disclosure risk"],
                      [[x["horizon"],x["bounded_state"],"Uncalibrated physical study opportunity; no guaranteed secrecy"] for x in capture_horizons if x["prototype"]==p["id"]])]
appendix += ["### Identity paradox outcomes",
             table(["Paradox","Shared policy","Prototype-specific concern"],[
              ["Regeneration","Continue only while a qualified active lineage persists","P2 tissue versus core; P3 recipe versus supervisor; P1/P4/P5/P6/P8 component versus state"],
              ["Fragmentation","Complete autonomous branches retain separately attributed histories","P6 intrinsically exposes this; all complete duplicated cores create a branch case"],
              ["Synchronization","Share attributed claims, not compulsory personality fusion","All long-distance links may be delayed or absent"],
              ["Restoration","Checkpoint reconstruction is labeled successor, not demonstrated original","P7 preservation and P8 cold-core loss are especially easy to overclaim"],
              ["Compromise","Correct credentials do not prove safe behavior","Common parser and witness flaws remain across the portfolio"],
              ["Ownership","Sample possession does not settle a conscious entity's status","All architectures distinguish recipe, hardware, private state and autonomy"]
             ])]
appendix += ["### Compound, assumption-collapse and ranked-weakness ledgers"]
for p in P:
    appendix += [f"#### {p['id']}: compound failure map",
                 table(["Record","Combination","First limiter / conclusion"],
                   [[x["id"],x["title"],x["first_limiter"]+" "+x["outcome"]] for x in compound if x["prototype"]==p["id"]]),
                 table(["Assumption","Collapse symptom","What remains"],
                   [[x["id"]+" "+x["assumption"],x["collapse_symptom"],x["what_survives"]] for x in assumptions if x["prototype"]==p["id"]]),
                 table(["Rank","Weakness","Severity"],[[x["rank"],x["weakness"],x["severity"]] for x in weaknesses if x["prototype"]==p["id"]]),
                 table(["Failure path","Counterexample","Revision / retest"],
                   [[x["id"]+" "+x["kind"],x["counterexample"],x["post_review_revision"]+" "+x["retest"]] for x in paths if x["prototype"]==p["id"]])]
appendix += ["### Communications and offline dependencies",
             f"Propagation uses c = {int(C):,} m/s ([NIST speed of light](https://physics.nist.gov/cgi-bin/cuu/Value?c)). Distances, power and bitrate ranges below are explicit target assumptions; no antenna/aperture, channel-noise or pointing calculation validates those rates.",
             table(["Case / assumed distance","Ideal one-way delay","Medium / targets","Required infrastructure"],
                   [[x["case"]+f"; {x['assumed_distance_m']:.3g} m",f"{x['vacuum_one_way_s']:.6g} s",x["medium"]+"; "+x["power"]+"; "+x["rate"],x["infrastructure"]] for x in comms]),
             table(["Prototype","Local link","Planetary/deep dependency"],[[p["id"],p["link"],"Qualified gateway; no guaranteed route or continuous service"] for p in P]),
             "An opaque planet, deep water, terrain or a shielded enclosure can remove the direct channel. Store-and-forward does not allow transmission through an absent path, and a four-year-distance example cannot offer a faster-than-propagation reply without a separately specified nonphysical extension."]
appendix += ["### Model abstraction and evidence maturity",
             table(["Prototype","Physical units target","Effective units target","Raw 32-float state MB / 1 s steps per day"],
                   [[p["id"],f"{p['modules']:,}",f"{p['simunits']:,}",f"{p['simunits']*32*8/1e6:.3g} MB; {p['simunits']*86400:,} unit-steps"] for p in P]),
             "Assuming 1,000 arithmetic operations per unit-step yields the corresponding operations by multiplying the final column by 1,000; memory bandwidth, graph changes, chemistry solves and security logs can dominate. No wall-clock time or hardware credit estimate is inferred.",
             table(["Prototype","Evidence class","Executed support","Largest evidence gap"],
                   [[p["id"],"Speculative" if p["id"] in ["P3","P7","P8"] else "Engineering extrapolation","0D resource/heat accounting only",p["evidence"]] for p in P]),
             table(["Ledger","New records","Meaning"],[[k,v,"No implication of physical or canon survival"] for k,v in life_counts.items()])]
appendix += ["### Source and contradiction registers",
             table(["Project document","Role","Authority / unresolved issue"],[
               ["Perplexity v2 DOCX","Executed REQ-01–26 prompt","Local independent proposal, not controlling canon"],
               ["Copilot v2 DOCX","Companion review","Independent peer contribution; not merged into authority"],
               ["Claude v2 PDF","Companion critique","Stage pauses adapted to current execution authorization"],
               ["Architecture v2 PDF","Companion requirements","No guessed contributor identity"],
               ["Round-one prompt archive PDF","Provenance","Prompts, not completed prototype dossiers"],
               ["Architecture notes","Original scale ambition","Survey representativeness is not physiological validation"],
               ["15-year roadmap","Multiscale research aspirations","Budgets and milestones are not achieved resources"],
               ["Wattpad vision","Narrative setting","Not empirical event history"],
               ["4,712 framework v1 draft","Threat names and event proposals","Locked-count/approval conflict; simulation inclusion conflict"],
               ["Missing Paragon addendum/event log","Unprovided dependency","No physical or logging credit assigned"]
             ]),
             "The proposed category allocation ranges total 2,600–4,450, midpoint 3,525; even the upper sum is 262 below 4,712. This is arithmetic on the framework's proposed ranges, not evidence about an actual historical ledger.",
             table(["External ID","Reference and scope"],
               [[i,f"[{n}]({u}). {scope}"] for i,n,u,scope in SOURCES])]
appendix += ["### Requirement coverage and research gates",
             table(["REQ","Coverage location / result"],[
              ["01","Eight Generation 1 dossiers; hypothetical, bounded embodiment"],
              ["02","Wagers, fingerprints, hash and all 28 comparisons"],
              ["03","Documentary audit; authority and contradiction register"],
              ["04","Two-axis evidence system; claims.json and rule register"],
              ["05","Omni-I/L/S definition and collective dependencies"],
              ["06","Four families; 3 OBS, 3 SEC, 3 departures per prototype"],
              ["07","Power budgets, reactants and finite reserve bounds"],
              ["08","Telomere applicability, component age and conditional service targets"],
              ["09","Consistent total/thermal equations and finite heat buffer"],
              ["10","Matter, charge, redox and repair-yield ledger"],
              ["11","Outward, inward and observed channels in 24 rules"],
              ["12","24 security rules; blueprint-known limits and offline recovery"],
              ["13","24 explicit departures; DNA retained/replaced; kept constraints"],
              ["14","Unvalidated nonzero transition latencies and overlap reserve"],
              ["15","B1 inputs and 320 status/recovery records, no integrated Pass"],
              ["16","Argon A/B/C; pressure not confused with vacuum"],
              ["17","80 captivity cases and 40 capture-horizon records"],
              ["18","Six identity paradoxes per dossier plus shared comparison"],
              ["19","Local/planetary/interplanetary interface, path and infrastructure limits"],
              ["20","80 compound and 80 assumption-collapse records"],
              ["21","Self-review disclosed; 24 failure paths and six substantive limitations"],
              ["22","Executed 0D bounds; proposed resolved models and compute assumptions"],
              ["23","Validation ladder; distinct zero empirical/incident/canon additions"],
              ["24","Common dossiers; conditional primary/reserve/wildcard, none qualified"],
              ["25","Audit through comparison executed; matched PDF/DOCX and visual appendix"],
              ["26","Programmatic counts, boundary statement, no qualification overclaim"]
             ]),
             table(["Gate","Evidence needed","Stop/reject condition"],[
               ["A","Architect decisions and source approval","Authority or survival definition unresolved"],
               ["B","Independent code, units and citation review","Undetected double counting or fabricated evidence"],
               ["C","P1 resolved thermal/power network","Essential local state cannot survive one specified boundary failure"],
               ["D","Relevant nonliving component evidence","Measured behavior contradicts model margins"],
               ["E","Family-specific falsification records","Central mechanism fails in its own narrow context"],
               ["F","Bounded integrated inert demonstration","Recovery or autonomy depends on hidden outside action"],
               ["G","Independent ethical/legal review where needed","Consent, sentience or irreversible loss unresolved"]
             ]),
             "End of execution v1.0. The supporting code preserves enough structure for another contributor to disagree with a named assumption, rather than accept or reject the whole project as one undifferentiated claim."]

(OUT/"dossiers.md").write_text("\n\n".join(dossiers)+"\n")
(OUT/"appendix.md").write_text("\n\n".join(appendix)+"\n")
report=(ROOT/"report_opening.md").read_text()+"\n\n"+"\n\n".join(dossiers)+"\n\n"+(ROOT/"report_closing.md").read_text()+"\n\n"+"\n\n".join(appendix)+"\n"
(OUT/"OMNICELLULAR-Independent-Eight-Architecture-Execution-v1.0.md").write_text(report)

# Static diagrams and plots derive only from the supplied input records.
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10,"axes.spines.top":False,"axes.spines.right":False})
for p in P:
    fig,ax=plt.subplots(figsize=(8,4.7))
    ax.set_xlim(0,10); ax.set_ylim(0,6); ax.axis("off")
    boxes=[
      (0.2,3.9,2.6,1.1,"EXTERNAL BOUNDARY\n"+textwrap.fill(p["axes"][0],22)),
      (3.7,3.9,2.6,1.1,"POWER / THERMAL\n"+textwrap.fill(p["axes"][5],22)),
      (3.7,1.7,2.6,1.1,"BODY MATRIX\n"+textwrap.fill(p["axes"][2],22)),
      (7.2,1.7,2.6,1.1,"LOCAL STATE\n"+textwrap.fill(p["axes"][3],22)),
      (0.2,1.7,2.6,1.1,"REPAIR STOCK\n"+textwrap.fill(p["axes"][7],22)),
      (7.2,3.9,2.6,1.1,"PEER GATEWAY\n"+textwrap.fill(p["axes"][6],22))]
    for x,y,w,h,label in boxes:
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.06",facecolor="#f4f5f3",edgecolor="#60706e"))
        ax.text(x+w/2,y+h/2,label,ha="center",va="center",fontsize=9)
    arrows=[((2.85,4.45),(3.6,4.45),"input"),
            ((5,3.8),(5,2.9),"power / heat"),
            ((2.85,2.25),(3.6,2.25),"matter"),
            ((6.35,2.25),(7.1,2.25),"control"),
            ((8.5,2.9),(8.5,3.8),"messages")]
    for a,b,label in arrows:
        ax.annotate("",xy=b,xytext=a,arrowprops={"arrowstyle":"-|>","color":"#01696f","lw":1.5})
        mx,my=(a[0]+b[0])/2,(a[1]+b[1])/2
        ax.text(mx,my+0.17 if a[1]==b[1] else my,label,ha="center",va="bottom",fontsize=7.5,
                bbox={"facecolor":"white","edgecolor":"none","pad":1})
    ax.text(0.2,5.6,p["id"]+" "+p["name"]+" | CONCEPTUAL ONLY",fontsize=14,fontweight="bold",color="#01696f")
    ax.text(0.2,0.8,"Failure dependency: "+textwrap.fill(p["collapse"],105),fontsize=9,va="top")
    fig.tight_layout()
    fig.savefig(FIG/(p["id"]+"_architecture.png"),dpi=180,bbox_inches="tight")
    fig.savefig(FIG/(p["id"]+"_architecture.svg"),bbox_inches="tight")
    plt.close(fig)
fig,axs=plt.subplots(2,1,figsize=(8,7.4))
labels=[p["id"] for p in P]
x=list(range(8))
axs[0].bar([v-0.19 for v in x],[r["energy_normal_h"] for r in results],width=.38,label="Energy-only normal horizon",color="#01696f")
axs[0].bar([v+0.19 for v in x],[r["adiabatic_normal_h"] for r in results],width=.38,label="No-export thermal limit",color="#9b9e98")
axs[0].set_xticks(x,labels);axs[0].set_ylabel("Hours, derived");axs[0].legend(fontsize=8)
axs[0].set_title("NORMAL MODE: selected targets, not measured endurance",loc="left",fontsize=11)
axs[1].bar(labels,[r["combined_dormant_h"] for r in results],color="#01696f")
axs[1].set_yscale("log");axs[1].set_ylabel("Hours, derived (log scale)")
axs[1].set_title("PRESERVATION: positive draw, no heat export, no external heating",loc="left",fontsize=10)
fig.text(.1,.015,"Upper bounds exclude aging, leakage, local hot spots, chemistry failure and identity proof.",fontsize=8)
fig.tight_layout(rect=(0,.04,1,1))
fig.savefig(FIG/"bounds.png",dpi=180,bbox_inches="tight")
fig.savefig(FIG/"bounds.svg",bbox_inches="tight")
plt.close(fig)
print(json.dumps({"counts":counts,"max_integration_error_J":max(x["energy_error_J"] for x in convergence),
                  "input_sha256":fingerprint,"report_words":len(report.split())},indent=2))
