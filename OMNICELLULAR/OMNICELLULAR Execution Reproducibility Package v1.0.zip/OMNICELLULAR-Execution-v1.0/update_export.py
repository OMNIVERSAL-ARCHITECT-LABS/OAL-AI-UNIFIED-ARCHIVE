#!/usr/bin/python3
"""Use LibreOffice's native document engine to refresh TOC and export both formats."""
from pathlib import Path
import shutil
import subprocess
import time
import uno
from com.sun.star.beans import PropertyValue

root=Path(__file__).resolve().parent
out=root/"output"
base="OMNICELLULAR-Independent-Eight-Architecture-Execution-v1.0"
def props(**kw):
    result=[]
    for k,v in kw.items():
        p=PropertyValue();p.Name=k;p.Value=v;result.append(p)
    return tuple(result)
proc=subprocess.Popen(["soffice","-env:UserInstallation=file:///tmp/omni_refresh_lo","--headless",
                       "--accept=socket,host=localhost,port=2011;urp;StarOffice.ComponentContext",
                       "--norestore","--nodefault","--nofirststartwizard"],
                      stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
local=uno.getComponentContext()
resolver=local.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver",local)
ctx=None
for _ in range(150):
    try:
        ctx=resolver.resolve("uno:socket,host=localhost,port=2011;urp;StarOffice.ComponentContext")
        break
    except Exception:
        if proc.poll() is not None:
            raise RuntimeError("LibreOffice listener exited before initialization")
        time.sleep(0.1)
if ctx is None: raise RuntimeError("LibreOffice listener unavailable")
desktop=ctx.ServiceManager.createInstanceWithContext("com.sun.star.frame.Desktop",ctx)
doc=desktop.loadComponentFromURL((out/(base+".docx")).as_uri(),"_blank",0,props(Hidden=True))
indexes=doc.getDocumentIndexes()
for j in range(indexes.getCount()): indexes.getByIndex(j).update()
doc.refresh()
for j in range(indexes.getCount()): indexes.getByIndex(j).update()
refreshed=root/"qa"/(base+"-refreshed.docx")
doc.storeAsURL(refreshed.as_uri(),props(FilterName="Office Open XML Text",Overwrite=True))
doc.storeToURL((out/(base+".pdf")).as_uri(),props(FilterName="writer_pdf_Export",Overwrite=True))
doc.close(True)
desktop.terminate()
proc.wait(timeout=20)
shutil.copyfile(refreshed,out/(base+".docx"))
print(f"Updated {indexes.getCount() if False else 'native'} contents index; exported matched DOCX and PDF.")
