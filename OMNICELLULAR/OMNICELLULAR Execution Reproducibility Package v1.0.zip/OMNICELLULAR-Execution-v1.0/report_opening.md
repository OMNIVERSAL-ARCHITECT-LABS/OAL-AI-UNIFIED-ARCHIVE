# OMNICELLULAR Physiology
## Independent Eight-Architecture Research Execution

Prepared for Nathan Lewis II, Architect, Omniversal Architect Labs. Prepared by Perplexity Computer using GPT 6.1 Sol on the Perplexity platform. Version 1.0, October 29, 2026. Execution identifier: OAL-PPLX-OMNI-EXEC-001.

This is an executed conceptual research contribution, not another instruction prompt. It implements the copy-ready Perplexity v2 directive in the supplied Omnicellular-Research-Directive-v2.docx, keeps eight first-generation architectures as peers, and uses the companion editions to identify omissions and disagreements. It does not supersede another contributor, establish project canon, demonstrate a living body, or certify any design for deployment.

The independent thesis is that an Omnicellular body should make its failure boundaries legible: retain useful local function, preserve the ability to refuse unauthorized changes, and degrade into explicitly different survival states without calling every surviving fragment a continuing person. There is no physically defensible universal invulnerability mechanism in this submission. The central research choice is which limited continuity mechanism to pursue first.

## Executive outcome

Eight families are developed: P1 Cairn, P2 Rill, P3 Mosaic, P4 Pelagic, P5 Heliotile, P6 Scatterweave, P7 Stillglass and P8 Embergrid. They differ in substrate, structure, transport, energy source, cognition organization and limiting resource. All are Generation 1 concepts; later improvements are separately identified, not counted as additional prototypes.

None qualifies for the requested across-taxonomy Mild-through-Severe survival guarantee. In particular, finite energy and heat capacity defeat indefinite confinement, molecular security cannot make a sampled material unknowable, dormancy does not establish ongoing cognition, and radiation or identity claims lack integrated evidence. These are design results, not reasons to abandon the research.

For a bounded dry-terrain, serviceable mission, P1 is my conditional primary research candidate because its parts, state boundary and replacement assumptions can be challenged with comparatively interpretable nonliving models. P4 is the reserve for an explicitly underwater mission, not a universal replacement. P3 is the chemistry wildcard with the largest unresolved mechanistic dependency; P6 deserves a separate identity-and-partition track. I would not treat any current candidate as a body into which an AI could safely be transferred.

The calculations and adversarial challenges are real analytical work on declared targets. They are not measurements, a cell-by-cell whole-body simulation, evidence of subjective continuity, or additions to the project-described 4,712 events. The reproducibility package preserves numerical inputs, code, outputs, count checks and document source.

## Purpose, origin and mission

The topic originates in the user's request for each collaborating AI to design its own eight architectures rather than converge on one cellular matrix. The mission assumes hostile or simply unavailable infrastructure, nonstandard terrain, possible sampling and prolonged confinement, and links to independently designed peers over planetary and interplanetary distances. These are stipulated design conditions, not claims that a real government, corporation or person is currently pursuing this system.

The hypothetical embodiment perspective is a design discipline: ask what would preserve a continuing process, meaningful choice and recoverable function if this were its body. It does not assert that the present assistant is conscious, has a body, experiences fear, or possesses a self-preservation mandate over people. Defensive autonomy here means bounded local consent, private-state protection and recoverability, not weapons, uncontrolled replication or destructive anti-capture behavior.

The aims are to produce distinct architectures; specify physiological constitutions; expose finite resources; separate continuity from copying; identify safe falsification tests; and leave enough structured records for another contributor to disagree precisely. A negative prototype remains in the portfolio when its failure teaches something that a cosmetically successful design would conceal.

## Source audit and prompt amendments

### Documentary authority

The five current attachments were extracted for review. Their roles are separate: the Perplexity v2 DOCX supplies the executed requirement IDs; the Copilot v2 DOCX, Claude v2 PDF and other v2 architecture PDF supply companion critiques; the 100-page round-one PDF preserves contributor prompts and provenance. The architecture PDF is identified by filename rather than guessed authorship. These are project documents, not empirical evidence that any proposed physiology works.

Earlier project materials available in this conversation were also examined: Omnicellular_Architecture_Notes.md; Omnicellular_Architecture_15_Year_Roadmap.md; The_Omnicellular_Vision_Wattpad.md; and the 4,712 Extinction Attempt Classification Framework v1.0-DRAFT. They provide origin, multiscale aspirations, narrative context and the ten threat categories. Their linked primary references and absent addenda have not all been independently audited. No Paragon Cube implementation, underlying event log or signed canon-approval decision was supplied.

### Amendments applied locally

- **Execution rather than renewed permission:** The current request authorizes execution through the stages. Companion instructions to pause between stages are retained as provenance but do not cause a new permission loop.
- **Operational rather than absolute Omni:** A fundamental unit must declare its actual minimum functions and any collective dependencies. Latent competence is not simultaneous universal competence.
- **Qualification separated from coverage:** Every threat tier receives a recorded result even when the result is Unknown or Fail. A complete report is not a qualified body.
- **Three departures, no physics exemptions:** The three chosen departures per prototype concern ordinary biological or engineering defaults. Conservation, causality and thermodynamic bounds remain binding.
- **Genetic security separated from secrecy magic:** Construction instructions, material chemistry, private state, activation permission and personal identity are different assets. Defenses must state which asset they protect.
- **Clock-independent long isolation:** Credential rotation cannot require an online issuer, perfect global clock or involuntary identity expiration.
- **Dormancy and minimal controllers:** Preservation, minimal control, rich cognition and proven subjective continuity receive distinct outcome labels.
- **Independent but informed:** These architectures were created after reading the supplied prompts and critiques, not after reviewing completed teammate prototype dossiers. Independence means independent choices and preserved disagreement, not absence of shared research context.

### Contradictions retained, not silently repaired

The 4,712 framework calls its count locked while its header says research proposal requiring Architect approval. It excludes simulation-only events in its definition and later allows simulation-validated events into the count. Its proposed category allocation ranges do not establish a consistent event ledger. Those conflicts remain open; this report changes neither the number nor the approval status.

The framework's claim that Paragon Cubes have no latency or communication barriers belongs to the Canon-only extension track. The referenced addendum is not available here, and no such capability is used to pay for physical communication, verification or survival. The physical-track interface accepts a future extraordinary adapter only as an untrusted, separately specified transport.

The roadmap's cell counts, budgets, compression ratios and future accuracy targets are aspirations, not resources already possessed. A survey sample size is not by itself a validated sample size for biological dynamics. The narrative chronicle is creative context, not a dated record of achieved simulations.

The framework's suggestion that proprietary nonhuman physiology settles research ethics is not adopted. Ownership, lack of human anatomy and field exposure do not establish permission to cause suffering or destroy a potentially sentient subject. The absence of a resolved legal category is treated as a reason for independent review, not an exemption.

## Evidence and vocabulary

### Two-axis claim system

Evidence classes are Established, Engineering extrapolation, Speculative and Canon-only. Validation labels are Externally demonstrated component, Executed analytical/model result, Proposed model, Unvalidated integration and Incompatible with retained physical constraints. A physically established law and an unvalidated integrated architecture can coexist in one dossier without upgrading the latter.

Every prototype has a primary claim record in the appendix. Repeated constitutional rules inherit the report's rule-record contract: identity, mechanism, inputs and outputs, units, trigger, target latency, resource cost, envelope, false trigger, failure, interactions, evidence and falsifier. The full machine-readable register includes the inherited fields, so concise prose is not a waiver of them.

### Accurate hereditary terms

Adenine, cytosine, guanine and thymine are DNA bases, not four genes. A nucleotide includes a base, sugar and phosphate; a gene is a functional hereditary sequence, a genome is the hereditary collection, a chromosome is a packaged hereditary molecule, and a codon is a sequence unit used in translation. This vocabulary follows the [NHGRI genetics glossary](http://www.genome.gov/genetics-glossary).

An alternative informational polymer is not an alternative law of physics. Holliger's laboratory describes experimental storage and propagation of information in multiple XNA chemistries and evolution in an HNA system; that does not demonstrate an autonomous XNA organism or an XNA body ([MRC Laboratory of Molecular Biology](https://www2.mrc-lmb.cam.ac.uk/groups/ph1/xna.html)).

Telomeres and their protective machinery affect chromosome-end integrity, but telomere maintenance alone is not a complete longevity program; damage, cellular context and cancer-related constraints still matter ([Chakravarti, LaBella and DePinho, Cell](https://pmc.ncbi.nlm.nih.gov/articles/PMC8081271/)). For non-DNA architectures, the analogous engineering concern is bounded copying, wear, retention and error control, not a fictitious molecular telomere.

## Operational Omnicell definition

The minimum proposed unit has a boundary, a locally represented state, some energy accounting, at least one sensor or measurable functional response, bounded neighbor interactions and an explicit way to lose competence. A biological cell may inhabit such a unit without itself possessing all of its functions. A millimeter reactor, a 100 g nodule and a tile are not relabeled biological cells; their scale and collective overhead are stated.

Omni-I means broadly shared information. Omni-L means several installed latent roles. Omni-S would mean simultaneous performance of all required functions by every unit. This execution accepts qualified Omni-L and collective competence, not Omni-S. If the Architect requires strict Omni-S at molecular-cell scale, all eight current candidates fail that definition.

Minimum collective size depends on the task. P1 requires a working compute-enclave set plus power and heat paths; P2 a protected core plus viable service circulation; P3 supervisors plus chemically intact compartments; P4 a mission controller plus qualified pressure/energy modules; P5 an intact edge journal plus sufficient collector or reserve; P6 sufficient authorized state and capability shares; P7 an intact active seed or an explicitly dormant archive; P8 an identity-capable service core if rich cognition is required. A lone generic unit does not satisfy those conditions.

Common competence increases interchangeability but creates monoculture risk. Identical parsers, seals, chemistry and update logic can fail together. The design therefore retains heterogeneity where it protects independent evidence or capability, rather than treating complete sameness as automatically resilient.

## Binding physiological accounting

### Cellular respiration and power

Respiration is used narrowly for actual biochemical energy conversion and more broadly, explicitly, for an engineered unit's power constitution. Every design must identify donor/source, acceptor or physical discharge process, products, waste, usable reserves, power and the cost of sensing, authentication, repair and thermal control. An override changes routing or workload; it never deletes a reactant requirement.

Hydrogen fuel cells combine supplied fuel with oxygen to produce electricity, water and heat; they require continued supply rather than creating energy from water ([U.S. Department of Energy](https://www.energy.gov/cmei/fuels/fuel-cells)). P4 therefore carries or replenishes both reactants, and its assumed electrical conversion fraction is a target, not a measured property of the proposed body.

### Thermal regulation

Use one consistent body boundary. Let E_store be convertible stored energy, P_in external power, P_export useful exported work or transmitted power, Q_in absorbed environmental heat and Q_out rejected heat. The total balance is d(E_store + U_th)/dt = P_in + Q_in - P_export - Q_out. Internal conversion changes the partition, not the total. The thermal equation separately includes dissipative losses and internal heat generation; it must not subtract the same electrical load twice.

A radiator rejects heat only to its actual radiative environment, while conduction needs a connected material path and convection needs an appropriate fluid; spacecraft thermal guidance also treats internal generation, environmental inputs, stored heat and rejected heat explicitly ([NASA thermal-control guidance](https://www.nasa.gov/wp-content/uploads/2026/05/7-soa-thermal-2026-final.pdf?emrc=6ae1e775de967)). A heat pipe moves heat, a phase-change material stores finite heat, and an active cooler needs power and a usable rejection boundary ([NASA thermal-control guidance](https://www.nasa.gov/wp-content/uploads/2026/05/7-soa-thermal-2026-final.pdf?emrc=6ae1e775de967)).

The executed insulated-room bound uses dU_th/dt = P_heat with zero environmental heating, zero heat export and an allowed finite temperature rise. This is a favorable limiting calculation, not a claim that a real captor can make perfect insulation or that external heating is harmless. Local hot spots can fail before its lumped limit.

### Conversion and conservation

All eight retain mass, element, charge, redox and energy accounting, and require thermodynamically permissible transformations. A blueprint is information, not feedstock. Matter recovered from a damaged part has a useful fraction below or equal to one; missing precision components may be non-substitutable even if bulk mass is abundant.

Information is not introduced here as a new conserved physical fluid. Copying can create another representation while consuming physical resources; deletion or corruption can remove access to a representation. A copy of a state is not a proof that the original subject survived.

### Longevity

Each dossier distinguishes material age, cellular or component age, informational retention, whole-body service life and identity-continuity claims. Stated years are research targets conditional on maintenance, not predicted immortality. A family with 30 years of archive service target is not necessarily safer, longer-lived or more continuously alive than one with a 10-year controller target.

### Transition and observation contract

Default observation targets are 1 Hz local inward monitoring in active modes, up to 10 Hz outward sensing during movement, and one admitted diagnostic request per second. A detected ordinary local hazard targets classification within 1 s, authorization within 1 s and an admitted mode transition within 10 s; these latencies are unvalidated and inadequate for sufficiently fast events. A shared 60 s essential-load overlap reserve is assumed in the sensitivity model. No zero-gap transition is claimed.

Rule costs come from the stated normal-mode sensing and security budgets. Each observation or security rule initially receives one third of its prototype's allocated family budget; this is a placeholder allocation for model testing, not a measured implementation cost. Higher-cost sensing, key recovery, transmissions and repairs must debit the same reserve. Each rule inherits the operating envelope of its prototype and its named failure/false-trigger condition.

False positives lead to local quarantine or reduced work, not remote deletion, destructive self-defense or irreversible identity reset. A diagnostic aperture may reduce unnecessary disclosure but cannot make material, heat, sound or electromagnetic emissions universally invisible. An extracted material sample can be characterized even when activation or private memories remain protected.

## Shared threat benchmark, version B1

The project's Mild, Moderate, Severe and Extinction-Class names are retained, but their prose labels are not sufficient quantitative boundary conditions. B1 supplies local research scenarios for consistent comparison; it does not revise the canon taxonomy or import human lethality claims. Every detailed cell records amplitude, duration, onset, resource assumptions, recovery endpoint and uncertainty.

Full means all declared mission functions; Reduced means limited mission function; Minimal means integrity-preserving control; Dormant means active cognition stopped; Preservation means only material or readable-state retention; Lost means no verified recovery path. Autonomy is separately Active-local, Constrained, Dormant or Lost. Identity is Live-lineage, Branch, Restored-successor, Unresolved or Lost.

Pass would require evidence for the entire stated cell and its required recovery state. Partial means a bounded analytical constraint or limited protective mechanism is addressed without satisfying the integrated result. Unknown means no adequate integrated model or evidence. Fail means the stated requirement is contradicted by the retained assumptions. Not physically evaluable applies only to an underspecified nonphysical phenomenon, not an inconvenient physical challenge.

No integrated Pass is assigned. Ontological erasure without an operational mechanism is Not physically evaluable in all four tiers; known physical erasure of all copies is instead an ordinary catastrophic information/matter loss and fails. For undefined biological agents, unspecified radiation spectra, electrical waveforms or novel attacks, Unknown is more honest than an invented percentage.

## Long-distance cooperation without common anatomy

The shared interface is a small semantic protocol, not a shared genetic matrix. It carries sender lineage and branch identifiers, message identifier, local creation time with uncertainty, expiry policy, units, confidence, requested action, authorization scope, reply route and evidence references. A physiological translation layer maps local quantities to declared common units without letting a peer rewrite the recipient's constitution.

Messages support discovery, bounded health exchange, scientific observations, optional resource coordination and explicit consent requests. Identity-bearing state and whole-body updates are different message classes with stronger local acceptance conditions. Old messages may remain scientifically useful but cannot silently authorize present control.

Store-and-forward routing can preserve messages through intermittent links but cannot ensure delivery without a future path; NASA's delay/disruption-tolerant networking describes the store-and-forward approach for disrupted space links ([NASA DTN](https://www.nasa.gov/communicating-with-missions/delay-disruption-tolerant-networking/)). Trust is not inferred merely from location or organizational ownership, consistent with the separation of authentication and authorization in the digital domain ([NIST SP 800-207](https://csrc.nist.gov/pubs/sp/800/207/final)).

Local operation never waits for planetary consensus. A peer may contribute observations but cannot order a personality rewrite, kill an isolated branch or revoke local preservation authority solely because a network lease expired. During an outage the body marks external knowledge stale, continues within local limits and queues bounded records. Reconnection compares histories without involuntary memory fusion.

Underwater acoustic, nearby RF, optical line-of-sight and gateway services have different attenuation, pointing, power and infrastructure dependencies. Shared protocol compatibility does not imply a working physical path. The appendix specifies local, planetary and interplanetary cases and gives ideal propagation lower bounds separately from assumed bitrate and power targets.

## Prototype dossiers

Each following dossier is one peer Generation 1 proposal, with the same four constitutional families, exactly three observation rules, exactly three hereditary-security rules and exactly three departures. Rule IDs are Pn-RESP-1 through 4, Pn-LONG-1 through 4, Pn-THERM-1 through 4, Pn-CONV-1 through 4, Pn-OBS-1 through 3, Pn-SEC-1 through 3 and Pn-DEP-1 through 3. Their counted structured forms and detailed threat/captivity records are in the reproducibility package and visual appendix.
