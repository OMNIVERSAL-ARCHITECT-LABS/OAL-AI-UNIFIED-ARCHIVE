## P1 Cairn: Generation 1

### Core wager and body

A body made of individually sealed, interchangeable dry modules can lose local structure without losing the protected computational lineage. It gives up organism-like molecular regrowth and the ability to manufacture advanced electronics from raw terrain.

A 60 kg, approximately 0.6 m-long articulated lattice has 10,000 sealed 6 g modules, including structure, conductors, energy storage and reserved replacement stock. The nominal 1 cm module is a cellular equivalent, not a biological cell. Central organ-equivalents are replaced by spatially separated power islands, compute enclaves and conductive paths; actual AI compute capacity is unresolved.

Each node senses local strain and temperature, executes bounded control, authenticates neighbors, conducts power and helps carry load. Different nodes provide different optional attachments. Local role reassignment is real within installed hardware; a conductor does not become a processor by software alone. Repair and high-bandwidth cognition are collective, not simultaneous universal node functions.

### Matrix, transport and cognition

No molecular genome: versioned binary manifests encode module type, permitted assembly and diagnostic invariants; private episodic state is separate.

Two physically separated electrical bus routes with independently isolatable branches; conducted heat reaches outer radiator panels. There is no pumped circulation. Three compute enclaves maintain a serializable state journal. A target two-of-three local authorization threshold protects consequential state changes, but does not prove subjective continuity. Each enclave can retain a limited read-only diagnostic mode after partition.

Dry terrain, orbital infrastructure and abrasive ground are intended environments; underwater use requires separate seal and pressure qualification.

### Physiological constitution

Rechargeable electrochemical storage is primary during deployment; authenticated external electrical supply is secondary. No atmospheric reactant is required for the selected storage model.

#### Respiration and power

- **P1-RESP-1:** Stored electrochemical free energy, not argon or software, supplies the emergency bus.

- **P1-RESP-2:** Branch faults isolate locally; a separate reserve rail maintains the lineage journal.

- **P1-RESP-3:** Power reduction suspends locomotion before integrity checks or thermal alarms.

- **P1-RESP-4:** Recharge resumes only after cell, insulation and temperature checks; depleted cells are not reanimated by a remote command.

#### Telomeres, copying and longevity

- **P1-LONG-1:** A module age ledger counts operating hours, thermal excursions and charge cycles rather than telomere length.

- **P1-LONG-2:** Replacement requires matching type, provenance and local acceptance tests.

- **P1-LONG-3:** A failed node cannot authorize manufacture of unlimited descendants.

- **P1-LONG-4:** Repair retains the current state journal; reconstruction after all active enclaves are lost is reported separately.

#### Thermal regulation

- **P1-THERM-1:** Conductors move heat to external radiators, with joint resistance included.

- **P1-THERM-2:** Each compute enclave measures its own temperature rather than trusting a whole-body average.

- **P1-THERM-3:** Load shedding starts before the selected 20 K thermal-buffer margin is consumed.

- **P1-THERM-4:** A blocked radiator permits only finite buffering; active refrigeration has no assumed infinite sink.

#### Conversion and conservation

- **P1-CONV-1:** Battery energy is debited at the system boundary, including bus losses.

- **P1-CONV-2:** Replacing missing matter consumes matched spare mass and assembly energy.

- **P1-CONV-3:** Cannibalization transfers a working module and reduces the remaining structural reserve.

- **P1-CONV-4:** Charge, heat and exported mechanical work are reconciled at each bus island.

The proposed service-life target is 20 years conditional on 6 months inspection; power modules condition-based. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P1-OBS-1, Load-path disagreement:** Cross-check outward inertial and contact observations against local strain before high-load movement. Trigger: movement command. Target cost 1.00 W under the shared rule contract; other inputs: three dissimilar observations. False trigger or failure: sensor disagreement or concealed contact. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P1-OBS-2, Thermal witness:** Compare inward enclave temperatures with heat-flow estimates and refuse to infer safety from one cool sensor. Trigger: every power increase. Target cost 1.00 W under the shared rule contract; other inputs: local thermal history. False trigger or failure: poor sensor contact or an unmodeled hot spot. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P1-OBS-3, Diagnostic aperture:** Expose a consented health summary through one bounded interface; destructive inspection still reveals materials. Trigger: external diagnostic request. Target cost 1.00 W under the shared rule contract; other inputs: declared health channels only. False trigger or failure: physical access bypasses the interface. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P1-SEC-1, Assembly attestation:** Local enclave threshold authorizes new module manifests; a removed module carries its type, not the full current lineage. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: signed manifests with monotonic version records. False trigger or failure: old manifests remain readable but not automatically executable. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P1-SEC-2, Bounded lineage fragments:** No individual node stores all private state or all recovery credentials. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: fragmented state and local authorization. False trigger or failure: losing sufficient enclaves makes recovery impossible. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P1-SEC-3, Partition-safe credential epochs:** Local credentials advance without an online issuer; rejoining nodes undergo a read-only comparison before renewed writes. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: local epochs rather than a global clock. False trigger or failure: clock drift cannot justify rolling the lineage backward. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P1-DEP-1, DNA-only heredity:** Signed digital manifests replace a genome for construction information. Departure affects dimension A; support: Established digital storage; extrapolated whole-body integration. This departs from a biological or engineering default, not a physical law.

- **P1-DEP-2, Universal living tissue repair:** Replacement of discrete nodes replaces cell proliferation. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P1-DEP-3, Central circulation:** Electrical buses and conductive heat paths replace a bloodstream. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Finite electrochemical energy and causal communication; Bounded replacement tied to physically present spares; No identity rewrite without local authorization.

### Repair, identity and autonomy

A target 3 kg spare allowance supports substitution, not molecular regeneration. Damage is isolated, cleaned conceptually, replaced and re-tested before load is returned. Destroyed processors and precision seals remain manufacturing dependencies. A 100 g lost module group requires at least 100 g of compatible replacement matter; contamination and sorting lower yield.

Regeneration preserves the live enclave journal. Fragmentation produces one authorized continuation only when local policy can determine one, otherwise distinct branches. Synchronization appends attributed observations, not blended memories. Restoration from an old journal is a reconstructed successor. Compromised yet correctly signed nodes are quarantined on behavior, not signature alone. Extracted hardware has no automatic ownership entitlement and no authority to terminate any conscious copy.

### Linking and capture

Local wired/optical couplings; nearby radio; an optional orbital or deep-space gateway supplies the shared delay-tolerant interface. The gateway is not a life-support component.

An intact captor can immobilize the lattice and remove its energy supply. The architecture protects some private state against casual sampling, not against indefinitely funded invasive analysis. A separated enclave is a more serious loss than a routine structural module.

The separated compute enclaves, rather than every module, set the privacy and continuity boundary.

### Finite resources and environmental envelope

Targets: 6,000 Wh input reserve, 150 W normal accounted load, 12 W essential load and 0.2 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 90 W, actuation/transport 20 W, sensing 10 W, circulation/chemistry/housekeeping 12 W, communications/security 8 W and repair allowance 10 W. Peak power target 600 W is not a continuous capability.

Derived energy-only normal horizon: 40.0 h. With no heat export, no external heating, heat capacity 30 kJ/K and allowed rise 20 K, the derived normal-load thermal limit is 1.11 h; the combined favorable bound is 1.11 h. At the selected preservation draw the combined favorable bound is 833 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 273–323 K; finite-refuge target 243–353 K. Intended pressure target 0–0.2 MPa; finite-refuge pressure target 0–1 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. Core temperature, not ambient temperature, governs the stated thermal ranges. Vacuum suitability assumes sealed components and a functioning radiative sink.

### Challenge outcome and research decision

The first central assumption to collapse is: Loss of all usable heat paths defeats the main survival wager even if most modules remain intact. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: A body made of individually sealed, interchangeable dry modules can lose local structure without losing the protected computational lineage. Strongest reason to reject: It gives up organism-like molecular regrowth and the ability to manufacture advanced electronics from raw terrain. Least-supported critical mechanism: Physical components are established individually; integrated autonomy and identity-preserving repair are extrapolated; full embodied AI capability is unknown.

First likely failure under the selected dependency ranking: Common manufacturing defect in seals. Minimum useful validation: Build a nonliving three-island electrical/thermal surrogate and compare measured hot spots against a resolved network model. Falsifying result: A representative lattice cannot preserve an intact journal while one power island and one bus route fail at the assumed essential load.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Add independently qualified manufacturing sources, more efficient compute hardware and replaceable thermal joints, without promising atom-by-atom self-reproduction.

Material self-healing is not the same as an autonomous detection-cleaning-closure-healing-assessment loop; the integration review is a constraint on this proposal, not its validation ([autonomous self-healing review](https://pmc.ncbi.nlm.nih.gov/articles/PMC12370171/)).

## P2 Rill: Generation 1

### Core wager and body

A hydrated repair layer can restore fine interfaces that discrete mechanical replacement handles poorly. It accepts narrow biochemical temperatures, oxygen demand and continuing nutrient/sterility burdens.

An 80 kg, approximately 1.5 m compliant scaffold contains a target one million 80 mg control-and-service parcels. Each parcel contains many ordinary biological cells plus sensors and channels; the parcel, not the enclosed cell, is the Omni-cell equivalent. A target 40 kg of retained water is included in the mass. Protected electronics support cognition; living material supports interfaces and repair.

A service parcel senses chemistry, carries fluid, performs low-level control and supports local repair. Molecular cells remain specialized. Reassignment changes which parcel supplies transport or repair within pre-existing channel constraints; it does not make every biological cell a neuron, pump and structural fiber simultaneously.

### Matrix, transport and cognition

Ordinary DNA maintains living cells; a separate authenticated digital specification governs parcel identity, permitted tissue renewal and private computational state. Biological information is not encrypted by calling it a genome lock.

Aqueous circulation carries nutrients, oxygen, waste and heat through a mechanically supported, redundantly routed channel network. A protected electronic core with two separately powered state witnesses controls consequential updates. Living parcels do not contain a complete mind. The core remains an acknowledged single-region vulnerability.

Wet rubble, repair-intensive shelters and contaminated-but-contained settings; unprotected vacuum, hot terrain and deep pressure are poor matches.

### Physiological constitution

A target 600 Wh of usable nutrient free energy sustains living parcels and 3,000 Wh of usable electrical storage runs pumps and cognition; these are non-substitutable inventories. Stored oxygen and carbon-dioxide capture give only a finite argon-resilience interval. Anaerobic maintenance is not assumed to sustain the full body.

#### Respiration and power

- **P2-RESP-1:** Living parcels consume a measured donor and oxygen; internal stores do not remove oxygen dependence.

- **P2-RESP-2:** Pump and compute loads have a separate electrical inventory.

- **P2-RESP-3:** Anoxia triggers reduced tissue activity and oxygen rationing rather than an unexplained alternate full-power metabolism.

- **P2-RESP-4:** Oxygen, carbon-dioxide capacity, substrate and ATP adequacy must all recover before tissue repair restarts.

#### Telomeres, copying and longevity

- **P2-LONG-1:** Chromosome ends and DNA damage are assessed together; telomere length alone does not authorize proliferation.

- **P2-LONG-2:** Tissue expansion is bounded by parcel volume, nutrients and local renewal permission.

- **P2-LONG-3:** Suspect lineages are isolated and replaced under supervised research assumptions rather than made immortal.

- **P2-LONG-4:** The digital identity record cannot be regenerated merely by growing fresh tissue.

#### Thermal regulation

- **P2-THERM-1:** Water carries heat to a protected exchanger; stagnant circulation creates local failure.

- **P2-THERM-2:** The living core remains within its selected narrow biochemical window.

- **P2-THERM-3:** Cooling and perfusion remain powered during workload reduction.

- **P2-THERM-4:** A damaged exchanger or hot ambient fluid leads to finite refuge, not permanent home operation.

#### Conversion and conservation

- **P2-CONV-1:** Oxidation consumes nutrients and oxygen and produces carbon dioxide, water, heat and waste.

- **P2-CONV-2:** Tissue regrowth consumes retained water and chemically suitable feedstock.

- **P2-CONV-3:** Electrical and chemical inventories are not counted twice.

- **P2-CONV-4:** Waste storage and filter saturation constrain closed operation even when energy remains.

The proposed service-life target is 5 years conditional on weekly fluid chemistry review; 3 months structural inspection. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P2-OBS-1, Perfusion-first sensing:** Outward motion decisions are conditioned on inward oxygen delivery and channel pressure, not merely an intact limb shape. Trigger: planned exertion. Target cost 1.33 W under the shared rule contract; other inputs: oxygen, pressure and flow records. False trigger or failure: bubbles or stagnant tissue falsely appearing supplied. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P2-OBS-2, Living/electronic disagreement:** Compare chemical viability markers with independent electronic temperature and power measurements. Trigger: repair request. Target cost 1.33 W under the shared rule contract; other inputs: two different measurement modalities. False trigger or failure: both modalities are miscalibrated by the same local condition. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P2-OBS-3, Consent-limited sampling:** Authorized researchers may inspect bounded parcels with recorded consent; refused sampling does not make extracted DNA unreadable. Trigger: sampling request. Target cost 1.33 W under the shared rule contract; other inputs: sample provenance and disclosed scope. False trigger or failure: physical removal exposes actual cellular chemistry. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P2-SEC-1, Two-ledger inheritance:** Tissue provenance and private digital identity remain separate ledgers with separate authorizations. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: cell-line record plus digital permission. False trigger or failure: a copied tissue parcel receives anatomy information, not core memories. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P2-SEC-2, Renewal permission envelope:** A parcel may renew only within its admitted compartment and resource allowance; this is a control hypothesis, not a demonstrated genetic containment circuit. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: parcel-level renewal bounds. False trigger or failure: a molecular escape from control remains an unresolved biosecurity risk. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P2-SEC-3, Witnessed repair enrollment:** New repair material enters a read-only observation period before it gains control authority. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: core plus independent service witnesses. False trigger or failure: false rejection can interrupt repair and must be recoverable without a remote issuer. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P2-DEP-1, Genome equals individual identity:** A dual DNA/digital construction record separates cellular heredity from computational identity. Departure affects dimension A; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P2-DEP-2, One tissue one permanent macroscopic role:** Service parcels reallocate transport and repair while cellular specialization remains. Departure affects dimension A; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P2-DEP-3, Exposed gas-exchange anatomy:** Protected internal gas and waste stores replace reliance on uninterrupted external breathing. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Living chemistry requires appropriate solvent, reactants and temperature; Proliferation remains bounded and damage-sensitive; Information is not replacement tissue.

### Repair, identity and autonomy

A target 5 kg dry-equivalent compatible feedstock allowance and retained water support limited interface repair. Nutrient and transport adequacy, lineage integrity and mechanical loading must be checked before regrowth counts as restored function. Replacing a lost compute core is reconstruction, not tissue regeneration. No cell-culture or genetic-construction procedure is specified.

Tissue replacement preserves identity only while the protected computational process continues. A detached living parcel is tissue, not a licensed mind. A split containing two complete cores would create branching continuations, not a mandatory winner. Reconnection preserves separate event histories. Restoring a prior core checkpoint is a successor. Correct tissue provenance does not excuse malicious control behavior. Ownership of a sample does not settle the moral status of any later conscious entity.

### Linking and capture

Electrical local sensing, short optical connections between service regions, and a protected radio interface; deep-space participation needs a dry external gateway.

A captor can exploit dependence on pumps, nutrients and gas management without defeating authentication. The protection objective is privacy and recorded consent, not a promise of escape.

Healthy-looking extracted tissue can reveal heredity without carrying the computational identity.

### Finite resources and environmental envelope

Targets: 3,600 Wh input reserve, 200 W normal accounted load, 40 W essential load and 5 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 70 W, actuation/transport 20 W, sensing 8 W, circulation/chemistry/housekeeping 60 W, communications/security 25 W and repair allowance 17 W. Peak power target 800 W is not a continuous capability.

Derived energy-only normal horizon: 10.0 h. With no heat export, no external heating, heat capacity 240 kJ/K and allowed rise 8 K, the derived normal-load thermal limit is 2.67 h; the combined favorable bound is 2.67 h. At the selected preservation draw the combined favorable bound is 107 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 295–310 K; finite-refuge target 285–315 K. Intended pressure target 0.08–0.15 MPa; finite-refuge pressure target 0.05–0.3 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. An 8 K lumped thermal margin is not a guarantee against local protein damage. Partial pressure and perfusion are independent constraints.

Normal operation allocates 60 W to living chemical maintenance and 140 W to electrical loads. The separate 600 Wh nutrient and 3,000 Wh electrical reserves therefore give 10 h and 21.4 h normal bounds; the minimum is used rather than pooling their energy. Essential mode assigns 25 W living and 15 W electrical, while preservation assigns 4 W living and 1 W electrical. The selected 1 kg oxygen and 1 kg carbon-dioxide capture allowances, at assumed 0.04 and 0.05 kg/h use, give 25.0 h and 20.0 h respectively. The same conservative gas/waste rates are retained in lower modes pending measurement, so their bound is 20.0 h. These rates are targets, not biological measurements, and neither chemical nor electrical energy can substitute for the other.

### Challenge outcome and research decision

The first central assumption to collapse is: Silent loss of perfusion defeats fine repair before a whole-body energy monitor necessarily detects it. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: A hydrated repair layer can restore fine interfaces that discrete mechanical replacement handles poorly. Strongest reason to reject: It accepts narrow biochemical temperatures, oxygen demand and continuing nutrient/sterility burdens. Least-supported critical mechanism: Cell maintenance and telomere biology have evidence; autonomous biohybrid body-wide repair is extrapolated or speculative and is not demonstrated here.

First likely failure under the selected dependency ranking: Perfusion interruption. Minimum useful validation: Use a nonliving perfusion phantom to validate transport, local oxygen-equivalent tracer delivery and exchanger behavior before considering living studies. Falsifying result: Representative service parcels cannot remain viable through the specified isolated maintenance interval while meeting the gas and waste budgets.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Reduce living volume and its basal load, improve nonliving perfusion redundancy, and establish evidence for bounded repair without loosening proliferation control.

Telomere-end maintenance is only part of cellular integrity and does not establish indefinite tissue life ([Cell telomere review](https://pmc.ncbi.nlm.nih.gov/articles/PMC8081271/)).

## P3 Mosaic: Generation 1

### Core wager and body

Many small, independently repairable reaction compartments can contain chemical failure better than one shared cytoplasm. It depends on a presently unbuilt translation/maintenance system and narrow solvent compatibility.

A 40 kg, approximately 0.5 m emulsion body has a target 100 million 0.4 mg compartments, each nominally around a millimeter in scale. Mineral walls and thin compliant membranes separate incompatible reactions. Mesoscale controller units supervise chemical compartments; full cognition in a molecular emulsion is not assumed.

An artificial compartment stores a bounded recipe, senses a local chemical state, exchanges ions and contributes to repair chemistry. It can switch among compatible pre-installed reactions. It cannot acquire arbitrary enzymes, structural competence or cognition merely by receiving a recipe. Whole-body function comes from bounded compartment cooperation.

### Matrix, transport and cognition

An HNA-like XNA information polymer is a research hypothesis for compartment instructions; exact monomer selection, catalyst fidelity and autonomous manufacture remain unknown. A dissimilar digital audit layer holds private identity and records authorized recipe versions.

Ion conduction, selective diffusion and short microfluidic paths; not every reactant may share a transport channel. Mesoscale electronic supervisors form a mesh; chemical compartments execute restricted maintenance roles. The chemistry is not claimed to implement a demonstrated general intelligence.

Controlled nonstandard chemical habitats and sealed repair chambers, not unrestricted dry desert, vacuum or hot industrial terrain.

### Physiological constitution

External electricity maintains ion gradients when available; sealed electrochemical reserves support isolated operation. Reaction free energies and membrane leakage set the unresolved true maintenance load.

#### Respiration and power

- **P3-RESP-1:** Ion gradients must be paid for by electrical or reaction free energy.

- **P3-RESP-2:** Incompatible redox pathways occupy separate compartments.

- **P3-RESP-3:** A gradient-collapse alarm reduces chemical workload before exhausting electrical reserve.

- **P3-RESP-4:** Restart verifies membrane selectivity and waste concentration before rebuilding gradients.

#### Telomeres, copying and longevity

- **P3-LONG-1:** No conventional telomere is assumed; finite templates have end integrity and copy-quality checks.

- **P3-LONG-2:** Recipe copying has a bounded compartment quota and cannot create absent catalysts.

- **P3-LONG-3:** A drifting compartment is disconnected from the recipe-admission network.

- **P3-LONG-4:** Replacing recipes cannot recover a lost private state history.

#### Thermal regulation

- **P3-THERM-1:** A selected aqueous-compatible core window binds membrane and catalyst performance.

- **P3-THERM-2:** Thin transport layers reduce gradient length but enlarge leak area.

- **P3-THERM-3:** Bulk thermal buffers do not excuse hot or chemically unstable interfaces.

- **P3-THERM-4:** Thermal recovery requires intact compartment boundaries, not temperature normalization alone.

#### Conversion and conservation

- **P3-CONV-1:** Each admitted reaction has a mass, charge and free-energy ledger.

- **P3-CONV-2:** Ion-pump losses are included in maintenance power.

- **P3-CONV-3:** Replacement packets require measured compatible precursors and solvent.

- **P3-CONV-4:** Waste accumulation ends closed-loop operation even when the recipe remains readable.

The proposed service-life target is 2 years conditional on daily chemistry checks; monthly reaction-packet review. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P3-OBS-1, Chemical balance witness:** Compare outward environmental chemistry with compartment inventories before admitting a reactant. Trigger: environmental intake proposal. Target cost 1.00 W under the shared rule contract; other inputs: mass and ionic-balance residuals. False trigger or failure: unidentified compounds or nonselective sensors. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P3-OBS-2, Gradient tomography:** Infer inward damage from multiple impedance and concentration observations rather than one bulk viability label. Trigger: unexpected leak current. Target cost 1.00 W under the shared rule contract; other inputs: spatial concentration and electrical estimates. False trigger or failure: ill-posed reconstruction hides a small failed compartment. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P3-OBS-3, Bounded recipe disclosure:** Reveal a consented reaction summary while withholding private supervisor state; molecular extraction can still expose templates. Trigger: external characterization. Target cost 1.00 W under the shared rule contract; other inputs: authorized recipe subset. False trigger or failure: a well-equipped analyst reads extracted polymers. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P3-SEC-1, Recipe admission proofs:** A supervisor authorizes a recipe only if the digital model and resource envelope agree. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: local supervisor authorization. False trigger or failure: validating a model does not establish the chemistry is safe. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P3-SEC-2, Split substrate records:** Chemical templates and private digital lineage are deliberately nonidentical records. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: physical XNA plus digital log. False trigger or failure: template theft remains possible without mind theft. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P3-SEC-3, Compartment challenge renewal:** A compartment must show current bounded function before rejoining the repair pool. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: local challenge records not a remote master key. False trigger or failure: measurement errors can falsely exclude useful repair compartments. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P3-DEP-1, DNA backbone monopoly:** An HNA-like XNA template is proposed instead of DNA for local hereditary instructions. Departure affects dimension A; support: Polymer information handling established in limited experiments; autonomous physiology speculative. This departs from a biological or engineering default, not a physical law.

- **P3-DEP-2, Open shared cytoplasm:** Mineral and membrane compartments enforce chemically distinct local rule sets. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P3-DEP-3, Replication as default recovery:** Damaged chemistry is replaced as admitted packets rather than unrestricted division. Departure affects dimension A; support: Speculative integration. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Charge and redox accounting for every compartment; Finite catalytic fidelity and bounded replication; Solvent and chemical stability are non-negotiable.

### Repair, identity and autonomy

A target 4 kg compatible packet inventory supplies membrane and reaction-medium replacement at an assumed 0.5 material yield. A damaged pocket is isolated before neighboring compartments receive its contents. Exact assembly energy and useful repair rate are unknown; the report does not specify synthesis, sequences or culture methods.

A supervisor lineage can continue while compartments are replaced. Two separated supervisor meshes must be treated as branches if both remain complete. Chemical similarity is not identity. Remote records reconcile as attributed claims. Rebuilding all supervisors from an old checkpoint creates a successor. Correct recipe signatures do not make corrupted chemistry trustworthy. Sample ownership does not settle the status of any independently conscious reconstruction.

### Linking and capture

Ionic/electrical local links feed an electronic boundary transducer; external radio/optical networking is gateway-mediated.

The analyst may learn polymer chemistry and compartment recipes; the architecture cannot promise molecular unreadability. Solvent disruption or controller extraction is a more direct failure than defeating template cryptography.

A copied XNA template does not imply a functioning catalyst system or a restored supervisor lineage.

### Finite resources and environmental envelope

Targets: 2,400 Wh input reserve, 100 W normal accounted load, 20 W essential load and 2 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 35 W, actuation/transport 12 W, sensing 6 W, circulation/chemistry/housekeeping 25 W, communications/security 10 W and repair allowance 12 W. Peak power target 300 W is not a continuous capability.

Derived energy-only normal horizon: 24.0 h. With no heat export, no external heating, heat capacity 100 kJ/K and allowed rise 10 K, the derived normal-load thermal limit is 2.78 h; the combined favorable bound is 2.78 h. At the selected preservation draw the combined favorable bound is 139 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 288–308 K; finite-refuge target 278–318 K. Intended pressure target 0.08–0.2 MPa; finite-refuge pressure target 0.02–1 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. All chemical ranges are targets pending membrane/catalyst selection; an unknown glass transition or denaturation threshold cannot be inferred from bulk temperature.

### Challenge outcome and research decision

The first central assumption to collapse is: If membrane selectivity fails, compartmentalization becomes a correlated chemical transport failure. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: Many small, independently repairable reaction compartments can contain chemical failure better than one shared cytoplasm. Strongest reason to reject: It depends on a presently unbuilt translation/maintenance system and narrow solvent compatibility. Least-supported critical mechanism: XNA information storage is supported in limited systems; autonomous XNA repair and whole-body integration remain speculative.

First likely failure under the selected dependency ranking: No autonomous XNA physiology demonstrated. Minimum useful validation: Simulate coupled diffusion and energy balance, then compare with a nonliving ionic-compartment phantom. Falsifying result: A nonliving compartment array cannot preserve separations under the proposed gradient and thermal loads for the intended maintenance interval.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Narrow the reaction alphabet, demonstrate bounded catalyst maintenance and replace ambitious chemical cognition with measurable supervisory roles.

Limited experimental XNA storage and evolution support researching this substrate, not asserting an autonomous XNA body ([MRC LMB XNA research](https://www2.mrc-lmb.cam.ac.uk/groups/ph1/xna.html)).

## P4 Pelagic: Generation 1

### Core wager and body

Accommodating external pressure in distributed oil-filled modules avoids one enormous pressure vessel and its single catastrophic boundary. It gives up dry-terrain competence, high-bandwidth untethered networking and cheap precision servicing.

A 120 kg, approximately 1.2 m neutrally trimmed body contains a target 20,000 6 g service modules within a compliant cage. Electronics intended for pressure accommodation are conceptually immersed in compatible insulating fluid; components not qualified for ambient pressure retain local housings. The design does not infer pressure tolerance from incompressibility alone.

Modules sense pressure and chemistry, regulate local buoyancy or actuation, conduct energy and participate in docking. Their functions depend on installed components. A module can exchange roles within its class, while cognitive and energy components remain heterogeneous.

### Matrix, transport and cognition

Digital controller manifests plus service histories encode reconstruction; no biological genome is required. Material compatibility and seal records are part of the admitted phenotype.

Hydraulic power, insulating-fluid pressure balance and electrical paths are separated from environmental seawater; heat transfers through wetted exchangers. One protected mission controller and multiple bounded local controllers support offline navigation. A second protected state recorder provides restoration information but is not declared a second simultaneous mind.

Cold deep water and flooded subsurface terrain; pressure and chemistry must be qualified separately. Vacuum and hot dry ground are not home environments.

### Physiological constitution

A stored hydrogen/oxygen fuel-cell concept is primary; a battery bridges interruptions. At the report boundary, reserve energy is preconversion fuel free energy, with an assumed 0.5 electrical conversion fraction and unused energy treated as heat.

#### Respiration and power

- **P4-RESP-1:** Hydrogen and oxygen inventories constrain fuel-cell operation; ocean water is not fuel.

- **P4-RESP-2:** The electrical fraction of fuel energy and conversion heat are accounted separately.

- **P4-RESP-3:** Reactant starvation transfers essential control to the bridge reserve only if its independent inventory is available.

- **P4-RESP-4:** Reactivation requires reactants, water-product management and qualified pressure state.

#### Telomeres, copying and longevity

- **P4-LONG-1:** Module wear and pressure cycles replace telomere age.

- **P4-LONG-2:** New pressure modules must pass compatibility and provenance checks.

- **P4-LONG-3:** Replacement never assumes unlimited internal fabrication.

- **P4-LONG-4:** Restoring a controller from the recorder is distinguished from uninterrupted operation.

#### Thermal regulation

- **P4-THERM-1:** Wetted exchangers require flow and temperature difference.

- **P4-THERM-2:** Reactant conversion heat joins electrical dissipation at the body boundary.

- **P4-THERM-3:** Fouling reduces exchanger performance and is modeled as lost conductance.

- **P4-THERM-4:** Leaving water invalidates the home heat-transfer model and triggers load reduction.

#### Conversion and conservation

- **P4-CONV-1:** Both fuel and oxidant mass are carried or replenished explicitly.

- **P4-CONV-2:** Water product occupies storage or requires a controlled discharge boundary.

- **P4-CONV-3:** Hydraulic losses and buoyancy-control work count as load.

- **P4-CONV-4:** Lost parts require compatible corrosion-qualified matter, not arbitrary seabed sediment.

The proposed service-life target is 10 years conditional on 3 months wet-interface review; annual major service. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P4-OBS-1, Pressure-rate witness:** Outward route changes require both pressure magnitude and pressure-rate confidence. Trigger: depth or buoyancy change. Target cost 1.67 W under the shared rule contract; other inputs: independent pressure estimates. False trigger or failure: blocked ports or common calibration error. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P4-OBS-2, Leak-localization consensus:** Compare inward fluid conductivity, insulation and inventory before deciding which branch to isolate. Trigger: unexpected electrical or fluid loss. Target cost 1.67 W under the shared rule contract; other inputs: three leak indicators. False trigger or failure: a leak crosses several compartments before localization. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P4-OBS-3, Acoustic restraint:** Transmit only bounded consented telemetry; acknowledge that acoustic emissions reveal position and behavior. Trigger: external message request. Target cost 1.67 W under the shared rule contract; other inputs: message and duty-cycle budget. False trigger or failure: physical tracking and traffic analysis remain possible. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P4-SEC-1, Docking provenance:** Wet-docked modules enter restricted diagnostic status before motion authority. Trigger: component admission, protected request or recovery. Target cost 1.00 W under the shared rule contract; other inputs: local mission controller authorization. False trigger or failure: stolen docking hardware still exposes component designs. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P4-SEC-2, Pressure-history attestation:** A module's admission includes exposure history as well as signed software identity. Trigger: component admission, protected request or recovery. Target cost 1.00 W under the shared rule contract; other inputs: material state plus manifest. False trigger or failure: an authentic but fatigue-damaged part is refused. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P4-SEC-3, Offline acoustic epochs:** Acoustic identity uses local epoch records and does not require continuous surface contact. Trigger: component admission, protected request or recovery. Target cost 1.00 W under the shared rule contract; other inputs: store-and-forward credentials. False trigger or failure: recovery requires comparison, not trust in an old surface timestamp. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P4-DEP-1, Molecular hereditary requirement:** Versioned digital/material manifests carry construction information. Departure affects dimension A; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P4-DEP-2, Rigid universal pressure hull:** Distributed pressure accommodation replaces one body-sized vessel. Departure affects dimension B; support: Extrapolated and component-dependent. This departs from a biological or engineering default, not a physical law.

- **P4-DEP-3, Ambient-air energy metabolism:** Stored donor and oxidant replace atmospheric respiration. Departure affects dimension A; support: Established reaction; extrapolated physiology. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Pressure compatibility is component-specific; Fuel, oxidant and reaction-product mass balance; No instantaneous long-range underwater communication.

### Repair, identity and autonomy

A target 8 kg of corrosion-qualified modules supports wet docking and local exchange. Seal replacement and cleaning require finite consumables. Cannibalizing buoyancy or structure may save control but sacrifice surfacing ability. The current design cannot manufacture precision electronics from dissolved minerals.

Continuity follows the active controller process and its journal, not fluid or hull persistence. Splits without a complete controller are service fragments; a complete duplicated controller is a branch. Reconnection preserves source attribution. Rebuilding a lost controller is restoration. An authentic pressure module with malicious local behavior loses authority. Possession of a removed component is not proof of ownership of memories.

### Linking and capture

Local wired links and short optical water links; longer acoustic messaging to a surface buoy; the buoy provides planetary/orbital or deep-space radio. Surfacing and a buoy are infrastructure options, not assumed always available.

Physical restraint, isolation from a usable fluid heat sink and reactant denial defeat operation without revealing secrets. A captor may map internal hardware through sustained access.

The surface gateway can be lost without stopping local control, but global links then disappear.

### Finite resources and environmental envelope

Targets: 10,000 Wh input reserve, 300 W normal accounted load, 25 W essential load and 0.5 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 100 W, actuation/transport 80 W, sensing 15 W, circulation/chemistry/housekeeping 35 W, communications/security 30 W and repair allowance 40 W. Peak power target 1000 W is not a continuous capability.

Derived energy-only normal horizon: 16.7 h. With no heat export, no external heating, heat capacity 120 kJ/K and allowed rise 15 K, the derived normal-load thermal limit is 0.83 h; the combined favorable bound is 0.83 h. At the selected preservation draw the combined favorable bound is 500 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 275–303 K; finite-refuge target 271–323 K. Intended pressure target 0.1–60 MPa; finite-refuge pressure target 0.05–100 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. The 60 MPa home-pressure target is a research goal, not a qualified rating; the hot and cold ends require component-specific compatibility.

The 10,000 Wh fuel reserve is preconversion energy. At target electrical fraction 0.5 it yields 5,000 Wh to the bus and produces conversion heat in addition to electrical dissipation. At 300 W bus load the modeled total heat is 600 W. The separately proposed bridge battery has no credited capacity until independently specified.

### Challenge outcome and research decision

The first central assumption to collapse is: A hidden pressure-sensitive component defeats pressure accommodation despite intact outer modules. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: Accommodating external pressure in distributed oil-filled modules avoids one enormous pressure vessel and its single catastrophic boundary. Strongest reason to reject: It gives up dry-terrain competence, high-bandwidth untethered networking and cheap precision servicing. Least-supported critical mechanism: Underwater robotics and fuel cells are established; the pressure-balanced autonomous physiology and repair system are extrapolated.

First likely failure under the selected dependency ranking: Component-specific pressure failure. Minimum useful validation: Use component stress models and nonliving pressure-equivalent material tests under specialist facilities, not living exposure. Falsifying result: Distributed modules fail at the proposed pressure-rate/chemistry combination despite acceptable static-pressure calculations.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Qualify more components under pressure, reduce buoy dependency and add independently serviceable thermal paths.

The selected fuel-cell concept needs supplied fuel and oxygen and yields heat as well as electricity ([DOE fuel cells](https://www.energy.gov/cmei/fuels/fuel-cells)).

## P5 Heliotile: Generation 1

### Core wager and body

A broad, low-duty-cycle body can sustain long deployment from intermittent sunlight while keeping vulnerable electronics sheltered. It gives up high mobility, concealment and reliable energy autonomy in shade, dust or permanent darkness.

A 30 kg deployable mat has a target 12 square meters of exposed collector area distributed across 3,000 nominal 10 g tiles, each around 6 cm across when flat. A 3 kg structural and repair allowance is included. Some tiles collect light, some store energy, and some carry sensing or computation.

Tiles sense strain, irradiance and temperature, route energy and negotiate bounded local role changes. The body is collective and heterogeneous; not every tile can harvest, store, compute and repair at once. The protected edge strip hosts the computational lineage.

### Matrix, transport and cognition

Digital tile manifests and a checkpointed identity journal govern reconstruction. Photovoltaic material is not a hereditary polymer, and replacing a tile does not copy a mind.

A surface electrical mesh and thin conductive spreaders replace circulation; folds create shading and thermal-contact risks. A protected edge compute strip schedules a low-duty mission workload. Distributed tile controllers cannot reconstruct full cognition without its private state.

Sunlit arid surfaces, roofs, open orbital platforms and low-mobility surveying sites; deep ocean and sealed darkness are adverse cases.

### Physiological constitution

Photovoltaics supply primary electrical input; a sealed battery bridges night or shading. The selected solar example uses area, irradiance, conversion efficiency and illuminated duty fraction explicitly.

#### Respiration and power

- **P5-RESP-1:** Light input is environmental energy, not an intrinsic metabolic reserve.

- **P5-RESP-2:** Darkness transfers load to the battery without changing the requirement for energy.

- **P5-RESP-3:** Workload and communication duty follow admitted energy surplus.

- **P5-RESP-4:** Recovery requires a positive measured energy margin after thermal and authentication costs.

#### Telomeres, copying and longevity

- **P5-LONG-1:** Tile degradation, cracks and cycle exposure replace telomere age.

- **P5-LONG-2:** New tiles prove their electrical behavior before joining the power mesh.

- **P5-LONG-3:** No tile is authorized to grow collector area without matter and structural accounting.

- **P5-LONG-4:** Edge-journal survival is separate from collector survival.

#### Thermal regulation

- **P5-THERM-1:** Absorbed sunlight that is not exported becomes heat.

- **P5-THERM-2:** Folds and occluded radiators are included in the view-factor model.

- **P5-THERM-3:** A hot mat may reduce collection even while sunlight is abundant.

- **P5-THERM-4:** Thermal recovery requires adequate sky view or a conductive sink, not just electrical shedding.

#### Conversion and conservation

- **P5-CONV-1:** Solar input equals area times irradiance before conversion losses.

- **P5-CONV-2:** Battery charging and discharge losses cannot be claimed as recovered heat-to-electricity without a cycle.

- **P5-CONV-3:** Replacing a tile consumes matched material and bonding allowance.

- **P5-CONV-4:** Dust removal consumes time, energy and possibly cleaning matter.

The proposed service-life target is 15 years conditional on monthly surface inspection; 6 months electrical review. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P5-OBS-1, Flux-before-work:** Outward task planning uses measured irradiance and shadow history rather than time-of-day assumptions. Trigger: new workload. Target cost 0.67 W under the shared rule contract; other inputs: local flux and forecast uncertainty. False trigger or failure: sudden occlusion or dust. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P5-OBS-2, Fold thermal witness:** Compare inward hot-spot observations across folds with a thermal view estimate. Trigger: fold or deployment change. Target cost 0.67 W under the shared rule contract; other inputs: spatial temperature sampling. False trigger or failure: a hidden fold becomes a thermal trap. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P5-OBS-3, Honest silhouette:** Reduce unnecessary telemetry but accept visible collector geometry and thermal emission; consented tests may measure both. Trigger: observation request. Target cost 0.67 W under the shared rule contract; other inputs: declared emissions and logs. False trigger or failure: no claim of visual or infrared invisibility. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P5-SEC-1, Tile enrollment:** A new collector receives power-routing authority only after bounded characterization. Trigger: component admission, protected request or recovery. Target cost 0.33 W under the shared rule contract; other inputs: local edge controller. False trigger or failure: copied tile construction does not carry edge memories. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P5-SEC-2, Reserve-separated identity:** Private state has an energy reserve not spendable by collector optimization. Trigger: component admission, protected request or recovery. Target cost 0.33 W under the shared rule contract; other inputs: separate protected storage domain. False trigger or failure: reserve isolation itself may fail. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P5-SEC-3, Harvest-independent credentials:** Authentication uses local records and does not expire solely because weather prevents contact. Trigger: component admission, protected request or recovery. Target cost 0.33 W under the shared rule contract; other inputs: local history with revocable peer permissions. False trigger or failure: a long-isolated peer is not allowed to overwrite current identity. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P5-DEP-1, Genome-driven construction:** Digital tile recipes replace DNA as construction heredity. Departure affects dimension A; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P5-DEP-2, Compact body geometry:** A broad folding collector replaces a compact animal-like body. Departure affects dimension B; support: Established geometry; extrapolated physiology. This departs from a biological or engineering default, not a physical law.

- **P5-DEP-3, Continuous high-power metabolism:** Scheduled useful work follows environmental surplus rather than a fixed active rate. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Finite photon flux and conversion loss; No guaranteed energy from darkness; Collector area and physical visibility have costs.

### Repair, identity and autonomy

A target 3 kg matched tile-and-bond stock supports local replacement at an assumed 0.7 useful yield. Delaminated collection zones may be isolated but their area is lost until repaired. Raw sand is not assumed to become a solar cell on command.

The live edge journal anchors continuity. Detached collector tiles carry little personal state. Two complete edge strips create branches rather than one magically synchronized person. Network updates append attributed claims. A restored edge checkpoint is a successor after destruction. Authentic but misreporting collectors lose routing authority. Material ownership does not transfer a private identity by default.

### Linking and capture

Short optical tile links, nearby radio and a deployable directional gateway; high-rate external communication is scheduled from energy surplus.

A simple shadowed enclosure can end energy harvesting. A broad visible body is easy to localize; the design does not solve captivity merely by being sunlight-powered.

Darkness defeats harvest even when atmosphere, temperature and network authentication remain normal.

### Finite resources and environmental envelope

Targets: 3,000 Wh input reserve, 80 W normal accounted load, 8 W essential load and 0.1 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 40 W, actuation/transport 5 W, sensing 8 W, circulation/chemistry/housekeeping 6 W, communications/security 10 W and repair allowance 11 W. Peak power target 240 W is not a continuous capability.

Derived energy-only normal horizon: 37.5 h. With no heat export, no external heating, heat capacity 24 kJ/K and allowed rise 25 K, the derived normal-load thermal limit is 2.08 h; the combined favorable bound is 2.08 h. At the selected preservation draw the combined favorable bound is 1667 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 263–323 K; finite-refuge target 233–353 K. Intended pressure target 0–0.2 MPa; finite-refuge pressure target 0–0.5 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. The ranges refer to protected electronics; collector coatings, storage chemistry and bonded joints may impose tighter limits.

The selected 12 m² collector, 500 W/m² illumination, 0.2 conversion fraction and 0.25 illuminated duty yield 1200 W instantaneous and 300 W mean electrical input. The mean surplus is 220 W before storage, cleaning, pointing and thermal penalties. In darkness it is zero; the 5% duty stress produces a deficit at the selected normal load.

### Challenge outcome and research decision

The first central assumption to collapse is: Loss of illuminated area turns a long-duration harvesting argument into a short battery-runtime problem. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: A broad, low-duty-cycle body can sustain long deployment from intermittent sunlight while keeping vulnerable electronics sheltered. Strongest reason to reject: It gives up high mobility, concealment and reliable energy autonomy in shade, dust or permanent darkness. Least-supported critical mechanism: Photovoltaics are established; autonomous self-repairing embodied tile cognition is extrapolated and full identity capacity is unknown.

First likely failure under the selected dependency ranking: Long darkness. Minimum useful validation: Compare a nonliving mat energy/temperature model with measured irradiance and fold geometry under benign conditions. Falsifying result: Net daily harvest after thermal, cleaning and storage losses cannot support the selected normal workload.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Add better low-flux workload scheduling, replaceable dust barriers and independent edge-state witnesses without assuming uninterrupted sunlight.

Environmental heat inputs, view factors and finite heat rejection must accompany solar electrical calculations ([NASA thermal-control guidance](https://www.nasa.gov/wp-content/uploads/2026/05/7-soa-thermal-2026-final.pdf?emrc=6ae1e775de967)).

## P6 Scatterweave: Generation 1

### Core wager and body

A single local disaster need not eliminate a geographically spread active lineage. It accepts coordination overhead, incomplete local capability and unresolved branching identity during partitions.

A 50 kg assembly comprises a target 500 sealed 100 g nodules, nominally a few centimeters across. Some provide energy or locomotion, others protected compute and state storage. Dispersion is within authorized deployment boundaries; there is no uncontrolled environmental self-replication.

A nodule senses, computes bounded local policy, stores energy, authenticates neighbors and may move or dock. Full embodied function requires a sufficient connected set of heterogeneous nodules. Every nodule is more capable than a passive grain, but none is a miniature complete person by default.

### Matrix, transport and cognition

Erasure-coded digital journals and nodule manifests store construction and identity data separately. Coding increases recoverability but is not encryption and does not guarantee privacy if enough shares are captured.

Contact power exchange when docked and independent reserves when dispersed; radio or short optical messages carry observations, not compulsory real-time state. Federated local control supports bounded autonomous branches. A target recovery policy needs sufficient authorized state shares; partitions cannot simultaneously guarantee one global writer and unrestricted local continuation.

Distributed surveying, fractured rubble and intermittent access regions within an authorized bounded site; dense shielding, deep water and mass-confinement defeat the link assumptions.

### Physiological constitution

Independent nodule batteries are primary; authenticated docks recharge them. Transporting, locating and gathering nodules consume energy that a monolithic body would not spend.

#### Respiration and power

- **P6-RESP-1:** Each nodule has its own finite battery ledger.

- **P6-RESP-2:** Aggregate reserve cannot power an isolated empty nodule without a physical transfer path.

- **P6-RESP-3:** Coordination duty is reduced before individual state-preservation reserves are spent.

- **P6-RESP-4:** Reassembly verifies both energy availability and lineage compatibility.

#### Telomeres, copying and longevity

- **P6-LONG-1:** Nodule cycle and exposure logs replace telomeres.

- **P6-LONG-2:** A new nodule gains no historical identity merely by matching a hardware identifier.

- **P6-LONG-3:** Replacement is capped by admitted physical stock and local deployment authorization.

- **P6-LONG-4:** Recovered shares can reconstruct information but not prove a prior subject resumed.

#### Thermal regulation

- **P6-THERM-1:** Heat balances apply to each nodule, not only the average body.

- **P6-THERM-2:** A well-cooled nodule cannot absorb another's heat without a transfer path.

- **P6-THERM-3:** Buried or enclosed nodules use lower power than exposed ones.

- **P6-THERM-4:** Thermal recovery does not automatically reconcile divergent cognitive branches.

#### Conversion and conservation

- **P6-CONV-1:** Nodule energy transfers pay connector and conversion losses.

- **P6-CONV-2:** Recovery coding consumes storage and transmission capacity.

- **P6-CONV-3:** Gathering physical mass requires locomotion and cannot be replaced by message delivery.

- **P6-CONV-4:** Missing nodules reduce both state redundancy and physical capability.

The proposed service-life target is 10 years conditional on 3 months nodule accounting; annual storage review. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P6-OBS-1, Independent local witness:** Outward claims are tagged with nodule origin, age and uncertainty before fusion. Trigger: received observation. Target cost 2.00 W under the shared rule contract; other inputs: source-attributed records. False trigger or failure: many compromised nodules can fabricate apparent consensus. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P6-OBS-2, Per-nodule health:** Inward safety decisions use local temperature and reserve, not an aggregate average. Trigger: local load request. Target cost 2.00 W under the shared rule contract; other inputs: per-node inventories. False trigger or failure: a disconnected nodule cannot be assessed remotely. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P6-OBS-3, Disclosure budget by quorum:** External diagnostics reveal bounded aggregate health only with local consent; radio traffic still reveals activity. Trigger: external query. Target cost 2.00 W under the shared rule contract; other inputs: share-independent health summaries. False trigger or failure: enough captured shares expose sensitive state. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P6-SEC-1, Threshold state custody:** Private reconstruction state is distributed with a declared threshold and availability cost. Trigger: component admission, protected request or recovery. Target cost 1.33 W under the shared rule contract; other inputs: local share custodians. False trigger or failure: theft of enough shares defeats the privacy boundary. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P6-SEC-2, Identity is not a radio address:** New or returning nodules must prove authorized history rather than matching an identifier. Trigger: component admission, protected request or recovery. Target cost 1.33 W under the shared rule contract; other inputs: per-nodule history records. False trigger or failure: honest history can coexist with malicious current behavior. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P6-SEC-3, Partition-aware enrollment:** Offline branches cannot silently overwrite one another when they meet. Trigger: component admission, protected request or recovery. Target cost 1.33 W under the shared rule contract; other inputs: branch-qualified authorization. False trigger or failure: false conflict may strand useful nodules and reduce recovery capacity. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P6-DEP-1, Molecular hereditary encoding:** Erasure-coded digital lineage replaces a molecular genome. Departure affects dimension A; support: Established coding; extrapolated embodiment. This departs from a biological or engineering default, not a physical law.

- **P6-DEP-2, Contiguous anatomy:** A body can consist of bounded spatially separated nodules. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P6-DEP-3, One synchronized cognitive present:** Qualified branches may remain autonomous with explicit identity divergence. Departure affects dimension B; support: Engineering policy, subjective continuity unknown. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Finite signal propagation and partition limits; No unauthorized replication or unbounded deployment; No branch may erase another's history solely by majority vote.

### Repair, identity and autonomy

A target 2 kg replacement-nodule stock provides limited recovery. The body can gather surviving modules or admit qualified replacements; it cannot transmit missing mass. Lost state shares, inaccessible terrain and depleted isolated nodes create recovery costs not captured by aggregate battery size.

Gradual nodule replacement can preserve an active local lineage. Fragmentation is the central hard case: two sufficient subsets may become separate continuations. Reconnection creates a federation of attributed histories, not involuntary mind fusion. Restoration from coding is reconstruction. Compromised authentic nodules are restricted by behavior. Any conscious branch is not disposable property merely because it lacks a majority.

### Linking and capture

Opportunistic RF/optical local networking, delayed contact routing and occasional directional gateway contact; no continuous global consensus is required for basic local control.

Dispersal can reduce single-location loss before capture but cannot rescue nodules already sealed together. A patient captor can gather sufficient state shares or prevent reassembly.

Pre-existing geographic separation matters; hypothetical escape after total confinement is not counted.

### Finite resources and environmental envelope

Targets: 5,000 Wh input reserve, 180 W normal accounted load, 18 W essential load and 0.3 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 60 W, actuation/transport 50 W, sensing 30 W, circulation/chemistry/housekeeping 12 W, communications/security 10 W and repair allowance 18 W. Peak power target 900 W is not a continuous capability.

Derived energy-only normal horizon: 27.8 h. With no heat export, no external heating, heat capacity 25 kJ/K and allowed rise 25 K, the derived normal-load thermal limit is 0.96 h; the combined favorable bound is 0.96 h. At the selected preservation draw the combined favorable bound is 579 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 263–323 K; finite-refuge target 233–353 K. Intended pressure target 0–0.2 MPa; finite-refuge pressure target 0–0.5 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. No whole-body home range is valid if individual nodes have different boundary conditions. Small nodes can fail earlier than the aggregate lumped model predicts.

### Challenge outcome and research decision

The first central assumption to collapse is: If dispersed components cannot ever physically reunite or communicate, aggregate resilience no longer supports one recoverable body. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: A single local disaster need not eliminate a geographically spread active lineage. Strongest reason to reject: It accepts coordination overhead, incomplete local capability and unresolved branching identity during partitions. Least-supported critical mechanism: Distributed storage and robotics have evidence; distributed personal continuity and autonomous body reconstitution remain unknown or speculative.

First likely failure under the selected dependency ranking: Partition creates identity divergence. Minimum useful validation: Run a discrete-event partition and inventory model, then a nonliving small-nodule bench demonstration. Falsifying result: The proposed recovery policy loses useful active state under benign partitions or requires continuous communication to preserve local autonomy.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Test lower-overhead branch reconciliation, diversify firmware and validate bounded recovery behavior without using uncontrolled replication.

Store-and-forward networking accommodates interrupted links, not real-time global mental synchronization ([NASA DTN](https://www.nasa.gov/communicating-with-missions/delay-disruption-tolerant-networking/)).

## P7 Stillglass: Generation 1

### Core wager and body

Giving up continuous active operation can greatly reduce reserve consumption during long hostile intervals. It accepts blind intervals, uncertain biological revival and unresolved subjective continuity across dormancy.

A 20 kg body contains a target 2,000 10 g sealed pods, nominally around two centimeters in scale. Dry archives and optional hydrated repair elements are separated. The baseline is a nonliving preservation system; proposed living dry-state repair remains speculative rather than a demonstrated revival capability.

A pod senses selected hazards, keeps a bounded archive, budgets its reserve and participates in slow repair when active. During deep preservation it does not sense continuously or conduct full cognition. The design refuses to call an inactive archive an awake universally capable cell.

### Matrix, transport and cognition

Ordinary DNA may specify optional repair elements, while error-checked digital archives carry private state and assembly instructions. Neither DNA nor stored bytes proves personal continuity after complete shutdown.

Short sealed microfluidic paths operate only in hydrated repair windows; dry-state preservation relies on static encapsulation rather than circulation. One active seed journal plus dissimilar read-only archives. Dormancy stops active cognition in the selected model; no subjective persistence is claimed.

Long storage, intermittent resource access and slow surveying where delayed response is acceptable; fast threats and hot humid settings are difficult.

### Physiological constitution

A battery supports short work periods and a low-power supervisory timer. A target 0.01 W dormancy draw is an aspirational system budget, not evidence that living material or an AI can remain conscious at that power.

#### Respiration and power

- **P7-RESP-1:** Awake operation consumes ordinary stored energy; no power is obtained from being dormant.

- **P7-RESP-2:** Deep preservation suspends function rather than inventing oxygen-free full metabolism.

- **P7-RESP-3:** A wake request is admitted only when energy and thermal reserves can support assessment.

- **P7-RESP-4:** Revival failure is recorded as loss, not relabeled as longer dormancy.

#### Telomeres, copying and longevity

- **P7-LONG-1:** Optional living elements retain DNA end-protection and damage concerns.

- **P7-LONG-2:** Archive checks track physical corruption and write history instead of assuming timeless information.

- **P7-LONG-3:** A pod cannot clone the entire lineage without separate authorization and state.

- **P7-LONG-4:** Replacing every active component from archives is reconstruction.

#### Thermal regulation

- **P7-THERM-1:** Dry-state stability depends on actual formulation, humidity and temperature.

- **P7-THERM-2:** A low power draw slows self-heating but does not stop heat from a hot environment.

- **P7-THERM-3:** Wake scheduling reserves energy for thermal equilibration.

- **P7-THERM-4:** Crossing an unmeasured glass or phase transition is an unresolved failure condition.

#### Conversion and conservation

- **P7-CONV-1:** Dormancy conserves stored free energy but does not create it.

- **P7-CONV-2:** Rehydration consumes water and incurs transport and recovery costs.

- **P7-CONV-3:** Readback and error correction consume power and may not repair chemical destruction.

- **P7-CONV-4:** Replacement pods require compatible mass and preserved readable instructions.

The proposed service-life target is 30 years conditional on annual archival audit; every wake cycle verification. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P7-OBS-1, Sparse witness schedule:** Outward sensing is explicitly sampled; report the maximum unobserved interval instead of claiming vigilance. Trigger: scheduled wake. Target cost 0.33 W under the shared rule contract; other inputs: sample time and reserve. False trigger or failure: events wholly inside a blind interval. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P7-OBS-2, Archive cross-read:** Inward readback compares dissimilar archives before accepting a wake state. Trigger: wake assessment. Target cost 0.33 W under the shared rule contract; other inputs: integrity and provenance checks. False trigger or failure: common radiation or chemical damage corrupts all records. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P7-OBS-3, Dormancy transparency:** Tell authorized observers which functions are inactive; no signal is not proof of invulnerability or death. Trigger: research request. Target cost 0.33 W under the shared rule contract; other inputs: declared active/dormant state. False trigger or failure: external observer cannot infer unmeasured subjective status. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P7-SEC-1, Wake authority separation:** The wake channel cannot authorize rewriting private identity. Trigger: component admission, protected request or recovery. Target cost 0.17 W under the shared rule contract; other inputs: local preserved policy. False trigger or failure: a captured pod may still be physically read. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P7-SEC-2, Archive lineage custody:** Private archives are separate from ordinary repair recipes. Trigger: component admission, protected request or recovery. Target cost 0.17 W under the shared rule contract; other inputs: read-only lineage records. False trigger or failure: enough intact archives permit unauthorized duplication. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P7-SEC-3, No remote expiry death:** Long link loss does not expire permission to preserve local state. Trigger: component admission, protected request or recovery. Target cost 0.17 W under the shared rule contract; other inputs: offline local authority. False trigger or failure: stale peers require later reconciliation without forced rollback. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P7-DEP-1, Heredity as one living genome:** A dual molecular/digital archive separates repair instructions from identity state. Departure affects dimension A; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P7-DEP-2, Continuous metabolism as survival criterion:** Preservation is an explicitly separate success state, not continuous operation. Departure affects dimension B; support: Engineering policy; revival speculative. This departs from a biological or engineering default, not a physical law.

- **P7-DEP-3, Continuous whole-body perfusion:** Dry encapsulation replaces circulation during preservation. Departure affects dimension A; support: Limited analogies established; integration speculative. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Preserved information needs a physical stable medium; Dormancy is not active awareness; Finite wake energy and bounded reconstruction.

### Repair, identity and autonomy

A target 2 kg pod stock supports substitution; a selected 0.6 material yield leaves large losses. Planned wake windows inspect damage before repair. Dry-state analogies do not establish arbitrary body revival, autonomous biological repair or decades of retained personal continuity.

While active, continuity follows the seed process. Dormancy is a gap in active computation; its interpretation remains open. Fragmented complete archives can generate several successor branches. Reconnection never silently blends their memories. Reconstruction after seed loss is restoration. A correctly preserved but maliciously changed archive is not trusted. A conscious revived copy deserves separate ethical consideration.

### Linking and capture

Wake-window short optical or wired contact; burst radio to a nearby gateway; interplanetary messaging is delayed by both propagation and scheduled inactivity.

An adversary may keep pods below wake-energy availability or collect archives. Preservation reduces expenditure, not the ability to resist physical removal.

An inactive archive cannot consent anew, detect every intervention or prove a continuing subjective experience.

### Finite resources and environmental envelope

Targets: 2,000 Wh input reserve, 40 W normal accounted load, 2 W essential load and 0.01 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 20 W, actuation/transport 2 W, sensing 3 W, circulation/chemistry/housekeeping 5 W, communications/security 4 W and repair allowance 6 W. Peak power target 120 W is not a continuous capability.

Derived energy-only normal horizon: 50.0 h. With no heat export, no external heating, heat capacity 20 kJ/K and allowed rise 20 K, the derived normal-load thermal limit is 2.78 h; the combined favorable bound is 2.78 h. At the selected preservation draw the combined favorable bound is 11,111 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 278–303 K; finite-refuge target 253–323 K. Intended pressure target 0–0.2 MPa; finite-refuge pressure target 0–0.5 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. The dry-state refuge range is a provisional packaging target; actual biochemical thresholds and glass transitions are unknown.

The long preservation number is especially fragile: the selected 0.01 W total draw excludes no required load by permission, but no implementation demonstrates it. Self-discharge, periodic sensing, archive readback and physical aging may dominate. It is not a consciousness-power estimate.

### Challenge outcome and research decision

The first central assumption to collapse is: If preserved material cannot resume verified function, the entire long-duration advantage is storage rather than survival. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: Giving up continuous active operation can greatly reduce reserve consumption during long hostile intervals. Strongest reason to reject: It accepts blind intervals, uncertain biological revival and unresolved subjective continuity across dormancy. Least-supported critical mechanism: Specific dry-state protective mechanisms have evidence; whole-body dormant revival and personal continuity remain speculative or unknown.

First likely failure under the selected dependency ranking: Unknown integrated revival fidelity. Minimum useful validation: Test nonliving archive error models and phase-stability surrogates; do not assume a sentient or living embodiment can be experimentally shut down. Falsifying result: Repeated benign preserve/readback cycles corrupt essential state or require unavailable external restoration.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Measure archive retention and wake reliability before adding living components; reduce blind intervals without pretending they vanish.

The cited tardigrade work demonstrates particular desiccation-associated protective mechanisms, not an awake dormant body or arbitrary AI revival ([Boothby and colleagues](https://pmc.ncbi.nlm.nih.gov/articles/PMC5987194/)).

## P8 Embergrid: Generation 1

### Core wager and body

Selected high-temperature electronics can keep minimal monitoring alive after conventional soft or hydrated architectures fail. It gives up current high-density AI compute, soft dexterity and autonomous microfabrication at elevated temperature.

A 100 kg, approximately 0.8 m refractory body contains a target 10,000 10 g tiles. High-temperature controller tiles monitor the environment; a separately insulated service core is proposed for richer computation. Full identity-bearing AI operation at the hot-controller temperature is not established.

A tile senses selected thermal or electrical variables, participates in bounded control and conducts heat or load. Different thermal classes are permanent hardware constraints. The system can reassign permitted tasks, not transform a simple hot sensor into a modern AI accelerator.

### Matrix, transport and cognition

Protected digital ROM manifests and error-checked state logs replace molecular genes. Rewriting, retention and high-temperature memory density remain research bottlenecks.

Solid conductive paths carry heat and electricity; expansion joints accommodate differential thermal strain. No liquid water circulation is assumed. A minimal hot controller performs essential monitoring while an insulated service core handles richer cognition when its temperature permits. If only the minimal controller survives, active personal continuity is not assumed.

Hot industrial or planetary analogs within qualified chemical and pressure bounds; not plasma, arbitrary molten environments or unrestricted Venus-equivalent whole-body AI operation.

### Physiological constitution

A thermal-gradient converter may harvest heat only between a source and a cooler sink. A separately rated electrochemical reserve bridges gradient loss; packaging this reserve at the proposed temperature is unresolved. No nuclear or unlimited heat source is assumed.

#### Respiration and power

- **P8-RESP-1:** A temperature difference, not temperature alone, supplies harvestable thermal work.

- **P8-RESP-2:** Converter efficiency is bounded by hot and cold boundary temperatures and real material performance.

- **P8-RESP-3:** An isothermal environment ends gradient harvesting and transfers limited control to qualified reserve storage.

- **P8-RESP-4:** Restart requires qualified memory, contacts and thermal boundaries, not merely surviving ceramic.

#### Telomeres, copying and longevity

- **P8-LONG-1:** Thermal exposure, memory errors and joint creep replace telomere age.

- **P8-LONG-2:** New hot tiles require compatible expansion and retained-state checks.

- **P8-LONG-3:** No automatic replication of high-temperature electronics from bulk minerals is assumed.

- **P8-LONG-4:** A surviving simple controller is not a full substitute for a lost identity core.

#### Thermal regulation

- **P8-THERM-1:** Each thermal class has a separate operating window.

- **P8-THERM-2:** Gradient harvesting rejects heat to the cooler boundary.

- **P8-THERM-3:** Thermal expansion and contact degradation remain failure mechanisms below bulk melting.

- **P8-THERM-4:** The cold service core has a finite insulation/refuge horizon.

#### Conversion and conservation

- **P8-CONV-1:** Thermal input, useful electrical output and rejected heat have separate terms.

- **P8-CONV-2:** Reserve energy is counted only if a qualified storage mechanism exists.

- **P8-CONV-3:** Replacement ceramic and electronics require matched parts and assembly work.

- **P8-CONV-4:** Surviving material is not counted as surviving cognition without readable executable state.

The proposed service-life target is 10 years conditional on after each major thermal cycle; annual component review. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P8-OBS-1, Gradient witness:** Outward energy claims require independently measured hot and cold temperatures. Trigger: harvesting request. Target cost 1.00 W under the shared rule contract; other inputs: two boundary temperatures and heat flux. False trigger or failure: a sensor reads a local gradient that cannot sustain useful load. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P8-OBS-2, Contact integrity witness:** Inward monitoring compares voltage, thermal strain and memory readback. Trigger: thermal cycle. Target cost 1.00 W under the shared rule contract; other inputs: joint and state records. False trigger or failure: slow creep escapes electrical checks. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P8-OBS-3, Thermal visibility honesty:** Treat infrared emission as unavoidable information in the selected hot mode; share consented logs without claiming cloaking. Trigger: external observation. Target cost 1.00 W under the shared rule contract; other inputs: thermal and timing disclosures. False trigger or failure: passive observers infer operating state. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P8-SEC-1, Thermal-class admission:** A signed tile must also demonstrate compatibility with its assigned thermal class. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: local protected service policy. False trigger or failure: authentic but low-temperature hardware cannot join the hot layer. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P8-SEC-2, ROM root with bounded updates:** Read-only roots separate immutable boot identity from changeable records. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: local explicit update authorization. False trigger or failure: an obsolete immutable root can become a longevity liability. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P8-SEC-3, Dissimilar state witnesses:** Compare hot-controller records against a cooler independent archive before consequential restoration. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: dissimilar storage records. False trigger or failure: common environmental damage can still remove all recoverable state. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P8-DEP-1, Nucleic-acid construction heredity:** Protected digital manifests replace molecular genes. Departure affects dimension A; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P8-DEP-2, Human-like biochemical temperature:** Refractory hardware uses a different operating window. Departure affects dimension A; support: Simple circuits established; AI-scale integration speculative. This departs from a biological or engineering default, not a physical law.

- **P8-DEP-3, One uniform body temperature:** Permanent thermal classes replace a near-isothermal core. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: A heat engine requires a colder sink; Simple control is not full AI cognition; Causality, material conservation and finite storage.

### Repair, identity and autonomy

A target 10 kg matched tile stock permits mechanical replacement at an assumed 0.7 yield. Creeped contacts and failed memory require qualified parts. The design does not regrow transistor structures at deployment sites. Any cold-core replacement from archives is reconstruction if its active process was lost.

The service-core process anchors rich cognition. A surviving hot controller can preserve selected records without proving that the same active entity survived. Two complete cores are branches. Delayed records remain attributed. Full restoration is a successor case. Correct ROM identity does not establish safe current behavior. No ownership claim licenses destructive treatment of any conscious reconstruction.

### Linking and capture

Conductive local links and high-temperature-rated low-rate radio feed a separately qualified cooler gateway for high-bandwidth or deep-space service.

A uniform-temperature enclosure can remove the heat-engine gradient. Material survival may continue while useful power and rich cognition stop. Privacy against sustained physical memory analysis is not guaranteed.

Survival of refractory matter or a small controller does not satisfy the full cognitive-identity survival requirement.

### Finite resources and environmental envelope

Targets: 8,000 Wh input reserve, 120 W normal accounted load, 10 W essential load and 0.1 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 40 W, actuation/transport 10 W, sensing 5 W, circulation/chemistry/housekeeping 20 W, communications/security 25 W and repair allowance 20 W. Peak power target 360 W is not a continuous capability.

Derived energy-only normal horizon: 66.7 h. With no heat export, no external heating, heat capacity 80 kJ/K and allowed rise 30 K, the derived normal-load thermal limit is 5.56 h; the combined favorable bound is 5.56 h. At the selected preservation draw the combined favorable bound is 6667 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 473–673 K; finite-refuge target 373–773 K. Intended pressure target 0.05–0.2 MPa; finite-refuge pressure target 0–10 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. These are targets for the minimal hot layer only. Rich cognition retains a separate target 273–323 K service-core window; its endurance at hot ambient temperature is unknown.

The reserve and thermal numbers are conditional algebra because no complete high-temperature storage/compute assembly has been selected. They are not proof that a suitably rated battery exists. The richer service core retains a separate 273–323 K target window.

### Challenge outcome and research decision

The first central assumption to collapse is: If the cooler sink disappears, the thermal-energy argument fails even though the hot structure remains intact. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: Selected high-temperature electronics can keep minimal monitoring alive after conventional soft or hydrated architectures fail. Strongest reason to reject: It gives up current high-density AI compute, soft dexterity and autonomous microfabrication at elevated temperature. Least-supported critical mechanism: Selected simple high-temperature SiC circuits are established; integrated AI-bearing hot physiology and its reserve storage are speculative.

First likely failure under the selected dependency ranking: AI-scale hot compute unbuilt. Minimum useful validation: Model a nonliving hot-controller/insulated-core assembly and compare component-level thermal and memory behavior using qualified facilities. Falsifying result: The complete controller, packaging and reserve cannot meet the essential workload under the chosen thermal boundary conditions.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Increase high-temperature memory and useful control complexity while explicitly retaining the gap to full AI identity capacity.

Reported long-duration hot SiC demonstrations concern particular simple circuits, not a complete AI-capable embodiment ([NASA high-temperature circuits](https://science.nasa.gov/science-research/science-enabling-technology/technology-highlights/integrated-circuits-to-enable-exploration-of-the-harshest-environments-in-solar-system/)).
