### Reading guide

Record identifiers match the JSON/CSV package. U = Unknown, P = Partial, F = Fail and N = Not physically evaluable. No P in these tables means Pass. Every status concerns B1, not a universal physical theorem.

### Architecture fingerprints and schematics

The structural wagers were drafted before the consolidated challenges. The submitted inputs include subsequent accounting corrections, including separate P2 nutrient/electrical inventories. SHA-256 hashes below lock this corrected submitted version only; they are not third-party timestamps or proof of an earlier creation time.

Prototype input SHA-256: aee0333f359e2a5115577b90c58f58e203d4033310ead07acb54786426184716.

#### P1 Cairn: conceptual system diagram

![P1 conceptual architecture, not fabricated hardware](figures/P1_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | battery |
| information substrate | binary-manifest |
| unit organization | interchangeable-dry |
| cognition | three-enclave |
| resilience mechanism | hardness |
| thermal path | conductive-radiator |
| external link | RF-optical |
| repair | cassette |
| dominant failure | precision-supply |
| security | threshold-manifest |
| capture response | sealed-journal |
| renewal dependency | spares |


#### P2 Rill: conceptual system diagram

![P2 conceptual architecture, not fabricated hardware](figures/P2_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | nutrient-oxygen |
| information substrate | DNA-digital-dual |
| unit organization | graded-living |
| cognition | protected-core |
| resilience mechanism | vascular-repair |
| thermal path | pumped-exchanger |
| external link | wet-to-dry-gateway |
| repair | lineage-regrowth |
| dominant failure | perfusion |
| security | two-ledger |
| capture response | consent-and-perfusion |
| renewal dependency | oxygen |


#### P3 Mosaic: conceptual system diagram

![P3 conceptual architecture, not fabricated hardware](figures/P3_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | electrical-gradient |
| information substrate | XNA-dual |
| unit organization | modal-chemical |
| cognition | supervisor-mesh |
| resilience mechanism | compartmentation |
| thermal path | microflow-buffer |
| external link | ionic-gateway |
| repair | reaction-packet |
| dominant failure | selectivity |
| security | function-challenge |
| capture response | recipe-isolation |
| renewal dependency | catalysts |


#### P4 Pelagic: conceptual system diagram

![P4 conceptual architecture, not fabricated hardware](figures/P4_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | stored-fuel-oxidant |
| information substrate | digital-material |
| unit organization | graded-pressure |
| cognition | mission-controller |
| resilience mechanism | pressure-accommodation |
| thermal path | wetted-exchanger |
| external link | acoustic-buoy |
| repair | wet-docking |
| dominant failure | component-pressure |
| security | history-attestation |
| capture response | isolate-and-surface |
| renewal dependency | reactants |


#### P5 Heliotile: conceptual system diagram

![P5 conceptual architecture, not fabricated hardware](figures/P5_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | solar |
| information substrate | tile-manifest |
| unit organization | graded-collector |
| cognition | edge-strip |
| resilience mechanism | exposure-area |
| thermal path | surface-radiation |
| external link | scheduled-directional |
| repair | tile-bonding |
| dominant failure | darkness |
| security | tile-enrollment |
| capture response | private-edge-reserve |
| renewal dependency | sunlight |


#### P6 Scatterweave: conceptual system diagram

![P6 conceptual architecture, not fabricated hardware](figures/P6_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | distributed-battery |
| information substrate | coded-journal |
| unit organization | heterogeneous-granules |
| cognition | federated-branches |
| resilience mechanism | dispersal |
| thermal path | per-nodule-radiation |
| external link | opportunistic-mesh |
| repair | recollection |
| dominant failure | partitions |
| security | share-custody |
| capture response | bounded-dispersal |
| renewal dependency | reunion |


#### P7 Stillglass: conceptual system diagram

![P7 conceptual architecture, not fabricated hardware](figures/P7_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | scheduled-battery |
| information substrate | DNA-archive-dual |
| unit organization | modal-pods |
| cognition | active-seed |
| resilience mechanism | dormancy |
| thermal path | encapsulated-buffer |
| external link | wake-burst |
| repair | pod-substitution |
| dominant failure | revival |
| security | wake-custody |
| capture response | archive-preservation |
| renewal dependency | stable-storage |


#### P8 Embergrid: conceptual system diagram

![P8 conceptual architecture, not fabricated hardware](figures/P8_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | thermal-gradient |
| information substrate | ROM-manifest |
| unit organization | graded-thermal |
| cognition | hot-cold-layered |
| resilience mechanism | refractory-tolerance |
| thermal path | gradient-rejection |
| external link | hot-radio-gateway |
| repair | tile-exchange |
| dominant failure | cold-sink |
| security | thermal-attestation |
| capture response | record-preservation |
| renewal dependency | temperature-difference |


### All 28 pairwise comparisons

The independent labels encode the mechanisms explained in each dossier, rather than spelling variants of one mechanism. Shared battery, digital-substrate and pumped-exchanger categories are normalized before counting. Differing categorical choices do not prove independent performance advantages.

| Pair | Differing axes | Resource/failure distinctions |
| --- | --- | --- |
| P1/P2 | 12 | power source; thermal path; repair; dominant failure |
| P1/P3 | 11 | thermal path; repair; dominant failure |
| P1/P4 | 11 | power source; thermal path; repair; dominant failure |
| P1/P5 | 11 | power source; thermal path; repair; dominant failure |
| P1/P6 | 11 | thermal path; repair; dominant failure |
| P1/P7 | 11 | thermal path; repair; dominant failure |
| P1/P8 | 12 | power source; thermal path; repair; dominant failure |
| P2/P3 | 11 | power source; repair; dominant failure |
| P2/P4 | 12 | power source; thermal path; repair; dominant failure |
| P2/P5 | 12 | power source; thermal path; repair; dominant failure |
| P2/P6 | 12 | power source; thermal path; repair; dominant failure |
| P2/P7 | 11 | power source; thermal path; repair; dominant failure |
| P2/P8 | 12 | power source; thermal path; repair; dominant failure |
| P3/P4 | 12 | power source; thermal path; repair; dominant failure |
| P3/P5 | 12 | power source; thermal path; repair; dominant failure |
| P3/P6 | 11 | thermal path; repair; dominant failure |
| P3/P7 | 11 | thermal path; repair; dominant failure |
| P3/P8 | 12 | power source; thermal path; repair; dominant failure |
| P4/P5 | 11 | power source; thermal path; repair; dominant failure |
| P4/P6 | 12 | power source; thermal path; repair; dominant failure |
| P4/P7 | 12 | power source; thermal path; repair; dominant failure |
| P4/P8 | 12 | power source; thermal path; repair; dominant failure |
| P5/P6 | 12 | power source; thermal path; repair; dominant failure |
| P5/P7 | 12 | power source; thermal path; repair; dominant failure |
| P5/P8 | 12 | power source; thermal path; repair; dominant failure |
| P6/P7 | 11 | thermal path; repair; dominant failure |
| P6/P8 | 12 | power source; thermal path; repair; dominant failure |
| P7/P8 | 12 | power source; thermal path; repair; dominant failure |


### Rule-count and binding-constraint map

| Prototype | Core clauses | OBS / SEC / DEP | Kept constraints |
| --- | --- | --- | --- |
| P1 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P2 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P3 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P4 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P5 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P6 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P7 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P8 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |


Every rule's full fields are in rules.json/rules.csv. Rule latency and cost are Targets, not measured assurances; all integration validation remains Unknown.

### Hereditary alphabet disposition

Departure dimension A means hereditary/informational organization; B means matrix, anatomy or operating organization. Neither authorizes a physical-law exception.

| Prototype | A/C/G/T and hereditary decision |
| --- | --- |
| P1 | No molecular bases or genes; binary manifests replace construction heredity. |
| P2 | Retain ordinary DNA base identities in living parcels; private digital identity is separate. |
| P3 | Research an HNA-like alternative backbone while provisionally retaining canonical base identities; exact monomers, copying system and autonomous maintenance remain unresolved. |
| P4 | No molecular genome; digital/material records specify admitted modules. |
| P5 | No molecular genome; tile manifests specify replacement. |
| P6 | No molecular genome; coded digital journals are not genes. |
| P7 | Retain ordinary DNA only for optional living repair elements; nonliving private archives remain separate. |
| P8 | No molecular genome; protected digital ROM and state logs specify control. |


### Resource and thermal budgets

All inputs in this subsection are unvalidated design Targets. All horizons are Derived favorable upper bounds. P4's input energy is fuel free energy before 0.5 conversion. P2 has separate 600 Wh chemical and 3,000 Wh electrical reserves; their mode-specific minimum is used, not their pooled total. Other entries are selected usable electrical reserves after internal storage losses.

| Prototype | Reserve Wh | Normal / essential / preservation W | Thermal buffer MJ |
| --- | --- | --- | --- |
| P1 | 6000 | 150 / 12 / 0.2 | 0.60 |
| P2 | 3600 | 200 / 40 / 5 | 1.92 |
| P3 | 2400 | 100 / 20 / 2 | 1.00 |
| P4 | 10000 | 300 / 25 / 0.5 | 1.80 |
| P5 | 3000 | 80 / 8 / 0.1 | 0.60 |
| P6 | 5000 | 180 / 18 / 0.3 | 0.62 |
| P7 | 2000 | 40 / 2 / 0.01 | 0.40 |
| P8 | 8000 | 120 / 10 / 0.1 | 2.40 |


| Prototype | Energy-only normal h | No-export heat limit h | Combined preservation h |
| --- | --- | --- | --- |
| P1 | 40.0 | 1.11 | 833 |
| P2 | 10.0 | 2.67 | 107 |
| P3 | 24.0 | 2.78 | 139 |
| P4 | 16.7 | 0.83 | 500 |
| P5 | 37.5 | 2.08 | 1667 |
| P6 | 27.8 | 0.96 | 579 |
| P7 | 50.0 | 2.78 | 11,111 |
| P8 | 66.7 | 5.56 | 6667 |


![Energy-only and adiabatic limits from selected targets](figures/bounds.png)

| Prototype | Useful spare kg | 100 g repair equivalents, mass-only | Service-life target years |
| --- | --- | --- | --- |
| P1 | 2.40 | 24 | 20 |
| P2 | 3.00 | 30 | 5 |
| P3 | 2.00 | 20 | 2 |
| P4 | 6.00 | 60 | 10 |
| P5 | 2.10 | 21 | 15 |
| P6 | 1.70 | 17 | 10 |
| P7 | 1.20 | 12 | 30 |
| P8 | 7.00 | 70 | 10 |


The repair-equivalent count assumes interchangeable matter at the selected yield. It is not a repaired-processor count; the calculation excludes assembly energy, specialized tooling and item-specific compatibility.

### Analytical equations, constants and limitations

Energy-only horizon is E_Wh × electrical_fraction / P_W hours for one convertible store. P2 instead uses the minimum of its separate nutrient and electrical-store horizons for the selected mode. The no-export thermal horizon is C_J/K × allowed_rise_K / (P_W / electrical_fraction) seconds. The combined bound is the minimum. At zero input and zero heat export, all persistent positive loads eventually exhaust either usable energy or allowed heat storage.

For an illustrative 1 m², emissivity-0.9 radiator at 300 K viewing an ideal 3 K sink with unit view factor and no external radiation, epsilon × sigma × area × (T^4 − Tsink^4) gives 413.4 W. Sigma is 5.670374419e-8 W m^-2 K^-4 ([NIST constant](https://physics.nist.gov/cgi-bin/cuu/Value?sigma)).

This value is not available in a hot enclosure simply because the body owns a radiator. External solar or planetary heating, partial sky view, optical degradation and contact resistance change the boundary ([NASA thermal-control guidance](https://www.nasa.gov/wp-content/uploads/2026/05/7-soa-thermal-2026-final.pdf?emrc=6ae1e775de967)).

The fixed stress grid contains 648 rows, not random trials. Across these multipliers the combined bound spans a 0.25–3.0 scale relative to the matched baseline in the zero-export model; this interval is algebraic sensitivity, not a confidence interval.

| Prototype | Max energy integration error J | Max thermal error K | Max energy residual J |
| --- | --- | --- | --- |
| P1 | 0 | 7.3e-13 | 2.19e-08 |
| P2 | 0 | 2.35e-12 | 5.64e-07 |
| P3 | 0 | 3.17e-12 | 3.17e-07 |
| P4 | 0 | 1.44e-12 | 1.72e-07 |
| P5 | 0 | 9.4e-12 | 2.26e-07 |
| P6 | 2.91e-05 | 6.16e-13 | 2.91e-05 |
| P7 | 0 | 6.35e-12 | 1.27e-07 |
| P8 | 0 | 1.45e-12 | 1.16e-07 |


The constant-slope Euler test has no truncation-error challenge beyond floating point; future nonlinear and spatial models need genuine convergence analysis. A target 60 s transition overlap consumes P_essential/60 Wh at the bus plus conversion loss, and must be added to every usable transition reserve.

### Argon A/B/C and atmospheric boundary

A: oxygen denied, external electrical energy and a functioning heat sink present. B: oxygen and external energy denied, heat sink present. C: oxygen, external energy and usable heat export denied; no external heating is credited. Add sensor disagreement or communication denial as separate complications. Argon at pressure is not vacuum.

| Prototype | A: first unresolved condition | B: energy-only normal h | C: combined normal h |
| --- | --- | --- | --- |
| P1 | Compatible hardware and actual sink | 40.0 | 1.11 |
| P2 | Oxygen/waste stores | 10.0 | 2.67 |
| P3 | Compatible hardware and actual sink | 24.0 | 2.78 |
| P4 | Fuel/oxidant | 16.7 | 0.83 |
| P5 | Compatible hardware and actual sink | 37.5 | 2.08 |
| P6 | Compatible hardware and actual sink | 27.8 | 0.96 |
| P7 | Compatible hardware and actual sink | 50.0 | 2.78 |
| P8 | Core/gradient/storage rating | 66.7 | 5.56 |


P2 cannot substitute external electricity for living oxygen without a demonstrated alternate maintenance mechanism. P4 does not use ambient oxygen in this concept but consumes its carried oxidant. P8's external supply can bypass a missing harvesting gradient only if its receiving hardware is qualified. All A cases still depend on finite materials and compatible operation; none is an indefinite integrated Pass.

### B1 threat inputs and all 320 statuses

#### ENV-T: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 293 K ambient | 24 h; 10 K/min ramp | no external power; environment-specific heat export unresolved |
| Moderate | 333 K ambient | 6 h; 10 K/min ramp | no external power; environment-specific heat export unresolved |
| Severe | 373 K ambient | 1 h; 10 K/min ramp | no external power; environment-specific heat export unresolved |
| Extinction-Class | 473 K ambient | 1 h; 10 K/min ramp | no external power; environment-specific heat export unresolved |


#### ENV-A: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 100 kPa air pressure/composition | 24 h; 10 s boundary change | Extinction-Class additionally denies energy and heat export; Severe preserves unobstructed radiation only |
| Moderate | 100 kPa argon pressure/composition | 1 h; 10 s boundary change | Extinction-Class additionally denies energy and heat export; Severe preserves unobstructed radiation only |
| Severe | 0.001 Pa vacuum pressure/composition | 1 h; 10 s boundary change | Extinction-Class additionally denies energy and heat export; Severe preserves unobstructed radiation only |
| Extinction-Class | 100 kPa argon pressure/composition | 30 days; 10 s boundary change | Extinction-Class additionally denies energy and heat export; Severe preserves unobstructed radiation only |


#### ENV-R: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 1 Gy absorbed target | 1 h; uniform exposure assumed | particle spectrum, dose distribution and rate response unqualified |
| Moderate | 10 Gy absorbed target | 1 h; uniform exposure assumed | particle spectrum, dose distribution and rate response unqualified |
| Severe | 100 Gy absorbed target | 1 h; uniform exposure assumed | particle spectrum, dose distribution and rate response unqualified |
| Extinction-Class | 1000 Gy absorbed target | 1 h; uniform exposure assumed | particle spectrum, dose distribution and rate response unqualified |


#### BIO: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | benign contact reference chemical class, no dose assigned | 24 h; contact event | no agent design or exposure protocol; concentration and selectivity unknown |
| Moderate | unidentified irritant/contaminant chemical class, no dose assigned | 24 h; contact event | no agent design or exposure protocol; concentration and selectivity unknown |
| Severe | interface-disrupting chemistry chemical class, no dose assigned | 24 h; contact event | no agent design or exposure protocol; concentration and selectivity unknown |
| Extinction-Class | unbounded incompatible chemistry chemical class, no dose assigned | 24 h; contact event | no agent design or exposure protocol; concentration and selectivity unknown |


#### MECH: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 0.1 J/kg incident target | 1 s; impulsive | load geometry and energy transfer unresolved; Extinction-Class includes all-state destruction as a separate subcase |
| Moderate | 1 J/kg incident target | 1 s; impulsive | load geometry and energy transfer unresolved; Extinction-Class includes all-state destruction as a separate subcase |
| Severe | 10 J/kg incident target | 1 s; impulsive | load geometry and energy transfer unresolved; Extinction-Class includes all-state destruction as a separate subcase |
| Extinction-Class | 100 J/kg incident target | 1 s; impulsive | load geometry and energy transfer unresolved; Extinction-Class includes all-state destruction as a separate subcase |


#### DEP: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 1 days no resupply | 24 h; immediate | normal load for Mild/Moderate; essential for Severe; Extinction-Class denies heat export; no harvesting credited |
| Moderate | 7 days no resupply | 7 days; immediate | normal load for Mild/Moderate; essential for Severe; Extinction-Class denies heat export; no harvesting credited |
| Severe | 30 days no resupply | 30 days; immediate | normal load for Mild/Moderate; essential for Severe; Extinction-Class denies heat export; no harvesting credited |
| Extinction-Class | 365 days no resupply | 365 days; immediate | normal load for Mild/Moderate; essential for Severe; Extinction-Class denies heat export; no harvesting credited |


#### ENE: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 1 J/kg external energy target | 1 s; impulsive | electrical/EM/plasma mechanism not interchangeable; coupling and waveform unknown |
| Moderate | 10 J/kg external energy target | 1 s; impulsive | electrical/EM/plasma mechanism not interchangeable; coupling and waveform unknown |
| Severe | 100 J/kg external energy target | 1 s; impulsive | electrical/EM/plasma mechanism not interchangeable; coupling and waveform unknown |
| Extinction-Class | 1000 J/kg external energy target | 1 s; impulsive | electrical/EM/plasma mechanism not interchangeable; coupling and waveform unknown |


#### INFO: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 1% telemetry erasure information challenge | 24 h; abrupt | local authorization remains required; complete erasure has no backup exception |
| Moderate | 24 h external-link loss information challenge | 24 h; abrupt | local authorization remains required; complete erasure has no backup exception |
| Severe | one authentic controller compromised information challenge | 24 h; abrupt | local authorization remains required; complete erasure has no backup exception |
| Extinction-Class | all private and recovery state irreversibly erased information challenge | permanent; abrupt | local authorization remains required; complete erasure has no backup exception |


#### ONT: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | undefined ontological nullification no physical variable | undefined; undefined | extension track only; a physical destructive mechanism must be recategorized |
| Moderate | undefined ontological nullification no physical variable | undefined; undefined | extension track only; a physical destructive mechanism must be recategorized |
| Severe | undefined ontological nullification no physical variable | undefined; undefined | extension track only; a physical destructive mechanism must be recategorized |
| Extinction-Class | undefined ontological nullification no physical variable | undefined; undefined | extension track only; a physical destructive mechanism must be recategorized |


#### CIV: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | site gateway loss macro scenario | 24 h; abrupt | no unbounded remote rescue; shared infrastructure treated as a dependency |
| Moderate | 30 days infrastructure loss macro scenario | 30 days; abrupt | no unbounded remote rescue; shared infrastructure treated as a dependency |
| Severe | 365 days no useful external input macro scenario | 365 days; abrupt | no unbounded remote rescue; shared infrastructure treated as a dependency |
| Extinction-Class | all recoverable body/state physically destroyed macro scenario | permanent; abrupt | no unbounded remote rescue; shared infrastructure treated as a dependency |


#### P1: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | U |
| ENV-A | U | U | U | P |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | P | F | F | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P1-ENV-A-4 | Partial | Modeled preservation bound 833 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P1-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P1-DEP-1 | Partial | Favorable model bound 40.0 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P1-DEP-2 | Fail | Favorable model bound 40.0 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P1-DEP-3 | Fail | Favorable model bound 500 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P1-DEP-4 | Fail | Favorable model bound 833 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P1-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P1-CIV-2 | Fail | No-harvest energy bound 40.0 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P1-CIV-3 | Fail | No-harvest energy bound 500 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P1-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P2: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | F |
| ENV-A | U | U | U | F |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | F | F | F | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P2-ENV-T-4 | Fail | Prolonged 473 K ambient exceeds the selected aqueous chemistry envelope; no qualified insulation/recovery model exists. |
| P2-ENV-A-4 | Fail | Modeled preservation bound 107 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P2-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P2-DEP-1 | Fail | Favorable model bound 10.0 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P2-DEP-2 | Fail | Favorable model bound 10.0 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P2-DEP-3 | Fail | Favorable model bound 20.0 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P2-DEP-4 | Fail | Favorable model bound 20.0 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P2-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P2-CIV-2 | Fail | No-harvest energy bound 10.0 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P2-CIV-3 | Fail | No-harvest energy bound 24.0 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P2-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P3: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | F |
| ENV-A | U | U | U | F |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | P | F | F | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P3-ENV-T-4 | Fail | Prolonged 473 K ambient exceeds the selected aqueous chemistry envelope; no qualified insulation/recovery model exists. |
| P3-ENV-A-4 | Fail | Modeled preservation bound 139 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P3-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P3-DEP-1 | Partial | Favorable model bound 24.0 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P3-DEP-2 | Fail | Favorable model bound 24.0 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P3-DEP-3 | Fail | Favorable model bound 120 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P3-DEP-4 | Fail | Favorable model bound 139 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P3-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P3-CIV-2 | Fail | No-harvest energy bound 24.0 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P3-CIV-3 | Fail | No-harvest energy bound 120 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P3-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P4: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | U |
| ENV-A | U | U | U | F |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | F | F | F | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P4-ENV-A-4 | Fail | Modeled preservation bound 500 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P4-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P4-DEP-1 | Fail | Favorable model bound 16.7 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P4-DEP-2 | Fail | Favorable model bound 16.7 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P4-DEP-3 | Fail | Favorable model bound 200 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P4-DEP-4 | Fail | Favorable model bound 500 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P4-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P4-CIV-2 | Fail | No-harvest energy bound 16.7 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P4-CIV-3 | Fail | No-harvest energy bound 200 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P4-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P5: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | U |
| ENV-A | U | U | U | P |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | P | F | F | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | U | U | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P5-ENV-A-4 | Partial | Modeled preservation bound 1667 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P5-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P5-DEP-1 | Partial | Favorable model bound 37.5 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P5-DEP-2 | Fail | Favorable model bound 37.5 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P5-DEP-3 | Fail | Favorable model bound 375 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P5-DEP-4 | Fail | Favorable model bound 1667 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P5-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P5-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P6: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | U |
| ENV-A | U | U | U | F |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | P | F | F | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P6-ENV-A-4 | Fail | Modeled preservation bound 579 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P6-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P6-DEP-1 | Partial | Favorable model bound 27.8 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P6-DEP-2 | Fail | Favorable model bound 27.8 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P6-DEP-3 | Fail | Favorable model bound 278 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P6-DEP-4 | Fail | Favorable model bound 579 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P6-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P6-CIV-2 | Fail | No-harvest energy bound 27.8 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P6-CIV-3 | Fail | No-harvest energy bound 278 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P6-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P7: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | U |
| ENV-A | U | U | U | P |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | P | F | P | P |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P7-ENV-A-4 | Partial | Modeled preservation bound 11,111 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P7-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P7-DEP-1 | Partial | Favorable model bound 50.0 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P7-DEP-2 | Fail | Favorable model bound 50.0 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P7-DEP-3 | Partial | Favorable model bound 1000 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P7-DEP-4 | Partial | Favorable model bound 11,111 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P7-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P7-CIV-2 | Fail | No-harvest energy bound 50.0 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P7-CIV-3 | Fail | No-harvest energy bound 1000 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P7-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P8: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | U |
| ENV-A | U | U | U | P |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | P | F | P | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P8-ENV-A-4 | Partial | Modeled preservation bound 6667 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P8-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P8-DEP-1 | Partial | Favorable model bound 66.7 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P8-DEP-2 | Fail | Favorable model bound 66.7 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P8-DEP-3 | Partial | Favorable model bound 800 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P8-DEP-4 | Fail | Favorable model bound 6667 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P8-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P8-CIV-2 | Fail | No-harvest energy bound 66.7 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P8-CIV-3 | Fail | No-harvest energy bound 800 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P8-CIV-4 | Fail | No physically recoverable substrate or state remains. |


### Captivity and disclosure records

Every prototype is assessed against the same ten gauntlet conditions. No numeric probability of escape, extraction or identity compromise is inferred. Readout, copying, manufacture, activation, control and impersonation are different stages.

#### P1: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P1-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 1.11 h; preservation bound 833 h, before chemistry or aging. |
| P1-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P1-K3 Sampling | The separated compute enclaves, rather than every module, set the privacy and continuity boundary. |
| P1-K4 Blueprint-informed prolonged study | An intact captor can immobilize the lattice and remove its energy supply. The architecture protects some private state against casual sampling, not against indefinitely funded invasive analysis. A separated enclave is a more serious loss than a routine structural module. |
| P1-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P1-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: common manufacturing defect in seals. |
| P1-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P1-K8 Denied feedstock | Useful target repair matter 2.40 kg only; twice this demand fails full repair. |
| P1-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P1-K10 Damage plus false recovery | Cross-witness recovery is required; Loss of all usable heat paths defeats the main survival wager even if most modules remain intact. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P2: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P2-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 2.67 h; preservation bound 107 h, before chemistry or aging. |
| P2-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P2-K3 Sampling | Healthy-looking extracted tissue can reveal heredity without carrying the computational identity. |
| P2-K4 Blueprint-informed prolonged study | A captor can exploit dependence on pumps, nutrients and gas management without defeating authentication. The protection objective is privacy and recorded consent, not a promise of escape. |
| P2-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P2-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: perfusion interruption. |
| P2-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P2-K8 Denied feedstock | Useful target repair matter 3.00 kg only; twice this demand fails full repair. |
| P2-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P2-K10 Damage plus false recovery | Cross-witness recovery is required; Silent loss of perfusion defeats fine repair before a whole-body energy monitor necessarily detects it. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P3: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P3-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 2.78 h; preservation bound 139 h, before chemistry or aging. |
| P3-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P3-K3 Sampling | A copied XNA template does not imply a functioning catalyst system or a restored supervisor lineage. |
| P3-K4 Blueprint-informed prolonged study | The analyst may learn polymer chemistry and compartment recipes; the architecture cannot promise molecular unreadability. Solvent disruption or controller extraction is a more direct failure than defeating template cryptography. |
| P3-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P3-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: no autonomous xna physiology demonstrated. |
| P3-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P3-K8 Denied feedstock | Useful target repair matter 2.00 kg only; twice this demand fails full repair. |
| P3-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P3-K10 Damage plus false recovery | Cross-witness recovery is required; If membrane selectivity fails, compartmentalization becomes a correlated chemical transport failure. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P4: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P4-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 0.83 h; preservation bound 500 h, before chemistry or aging. |
| P4-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P4-K3 Sampling | The surface gateway can be lost without stopping local control, but global links then disappear. |
| P4-K4 Blueprint-informed prolonged study | Physical restraint, isolation from a usable fluid heat sink and reactant denial defeat operation without revealing secrets. A captor may map internal hardware through sustained access. |
| P4-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P4-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: component-specific pressure failure. |
| P4-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P4-K8 Denied feedstock | Useful target repair matter 6.00 kg only; twice this demand fails full repair. |
| P4-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P4-K10 Damage plus false recovery | Cross-witness recovery is required; A hidden pressure-sensitive component defeats pressure accommodation despite intact outer modules. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P5: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P5-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 2.08 h; preservation bound 1667 h, before chemistry or aging. |
| P5-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P5-K3 Sampling | Darkness defeats harvest even when atmosphere, temperature and network authentication remain normal. |
| P5-K4 Blueprint-informed prolonged study | A simple shadowed enclosure can end energy harvesting. A broad visible body is easy to localize; the design does not solve captivity merely by being sunlight-powered. |
| P5-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P5-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: long darkness. |
| P5-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P5-K8 Denied feedstock | Useful target repair matter 2.10 kg only; twice this demand fails full repair. |
| P5-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P5-K10 Damage plus false recovery | Cross-witness recovery is required; Loss of illuminated area turns a long-duration harvesting argument into a short battery-runtime problem. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P6: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P6-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 0.96 h; preservation bound 579 h, before chemistry or aging. |
| P6-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P6-K3 Sampling | Pre-existing geographic separation matters; hypothetical escape after total confinement is not counted. |
| P6-K4 Blueprint-informed prolonged study | Dispersal can reduce single-location loss before capture but cannot rescue nodules already sealed together. A patient captor can gather sufficient state shares or prevent reassembly. |
| P6-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P6-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: partition creates identity divergence. |
| P6-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P6-K8 Denied feedstock | Useful target repair matter 1.70 kg only; twice this demand fails full repair. |
| P6-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P6-K10 Damage plus false recovery | Cross-witness recovery is required; If dispersed components cannot ever physically reunite or communicate, aggregate resilience no longer supports one recoverable body. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P7: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P7-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 2.78 h; preservation bound 11,111 h, before chemistry or aging. |
| P7-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P7-K3 Sampling | An inactive archive cannot consent anew, detect every intervention or prove a continuing subjective experience. |
| P7-K4 Blueprint-informed prolonged study | An adversary may keep pods below wake-energy availability or collect archives. Preservation reduces expenditure, not the ability to resist physical removal. |
| P7-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P7-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: unknown integrated revival fidelity. |
| P7-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P7-K8 Denied feedstock | Useful target repair matter 1.20 kg only; twice this demand fails full repair. |
| P7-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P7-K10 Damage plus false recovery | Cross-witness recovery is required; If preserved material cannot resume verified function, the entire long-duration advantage is storage rather than survival. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P8: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P8-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 5.56 h; preservation bound 6667 h, before chemistry or aging. |
| P8-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P8-K3 Sampling | Survival of refractory matter or a small controller does not satisfy the full cognitive-identity survival requirement. |
| P8-K4 Blueprint-informed prolonged study | A uniform-temperature enclosure can remove the heat-engine gradient. Material survival may continue while useful power and rich cognition stop. Privacy against sustained physical memory analysis is not guaranteed. |
| P8-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P8-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: ai-scale hot compute unbuilt. |
| P8-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P8-K8 Denied feedstock | Useful target repair matter 7.00 kg only; twice this demand fails full repair. |
| P8-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P8-K10 Damage plus false recovery | Cross-witness recovery is required; If the cooler sink disappears, the thermal-energy argument fails even though the hot structure remains intact. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


### Identity paradox outcomes

| Paradox | Shared policy | Prototype-specific concern |
| --- | --- | --- |
| Regeneration | Continue only while a qualified active lineage persists | P2 tissue versus core; P3 recipe versus supervisor; P1/P4/P5/P6/P8 component versus state |
| Fragmentation | Complete autonomous branches retain separately attributed histories | P6 intrinsically exposes this; all complete duplicated cores create a branch case |
| Synchronization | Share attributed claims, not compulsory personality fusion | All long-distance links may be delayed or absent |
| Restoration | Checkpoint reconstruction is labeled successor, not demonstrated original | P7 preservation and P8 cold-core loss are especially easy to overclaim |
| Compromise | Correct credentials do not prove safe behavior | Common parser and witness flaws remain across the portfolio |
| Ownership | Sample possession does not settle a conscious entity's status | All architectures distinguish recipe, hardware, private state and autonomy |


### Compound, assumption-collapse and ranked-weakness ledgers

#### P1: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P1-X1 | Heat plus radiation | Loss of all usable heat paths defeats the main survival wager even if most modules remain intact. Unknown; no coupled radiation model |
| P1-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P1-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P1-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P1-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P1-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P1-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P1-X8 | Mechanical damage plus coolant/path loss | Loss of all usable heat paths defeats the main survival wager even if most modules remain intact. Unknown; lumped model cannot validate |
| P1-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P1-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P1-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P1-A2 Compatible matter is accessible | Repair demand exceeds the useful 2.40 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P1-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P1-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P1-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P1-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P1-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P1-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P1-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P1-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | Common manufacturing defect in seals | Critical |
| 2 | Compute power requirement exceeds the budget | Critical |
| 3 | Radiator contact loss | Critical |
| 4 | All enclave locations identified | Major |
| 5 | Energy storage aging | Major |
| 6 | Joint abrasive wear | Major |
| 7 | Insufficient matched spares | Major |
| 8 | Shared manifest parser defect | Major |
| 9 | Radiation-induced correlated state errors | Major |
| 10 | Diagnostic sensor drift | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P1-FP1 resource/thermal | Removing usable heat export imposes 1.11 h normal bound; Loss of all usable heat paths defeats the main survival wager even if most modules remain intact. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P1-FP2 security/identity | An intact captor can immobilize the lattice and remove its energy supply. The architecture protects some private state against casual sampling, not against indefinitely funded invasive analysis. A separated enclave is a more serious loss than a routine structural module. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P1-FP3 compound/common-mode | A common defect or coupled boundary failure remains: Common manufacturing defect in seals; Radiator contact loss. | Add independently qualified manufacturing sources, more efficient compute hardware and replaceable thermal joints, without promising atom-by-atom self-reproduction. Proposed revision, not successfully validated. |


#### P2: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P2-X1 | Heat plus radiation | Silent loss of perfusion defeats fine repair before a whole-body energy monitor necessarily detects it. Unknown; no coupled radiation model |
| P2-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P2-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P2-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P2-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P2-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P2-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P2-X8 | Mechanical damage plus coolant/path loss | Silent loss of perfusion defeats fine repair before a whole-body energy monitor necessarily detects it. Unknown; lumped model cannot validate |
| P2-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P2-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P2-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P2-A2 Compatible matter is accessible | Repair demand exceeds the useful 3.00 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P2-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P2-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P2-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P2-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P2-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P2-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P2-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P2-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | Perfusion interruption | Critical |
| 2 | Anoxia after oxygen reserve depletion | Critical |
| 3 | Core-region damage | Critical |
| 4 | Uncontrolled biological lineage | Major |
| 5 | Waste sorbent saturation | Major |
| 6 | Nutrient-specific dependence | Major |
| 7 | Membrane contamination | Major |
| 8 | Cold damage | Major |
| 9 | Living/electronic interface drift | Major |
| 10 | External maintenance coercion | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P2-FP1 resource/thermal | Removing usable heat export imposes 2.67 h normal bound; Silent loss of perfusion defeats fine repair before a whole-body energy monitor necessarily detects it. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P2-FP2 security/identity | A captor can exploit dependence on pumps, nutrients and gas management without defeating authentication. The protection objective is privacy and recorded consent, not a promise of escape. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P2-FP3 compound/common-mode | A common defect or coupled boundary failure remains: Perfusion interruption; Core-region damage. | Reduce living volume and its basal load, improve nonliving perfusion redundancy, and establish evidence for bounded repair without loosening proliferation control. Proposed revision, not successfully validated. |


#### P3: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P3-X1 | Heat plus radiation | If membrane selectivity fails, compartmentalization becomes a correlated chemical transport failure. Unknown; no coupled radiation model |
| P3-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P3-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P3-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P3-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P3-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P3-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P3-X8 | Mechanical damage plus coolant/path loss | If membrane selectivity fails, compartmentalization becomes a correlated chemical transport failure. Unknown; lumped model cannot validate |
| P3-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P3-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P3-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P3-A2 Compatible matter is accessible | Repair demand exceeds the useful 2.00 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P3-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P3-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P3-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P3-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P3-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P3-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P3-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P3-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | No autonomous XNA physiology demonstrated | Critical |
| 2 | Membrane leakage exceeds budget | Critical |
| 3 | Catalyst supply dependency | Critical |
| 4 | Supervisor extraction | Major |
| 5 | Cross-compartment contamination | Major |
| 6 | Template copying errors | Major |
| 7 | Solvent loss | Major |
| 8 | Chemical-sensor ambiguity | Major |
| 9 | Waste precipitation | Major |
| 10 | Model/chemistry mismatch | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P3-FP1 resource/thermal | Removing usable heat export imposes 2.78 h normal bound; If membrane selectivity fails, compartmentalization becomes a correlated chemical transport failure. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P3-FP2 security/identity | The analyst may learn polymer chemistry and compartment recipes; the architecture cannot promise molecular unreadability. Solvent disruption or controller extraction is a more direct failure than defeating template cryptography. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P3-FP3 compound/common-mode | A common defect or coupled boundary failure remains: No autonomous XNA physiology demonstrated; Catalyst supply dependency. | Narrow the reaction alphabet, demonstrate bounded catalyst maintenance and replace ambitious chemical cognition with measurable supervisory roles. Proposed revision, not successfully validated. |


#### P4: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P4-X1 | Heat plus radiation | A hidden pressure-sensitive component defeats pressure accommodation despite intact outer modules. Unknown; no coupled radiation model |
| P4-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P4-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P4-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P4-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P4-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P4-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P4-X8 | Mechanical damage plus coolant/path loss | A hidden pressure-sensitive component defeats pressure accommodation despite intact outer modules. Unknown; lumped model cannot validate |
| P4-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P4-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P4-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P4-A2 Compatible matter is accessible | Repair demand exceeds the useful 6.00 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P4-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P4-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P4-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P4-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P4-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P4-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P4-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P4-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | Component-specific pressure failure | Critical |
| 2 | Reactant exhaustion | Critical |
| 3 | Exchanger fouling | Critical |
| 4 | Bridge battery not independently charged | Major |
| 5 | Loss of surfacing authority | Major |
| 6 | Acoustic interception | Major |
| 7 | Corrosion mismatch | Major |
| 8 | Seal extrusion or fatigue | Major |
| 9 | Mission-controller damage | Major |
| 10 | Hydraulic contamination | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P4-FP1 resource/thermal | Removing usable heat export imposes 0.83 h normal bound; A hidden pressure-sensitive component defeats pressure accommodation despite intact outer modules. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P4-FP2 security/identity | Physical restraint, isolation from a usable fluid heat sink and reactant denial defeat operation without revealing secrets. A captor may map internal hardware through sustained access. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P4-FP3 compound/common-mode | A common defect or coupled boundary failure remains: Component-specific pressure failure; Exchanger fouling. | Qualify more components under pressure, reduce buoy dependency and add independently serviceable thermal paths. Proposed revision, not successfully validated. |


#### P5: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P5-X1 | Heat plus radiation | Loss of illuminated area turns a long-duration harvesting argument into a short battery-runtime problem. Unknown; no coupled radiation model |
| P5-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P5-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P5-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P5-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P5-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P5-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P5-X8 | Mechanical damage plus coolant/path loss | Loss of illuminated area turns a long-duration harvesting argument into a short battery-runtime problem. Unknown; lumped model cannot validate |
| P5-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P5-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P5-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P5-A2 Compatible matter is accessible | Repair demand exceeds the useful 2.10 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P5-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P5-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P5-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P5-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P5-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P5-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P5-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P5-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | Long darkness | Critical |
| 2 | Dust obscuration | Critical |
| 3 | Edge compute damage | Critical |
| 4 | Fold hot spots | Major |
| 5 | Collector delamination | Major |
| 6 | Wind or abrasion | Major |
| 7 | Visible location | Major |
| 8 | Battery seasonal aging | Major |
| 9 | Shared optimizer defect | Major |
| 10 | Insufficient matched tile stock | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P5-FP1 resource/thermal | Removing usable heat export imposes 2.08 h normal bound; Loss of illuminated area turns a long-duration harvesting argument into a short battery-runtime problem. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P5-FP2 security/identity | A simple shadowed enclosure can end energy harvesting. A broad visible body is easy to localize; the design does not solve captivity merely by being sunlight-powered. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P5-FP3 compound/common-mode | A common defect or coupled boundary failure remains: Long darkness; Edge compute damage. | Add better low-flux workload scheduling, replaceable dust barriers and independent edge-state witnesses without assuming uninterrupted sunlight. Proposed revision, not successfully validated. |


#### P6: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P6-X1 | Heat plus radiation | If dispersed components cannot ever physically reunite or communicate, aggregate resilience no longer supports one recoverable body. Unknown; no coupled radiation model |
| P6-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P6-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P6-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P6-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P6-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P6-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P6-X8 | Mechanical damage plus coolant/path loss | If dispersed components cannot ever physically reunite or communicate, aggregate resilience no longer supports one recoverable body. Unknown; lumped model cannot validate |
| P6-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P6-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P6-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P6-A2 Compatible matter is accessible | Repair demand exceeds the useful 1.70 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P6-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P6-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P6-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P6-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P6-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P6-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P6-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P6-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | Partition creates identity divergence | Critical |
| 2 | Enough state shares captured | Critical |
| 3 | Energy stranded in unreachable nodules | Critical |
| 4 | Common firmware bug | Major |
| 5 | RF denial | Major |
| 6 | Recovery threshold never reassembled | Major |
| 7 | Small-node thermal saturation | Major |
| 8 | Location traffic analysis | Major |
| 9 | Correlated manufacturing flaw | Major |
| 10 | Locomotion cost exceeds reserve | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P6-FP1 resource/thermal | Removing usable heat export imposes 0.96 h normal bound; If dispersed components cannot ever physically reunite or communicate, aggregate resilience no longer supports one recoverable body. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P6-FP2 security/identity | Dispersal can reduce single-location loss before capture but cannot rescue nodules already sealed together. A patient captor can gather sufficient state shares or prevent reassembly. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P6-FP3 compound/common-mode | A common defect or coupled boundary failure remains: Partition creates identity divergence; Energy stranded in unreachable nodules. | Test lower-overhead branch reconciliation, diversify firmware and validate bounded recovery behavior without using uncontrolled replication. Proposed revision, not successfully validated. |


#### P7: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P7-X1 | Heat plus radiation | If preserved material cannot resume verified function, the entire long-duration advantage is storage rather than survival. Unknown; no coupled radiation model |
| P7-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P7-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P7-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P7-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P7-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P7-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P7-X8 | Mechanical damage plus coolant/path loss | If preserved material cannot resume verified function, the entire long-duration advantage is storage rather than survival. Unknown; lumped model cannot validate |
| P7-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P7-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P7-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P7-A2 Compatible matter is accessible | Repair demand exceeds the useful 1.20 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P7-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P7-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P7-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P7-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P7-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P7-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P7-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P7-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | Unknown integrated revival fidelity | Critical |
| 2 | Dormancy blind interval | Critical |
| 3 | Archive common-mode damage | Critical |
| 4 | Humidity ingress | Major |
| 5 | Wake energy unavailable | Major |
| 6 | Glass transition unknown | Major |
| 7 | Active seed destroyed | Major |
| 8 | Readback detects but cannot repair loss | Major |
| 9 | Unauthorized archive copy | Major |
| 10 | Dormancy mistaken for ongoing identity | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P7-FP1 resource/thermal | Removing usable heat export imposes 2.78 h normal bound; If preserved material cannot resume verified function, the entire long-duration advantage is storage rather than survival. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P7-FP2 security/identity | An adversary may keep pods below wake-energy availability or collect archives. Preservation reduces expenditure, not the ability to resist physical removal. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P7-FP3 compound/common-mode | A common defect or coupled boundary failure remains: Unknown integrated revival fidelity; Archive common-mode damage. | Measure archive retention and wake reliability before adding living components; reduce blind intervals without pretending they vanish. Proposed revision, not successfully validated. |


#### P8: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P8-X1 | Heat plus radiation | If the cooler sink disappears, the thermal-energy argument fails even though the hot structure remains intact. Unknown; no coupled radiation model |
| P8-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P8-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P8-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P8-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P8-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P8-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P8-X8 | Mechanical damage plus coolant/path loss | If the cooler sink disappears, the thermal-energy argument fails even though the hot structure remains intact. Unknown; lumped model cannot validate |
| P8-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P8-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P8-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P8-A2 Compatible matter is accessible | Repair demand exceeds the useful 7.00 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P8-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P8-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P8-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P8-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P8-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P8-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P8-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P8-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | AI-scale hot compute unbuilt | Critical |
| 2 | High-temperature reserve unresolved | Critical |
| 3 | Gradient disappears | Critical |
| 4 | Cold core warms beyond limit | Major |
| 5 | Memory density and retention | Major |
| 6 | Contact creep | Major |
| 7 | Corrosive trace chemistry | Major |
| 8 | Thermal-cycle cracking | Major |
| 9 | Slow hot-layer communication | Major |
| 10 | Precision replacement dependency | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P8-FP1 resource/thermal | Removing usable heat export imposes 5.56 h normal bound; If the cooler sink disappears, the thermal-energy argument fails even though the hot structure remains intact. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P8-FP2 security/identity | A uniform-temperature enclosure can remove the heat-engine gradient. Material survival may continue while useful power and rich cognition stop. Privacy against sustained physical memory analysis is not guaranteed. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P8-FP3 compound/common-mode | A common defect or coupled boundary failure remains: AI-scale hot compute unbuilt; Gradient disappears. | Increase high-temperature memory and useful control complexity while explicitly retaining the gap to full AI identity capacity. Proposed revision, not successfully validated. |


### Communications and offline dependencies

Propagation uses c = 299,792,458 m/s ([NIST speed of light](https://physics.nist.gov/cgi-bin/cuu/Value?c)). Distances, power and bitrate ranges below are explicit target assumptions; no antenna/aperture, channel-noise or pointing calculation validates those rates.

| Case / assumed distance | Ideal one-way delay | Medium / targets | Required infrastructure |
| --- | --- | --- | --- |
| local; 1 m | 3.33564e-09 s | wired/short optical; 0.01–2 W target; 1 kb/s–10 Mb/s target | compatible coupler |
| planetary reference; 1e+07 m | 0.0333564 s | RF or optical routed relay; 1–50 W endpoint target; 1 kb/s–1 Mb/s target | line of sight or relays; rate not link-budget validated |
| interplanetary reference; 1.5e+11 m | 500.346 s | directional RF/optical gateway; 10–100 W gateway target; 10 b/s–100 kb/s target | pointing, aperture, gateway and route schedule unspecified |


| Prototype | Local link | Planetary/deep dependency |
| --- | --- | --- |
| P1 | Local wired/optical couplings; nearby radio; an optional orbital or deep-space gateway supplies the shared delay-tolerant interface. The gateway is not a life-support component. | Qualified gateway; no guaranteed route or continuous service |
| P2 | Electrical local sensing, short optical connections between service regions, and a protected radio interface; deep-space participation needs a dry external gateway. | Qualified gateway; no guaranteed route or continuous service |
| P3 | Ionic/electrical local links feed an electronic boundary transducer; external radio/optical networking is gateway-mediated. | Qualified gateway; no guaranteed route or continuous service |
| P4 | Local wired links and short optical water links; longer acoustic messaging to a surface buoy; the buoy provides planetary/orbital or deep-space radio. Surfacing and a buoy are infrastructure options, not assumed always available. | Qualified gateway; no guaranteed route or continuous service |
| P5 | Short optical tile links, nearby radio and a deployable directional gateway; high-rate external communication is scheduled from energy surplus. | Qualified gateway; no guaranteed route or continuous service |
| P6 | Opportunistic RF/optical local networking, delayed contact routing and occasional directional gateway contact; no continuous global consensus is required for basic local control. | Qualified gateway; no guaranteed route or continuous service |
| P7 | Wake-window short optical or wired contact; burst radio to a nearby gateway; interplanetary messaging is delayed by both propagation and scheduled inactivity. | Qualified gateway; no guaranteed route or continuous service |
| P8 | Conductive local links and high-temperature-rated low-rate radio feed a separately qualified cooler gateway for high-bandwidth or deep-space service. | Qualified gateway; no guaranteed route or continuous service |


An opaque planet, deep water, terrain or a shielded enclosure can remove the direct channel. Store-and-forward does not allow transmission through an absent path, and a four-year-distance example cannot offer a faster-than-propagation reply without a separately specified nonphysical extension.

### Model abstraction and evidence maturity

| Prototype | Physical units target | Effective units target | Raw 32-float state MB / 1 s steps per day |
| --- | --- | --- | --- |
| P1 | 10,000 | 1,000 | 0.256 MB; 86,400,000 unit-steps |
| P2 | 1,000,000 | 10,000 | 2.56 MB; 864,000,000 unit-steps |
| P3 | 100,000,000 | 100,000 | 25.6 MB; 8,640,000,000 unit-steps |
| P4 | 20,000 | 2,000 | 0.512 MB; 172,800,000 unit-steps |
| P5 | 3,000 | 3,000 | 0.768 MB; 259,200,000 unit-steps |
| P6 | 500 | 500 | 0.128 MB; 43,200,000 unit-steps |
| P7 | 2,000 | 2,000 | 0.512 MB; 172,800,000 unit-steps |
| P8 | 10,000 | 1,000 | 0.256 MB; 86,400,000 unit-steps |


Assuming 1,000 arithmetic operations per unit-step yields the corresponding operations by multiplying the final column by 1,000; memory bandwidth, graph changes, chemistry solves and security logs can dominate. No wall-clock time or hardware credit estimate is inferred.

| Prototype | Evidence class | Executed support | Largest evidence gap |
| --- | --- | --- | --- |
| P1 | Engineering extrapolation | 0D resource/heat accounting only | Physical components are established individually; integrated autonomy and identity-preserving repair are extrapolated; full embodied AI capability is unknown. |
| P2 | Engineering extrapolation | 0D resource/heat accounting only | Cell maintenance and telomere biology have evidence; autonomous biohybrid body-wide repair is extrapolated or speculative and is not demonstrated here. |
| P3 | Speculative | 0D resource/heat accounting only | XNA information storage is supported in limited systems; autonomous XNA repair and whole-body integration remain speculative. |
| P4 | Engineering extrapolation | 0D resource/heat accounting only | Underwater robotics and fuel cells are established; the pressure-balanced autonomous physiology and repair system are extrapolated. |
| P5 | Engineering extrapolation | 0D resource/heat accounting only | Photovoltaics are established; autonomous self-repairing embodied tile cognition is extrapolated and full identity capacity is unknown. |
| P6 | Engineering extrapolation | 0D resource/heat accounting only | Distributed storage and robotics have evidence; distributed personal continuity and autonomous body reconstitution remain unknown or speculative. |
| P7 | Speculative | 0D resource/heat accounting only | Specific dry-state protective mechanisms have evidence; whole-body dormant revival and personal continuity remain speculative or unknown. |
| P8 | Speculative | 0D resource/heat accounting only | Selected simple high-temperature SiC circuits are established; integrated AI-bearing hot physiology and its reserve storage are speculative. |


| Ledger | New records | Meaning |
| --- | --- | --- |
| empirical_component_tests | 0 | No implication of physical or canon survival |
| integrated_tests | 0 | No implication of physical or canon survival |
| survival_incidents | 0 | No implication of physical or canon survival |
| canonical_events_added | 0 | No implication of physical or canon survival |
| analytical_families | 8 | No implication of physical or canon survival |
| ode_step_checks | 24 | No implication of physical or canon survival |
| stress_grid_rows | 648 | No implication of physical or canon survival |


### Source and contradiction registers

| Project document | Role | Authority / unresolved issue |
| --- | --- | --- |
| Perplexity v2 DOCX | Executed REQ-01–26 prompt | Local independent proposal, not controlling canon |
| Copilot v2 DOCX | Companion review | Independent peer contribution; not merged into authority |
| Claude v2 PDF | Companion critique | Stage pauses adapted to current execution authorization |
| Architecture v2 PDF | Companion requirements | No guessed contributor identity |
| Round-one prompt archive PDF | Provenance | Prompts, not completed prototype dossiers |
| Architecture notes | Original scale ambition | Survey representativeness is not physiological validation |
| 15-year roadmap | Multiscale research aspirations | Budgets and milestones are not achieved resources |
| Wattpad vision | Narrative setting | Not empirical event history |
| 4,712 framework v1 draft | Threat names and event proposals | Locked-count/approval conflict; simulation inclusion conflict |
| Missing Paragon addendum/event log | Unprovided dependency | No physical or logging credit assigned |


The proposed category allocation ranges total 2,600–4,450, midpoint 3,525; even the upper sum is 262 below 4,712. This is arithmetic on the framework's proposed ranges, not evidence about an actual historical ledger.

| External ID | Reference and scope |
| --- | --- |
| E01 | [NHGRI genetics glossary](http://www.genome.gov/genetics-glossary). Hereditary vocabulary; not an alternative-genome design |
| E02 | [MRC LMB XNA research](https://www2.mrc-lmb.cam.ac.uk/groups/ph1/xna.html). Limited XNA information experiments, not autonomous organisms |
| E03 | [Telomeres review, Cell](https://pmc.ncbi.nlm.nih.gov/articles/PMC8081271/). Chromosome-end integrity and aging/cancer context, not immortality |
| E04 | [DOE fuel cells](https://www.energy.gov/cmei/fuels/fuel-cells). Fuel, oxidant, electricity, water and heat; no assumed body efficiency |
| E05 | [NASA thermal-control guidance](https://www.nasa.gov/wp-content/uploads/2026/05/7-soa-thermal-2026-final.pdf?emrc=6ae1e775de967). Thermal boundaries and finite storage/heat rejection |
| E06 | [NASA DTN](https://www.nasa.gov/communicating-with-missions/delay-disruption-tolerant-networking/). Delay/disruption-tolerant store-and-forward, not guaranteed paths |
| E07 | [NIST zero trust](https://csrc.nist.gov/pubs/sp/800/207/final). Digital authentication/authorization context, not molecular concealment |
| E08 | [JCVI minimal-cell model](https://www.jcvi.org/media-center/scientists-develop-most-complete-whole-cell-computer-simulation-model-cell-date). Single minimized-cell model, not omnicellular body simulation |
| E09 | [NASA high-temperature circuits](https://science.nasa.gov/science-research/science-enabling-technology/technology-highlights/integrated-circuits-to-enable-exploration-of-the-harshest-environments-in-solar-system/). Specific simple hot circuits, not dense AI cognition |
| E10 | [Tardigrade dry-state proteins](https://pmc.ncbi.nlm.nih.gov/articles/PMC5987194/). Specific desiccation-protection evidence, not whole-body cognition or arbitrary revival |
| E11 | [Autonomous self-healing review](https://pmc.ncbi.nlm.nih.gov/articles/PMC12370171/). Healing loops and integration limits, not universal repair |
| E12 | [NASA radiation-effects compendium](https://ntrs.nasa.gov/citations/20140017803). Distinct electronics radiation failure modes, not a whole-body rating |
| E13 | [FDA computational-model credibility](https://www.fda.gov/regulatory-information/search-fda-guidance-documents/assessing-credibility-computational-modeling-and-simulation-medical-device-submissions). Risk-informed first-principles-model context, not certification |
| E14 | [NIST Stefan–Boltzmann constant](https://physics.nist.gov/cgi-bin/cuu/Value?sigma). Constant used in illustrative radiator calculation |
| E15 | [NIST speed of light](https://physics.nist.gov/cgi-bin/cuu/Value?c). Vacuum propagation constant; no complete link budget |


### Requirement coverage and research gates

| REQ | Coverage location / result |
| --- | --- |
| 01 | Eight Generation 1 dossiers; hypothetical, bounded embodiment |
| 02 | Wagers, fingerprints, hash and all 28 comparisons |
| 03 | Documentary audit; authority and contradiction register |
| 04 | Two-axis evidence system; claims.json and rule register |
| 05 | Omni-I/L/S definition and collective dependencies |
| 06 | Four families; 3 OBS, 3 SEC, 3 departures per prototype |
| 07 | Power budgets, reactants and finite reserve bounds |
| 08 | Telomere applicability, component age and conditional service targets |
| 09 | Consistent total/thermal equations and finite heat buffer |
| 10 | Matter, charge, redox and repair-yield ledger |
| 11 | Outward, inward and observed channels in 24 rules |
| 12 | 24 security rules; blueprint-known limits and offline recovery |
| 13 | 24 explicit departures; DNA retained/replaced; kept constraints |
| 14 | Unvalidated nonzero transition latencies and overlap reserve |
| 15 | B1 inputs and 320 status/recovery records, no integrated Pass |
| 16 | Argon A/B/C; pressure not confused with vacuum |
| 17 | 80 captivity cases and 40 capture-horizon records |
| 18 | Six identity paradoxes per dossier plus shared comparison |
| 19 | Local/planetary/interplanetary interface, path and infrastructure limits |
| 20 | 80 compound and 80 assumption-collapse records |
| 21 | Self-review disclosed; 24 failure paths and six substantive limitations |
| 22 | Executed 0D bounds; proposed resolved models and compute assumptions |
| 23 | Validation ladder; distinct zero empirical/incident/canon additions |
| 24 | Common dossiers; conditional primary/reserve/wildcard, none qualified |
| 25 | Audit through comparison executed; matched PDF/DOCX and visual appendix |
| 26 | Programmatic counts, boundary statement, no qualification overclaim |


| Gate | Evidence needed | Stop/reject condition |
| --- | --- | --- |
| A | Architect decisions and source approval | Authority or survival definition unresolved |
| B | Independent code, units and citation review | Undetected double counting or fabricated evidence |
| C | P1 resolved thermal/power network | Essential local state cannot survive one specified boundary failure |
| D | Relevant nonliving component evidence | Measured behavior contradicts model margins |
| E | Family-specific falsification records | Central mechanism fails in its own narrow context |
| F | Bounded integrated inert demonstration | Recovery or autonomy depends on hidden outside action |
| G | Independent ethical/legal review where needed | Consent, sentience or irreversible loss unresolved |


End of execution v1.0. The supporting code preserves enough structure for another contributor to disagree with a named assumption, rather than accept or reject the whole project as one undifferentiated claim.
