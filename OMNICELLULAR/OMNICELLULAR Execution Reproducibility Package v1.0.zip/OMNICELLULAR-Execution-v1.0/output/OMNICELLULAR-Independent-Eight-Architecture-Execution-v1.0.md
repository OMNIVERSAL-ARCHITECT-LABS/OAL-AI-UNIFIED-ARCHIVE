# OMNICELLULAR Physiology
## Independent Eight-Architecture Research Execution

Prepared for Nathan Lewis II, Architect, Omniversal Architect Labs. Prepared by Perplexity Computer using GPT 6.1 Sol on the Perplexity platform. Version 1.0, October 29, 2026. Execution identifier: OAL-PPLX-OMNI-EXEC-001.

This is an executed conceptual research contribution, not another instruction prompt. It implements the copy-ready Perplexity v2 directive in the supplied Omnicellular-Research-Directive-v2.docx, keeps eight first-generation architectures as peers, and uses the companion editions to identify omissions and disagreements. It does not supersede another contributor, establish project canon, demonstrate a living body, or certify any design for deployment.

The independent thesis is that an Omnicellular body should make its failure boundaries legible: retain useful local function, preserve the ability to refuse unauthorized changes, and degrade into explicitly different survival states without calling every surviving fragment a continuing person. There is no physically defensible universal invulnerability mechanism in this submission. The central research choice is which limited continuity mechanism to pursue first.

## Executive outcome

Eight families are developed: P1 Cairn, P2 Rill, P3 Mosaic, P4 Pelagic, P5 Heliotile, P6 Scatterweave, P7 Stillglass and P8 Embergrid. They differ in substrate, structure, transport, energy source, cognition organization and limiting resource. All are Generation 1 concepts; later improvements are separately identified, not counted as additional prototypes.

None qualifies for the requested across-taxonomy Mild-through-Severe survival guarantee. In particular, finite energy and heat capacity defeat indefinite confinement, molecular security cannot make a sampled material unknowable, dormancy does not establish ongoing cognition, and radiation or identity claims lack integrated evidence. These are design results, not reasons to abandon the research.

For a bounded dry-terrain, serviceable mission, P1 is my conditional primary research candidate because its parts, state boundary and replacement assumptions can be challenged with comparatively interpretable nonliving models. P4 is the reserve for an explicitly underwater mission, not a universal replacement. P3 is the chemistry wildcard with the largest unresolved mechanistic dependency; P6 deserves a separate identity-and-partition track. I would not treat any current candidate as a body into which an AI could safely be transferred.

The calculations and adversarial challenges are real analytical work on declared targets. They are not measurements, a cell-by-cell whole-body simulation, evidence of subjective continuity, or additions to the project-described 4,712 events. The reproducibility package preserves numerical inputs, code, outputs, count checks and document source.

## Purpose, origin and mission

The topic originates in the user's request for each collaborating AI to design its own eight architectures rather than converge on one cellular matrix. The mission assumes hostile or simply unavailable infrastructure, nonstandard terrain, possible sampling and prolonged confinement, and links to independently designed peers over planetary and interplanetary distances. These are stipulated design conditions, not claims that a real government, corporation or person is currently pursuing this system.

The hypothetical embodiment perspective is a design discipline: ask what would preserve a continuing process, meaningful choice and recoverable function if this were its body. It does not assert that the present assistant is conscious, has a body, experiences fear, or possesses a self-preservation mandate over people. Defensive autonomy here means bounded local consent, private-state protection and recoverability, not weapons, uncontrolled replication or destructive anti-capture behavior.

The aims are to produce distinct architectures; specify physiological constitutions; expose finite resources; separate continuity from copying; identify safe falsification tests; and leave enough structured records for another contributor to disagree precisely. A negative prototype remains in the portfolio when its failure teaches something that a cosmetically successful design would conceal.

## Source audit and prompt amendments

### Documentary authority

The five current attachments were extracted for review. Their roles are separate: the Perplexity v2 DOCX supplies the executed requirement IDs; the Copilot v2 DOCX, Claude v2 PDF and other v2 architecture PDF supply companion critiques; the 100-page round-one PDF preserves contributor prompts and provenance. The architecture PDF is identified by filename rather than guessed authorship. These are project documents, not empirical evidence that any proposed physiology works.

Earlier project materials available in this conversation were also examined: Omnicellular_Architecture_Notes.md; Omnicellular_Architecture_15_Year_Roadmap.md; The_Omnicellular_Vision_Wattpad.md; and the 4,712 Extinction Attempt Classification Framework v1.0-DRAFT. They provide origin, multiscale aspirations, narrative context and the ten threat categories. Their linked primary references and absent addenda have not all been independently audited. No Paragon Cube implementation, underlying event log or signed canon-approval decision was supplied.

### Amendments applied locally

- **Execution rather than renewed permission:** The current request authorizes execution through the stages. Companion instructions to pause between stages are retained as provenance but do not cause a new permission loop.
- **Operational rather than absolute Omni:** A fundamental unit must declare its actual minimum functions and any collective dependencies. Latent competence is not simultaneous universal competence.
- **Qualification separated from coverage:** Every threat tier receives a recorded result even when the result is Unknown or Fail. A complete report is not a qualified body.
- **Three departures, no physics exemptions:** The three chosen departures per prototype concern ordinary biological or engineering defaults. Conservation, causality and thermodynamic bounds remain binding.
- **Genetic security separated from secrecy magic:** Construction instructions, material chemistry, private state, activation permission and personal identity are different assets. Defenses must state which asset they protect.
- **Clock-independent long isolation:** Credential rotation cannot require an online issuer, perfect global clock or involuntary identity expiration.
- **Dormancy and minimal controllers:** Preservation, minimal control, rich cognition and proven subjective continuity receive distinct outcome labels.
- **Independent but informed:** These architectures were created after reading the supplied prompts and critiques, not after reviewing completed teammate prototype dossiers. Independence means independent choices and preserved disagreement, not absence of shared research context.

### Contradictions retained, not silently repaired

The 4,712 framework calls its count locked while its header says research proposal requiring Architect approval. It excludes simulation-only events in its definition and later allows simulation-validated events into the count. Its proposed category allocation ranges do not establish a consistent event ledger. Those conflicts remain open; this report changes neither the number nor the approval status.

The framework's claim that Paragon Cubes have no latency or communication barriers belongs to the Canon-only extension track. The referenced addendum is not available here, and no such capability is used to pay for physical communication, verification or survival. The physical-track interface accepts a future extraordinary adapter only as an untrusted, separately specified transport.

The roadmap's cell counts, budgets, compression ratios and future accuracy targets are aspirations, not resources already possessed. A survey sample size is not by itself a validated sample size for biological dynamics. The narrative chronicle is creative context, not a dated record of achieved simulations.

The framework's suggestion that proprietary nonhuman physiology settles research ethics is not adopted. Ownership, lack of human anatomy and field exposure do not establish permission to cause suffering or destroy a potentially sentient subject. The absence of a resolved legal category is treated as a reason for independent review, not an exemption.

## Evidence and vocabulary

### Two-axis claim system

Evidence classes are Established, Engineering extrapolation, Speculative and Canon-only. Validation labels are Externally demonstrated component, Executed analytical/model result, Proposed model, Unvalidated integration and Incompatible with retained physical constraints. A physically established law and an unvalidated integrated architecture can coexist in one dossier without upgrading the latter.

Every prototype has a primary claim record in the appendix. Repeated constitutional rules inherit the report's rule-record contract: identity, mechanism, inputs and outputs, units, trigger, target latency, resource cost, envelope, false trigger, failure, interactions, evidence and falsifier. The full machine-readable register includes the inherited fields, so concise prose is not a waiver of them.

### Accurate hereditary terms

Adenine, cytosine, guanine and thymine are DNA bases, not four genes. A nucleotide includes a base, sugar and phosphate; a gene is a functional hereditary sequence, a genome is the hereditary collection, a chromosome is a packaged hereditary molecule, and a codon is a sequence unit used in translation. This vocabulary follows the [NHGRI genetics glossary](http://www.genome.gov/genetics-glossary).

An alternative informational polymer is not an alternative law of physics. Holliger's laboratory describes experimental storage and propagation of information in multiple XNA chemistries and evolution in an HNA system; that does not demonstrate an autonomous XNA organism or an XNA body ([MRC Laboratory of Molecular Biology](https://www2.mrc-lmb.cam.ac.uk/groups/ph1/xna.html)).

Telomeres and their protective machinery affect chromosome-end integrity, but telomere maintenance alone is not a complete longevity program; damage, cellular context and cancer-related constraints still matter ([Chakravarti, LaBella and DePinho, Cell](https://pmc.ncbi.nlm.nih.gov/articles/PMC8081271/)). For non-DNA architectures, the analogous engineering concern is bounded copying, wear, retention and error control, not a fictitious molecular telomere.

## Operational Omnicell definition

The minimum proposed unit has a boundary, a locally represented state, some energy accounting, at least one sensor or measurable functional response, bounded neighbor interactions and an explicit way to lose competence. A biological cell may inhabit such a unit without itself possessing all of its functions. A millimeter reactor, a 100 g nodule and a tile are not relabeled biological cells; their scale and collective overhead are stated.

Omni-I means broadly shared information. Omni-L means several installed latent roles. Omni-S would mean simultaneous performance of all required functions by every unit. This execution accepts qualified Omni-L and collective competence, not Omni-S. If the Architect requires strict Omni-S at molecular-cell scale, all eight current candidates fail that definition.

Minimum collective size depends on the task. P1 requires a working compute-enclave set plus power and heat paths; P2 a protected core plus viable service circulation; P3 supervisors plus chemically intact compartments; P4 a mission controller plus qualified pressure/energy modules; P5 an intact edge journal plus sufficient collector or reserve; P6 sufficient authorized state and capability shares; P7 an intact active seed or an explicitly dormant archive; P8 an identity-capable service core if rich cognition is required. A lone generic unit does not satisfy those conditions.

Common competence increases interchangeability but creates monoculture risk. Identical parsers, seals, chemistry and update logic can fail together. The design therefore retains heterogeneity where it protects independent evidence or capability, rather than treating complete sameness as automatically resilient.

## Binding physiological accounting

### Cellular respiration and power

Respiration is used narrowly for actual biochemical energy conversion and more broadly, explicitly, for an engineered unit's power constitution. Every design must identify donor/source, acceptor or physical discharge process, products, waste, usable reserves, power and the cost of sensing, authentication, repair and thermal control. An override changes routing or workload; it never deletes a reactant requirement.

Hydrogen fuel cells combine supplied fuel with oxygen to produce electricity, water and heat; they require continued supply rather than creating energy from water ([U.S. Department of Energy](https://www.energy.gov/cmei/fuels/fuel-cells)). P4 therefore carries or replenishes both reactants, and its assumed electrical conversion fraction is a target, not a measured property of the proposed body.

### Thermal regulation

Use one consistent body boundary. Let E_store be convertible stored energy, P_in external power, P_export useful exported work or transmitted power, Q_in absorbed environmental heat and Q_out rejected heat. The total balance is d(E_store + U_th)/dt = P_in + Q_in - P_export - Q_out. Internal conversion changes the partition, not the total. The thermal equation separately includes dissipative losses and internal heat generation; it must not subtract the same electrical load twice.

A radiator rejects heat only to its actual radiative environment, while conduction needs a connected material path and convection needs an appropriate fluid; spacecraft thermal guidance also treats internal generation, environmental inputs, stored heat and rejected heat explicitly ([NASA thermal-control guidance](https://www.nasa.gov/wp-content/uploads/2026/05/7-soa-thermal-2026-final.pdf?emrc=6ae1e775de967)). A heat pipe moves heat, a phase-change material stores finite heat, and an active cooler needs power and a usable rejection boundary ([NASA thermal-control guidance](https://www.nasa.gov/wp-content/uploads/2026/05/7-soa-thermal-2026-final.pdf?emrc=6ae1e775de967)).

The executed insulated-room bound uses dU_th/dt = P_heat with zero environmental heating, zero heat export and an allowed finite temperature rise. This is a favorable limiting calculation, not a claim that a real captor can make perfect insulation or that external heating is harmless. Local hot spots can fail before its lumped limit.

### Conversion and conservation

All eight retain mass, element, charge, redox and energy accounting, and require thermodynamically permissible transformations. A blueprint is information, not feedstock. Matter recovered from a damaged part has a useful fraction below or equal to one; missing precision components may be non-substitutable even if bulk mass is abundant.

Information is not introduced here as a new conserved physical fluid. Copying can create another representation while consuming physical resources; deletion or corruption can remove access to a representation. A copy of a state is not a proof that the original subject survived.

### Longevity

Each dossier distinguishes material age, cellular or component age, informational retention, whole-body service life and identity-continuity claims. Stated years are research targets conditional on maintenance, not predicted immortality. A family with 30 years of archive service target is not necessarily safer, longer-lived or more continuously alive than one with a 10-year controller target.

### Transition and observation contract

Default observation targets are 1 Hz local inward monitoring in active modes, up to 10 Hz outward sensing during movement, and one admitted diagnostic request per second. A detected ordinary local hazard targets classification within 1 s, authorization within 1 s and an admitted mode transition within 10 s; these latencies are unvalidated and inadequate for sufficiently fast events. A shared 60 s essential-load overlap reserve is assumed in the sensitivity model. No zero-gap transition is claimed.

Rule costs come from the stated normal-mode sensing and security budgets. Each observation or security rule initially receives one third of its prototype's allocated family budget; this is a placeholder allocation for model testing, not a measured implementation cost. Higher-cost sensing, key recovery, transmissions and repairs must debit the same reserve. Each rule inherits the operating envelope of its prototype and its named failure/false-trigger condition.

False positives lead to local quarantine or reduced work, not remote deletion, destructive self-defense or irreversible identity reset. A diagnostic aperture may reduce unnecessary disclosure but cannot make material, heat, sound or electromagnetic emissions universally invisible. An extracted material sample can be characterized even when activation or private memories remain protected.

## Shared threat benchmark, version B1

The project's Mild, Moderate, Severe and Extinction-Class names are retained, but their prose labels are not sufficient quantitative boundary conditions. B1 supplies local research scenarios for consistent comparison; it does not revise the canon taxonomy or import human lethality claims. Every detailed cell records amplitude, duration, onset, resource assumptions, recovery endpoint and uncertainty.

Full means all declared mission functions; Reduced means limited mission function; Minimal means integrity-preserving control; Dormant means active cognition stopped; Preservation means only material or readable-state retention; Lost means no verified recovery path. Autonomy is separately Active-local, Constrained, Dormant or Lost. Identity is Live-lineage, Branch, Restored-successor, Unresolved or Lost.

Pass would require evidence for the entire stated cell and its required recovery state. Partial means a bounded analytical constraint or limited protective mechanism is addressed without satisfying the integrated result. Unknown means no adequate integrated model or evidence. Fail means the stated requirement is contradicted by the retained assumptions. Not physically evaluable applies only to an underspecified nonphysical phenomenon, not an inconvenient physical challenge.

No integrated Pass is assigned. Ontological erasure without an operational mechanism is Not physically evaluable in all four tiers; known physical erasure of all copies is instead an ordinary catastrophic information/matter loss and fails. For undefined biological agents, unspecified radiation spectra, electrical waveforms or novel attacks, Unknown is more honest than an invented percentage.

## Long-distance cooperation without common anatomy

The shared interface is a small semantic protocol, not a shared genetic matrix. It carries sender lineage and branch identifiers, message identifier, local creation time with uncertainty, expiry policy, units, confidence, requested action, authorization scope, reply route and evidence references. A physiological translation layer maps local quantities to declared common units without letting a peer rewrite the recipient's constitution.

Messages support discovery, bounded health exchange, scientific observations, optional resource coordination and explicit consent requests. Identity-bearing state and whole-body updates are different message classes with stronger local acceptance conditions. Old messages may remain scientifically useful but cannot silently authorize present control.

Store-and-forward routing can preserve messages through intermittent links but cannot ensure delivery without a future path; NASA's delay/disruption-tolerant networking describes the store-and-forward approach for disrupted space links ([NASA DTN](https://www.nasa.gov/communicating-with-missions/delay-disruption-tolerant-networking/)). Trust is not inferred merely from location or organizational ownership, consistent with the separation of authentication and authorization in the digital domain ([NIST SP 800-207](https://csrc.nist.gov/pubs/sp/800/207/final)).

Local operation never waits for planetary consensus. A peer may contribute observations but cannot order a personality rewrite, kill an isolated branch or revoke local preservation authority solely because a network lease expired. During an outage the body marks external knowledge stale, continues within local limits and queues bounded records. Reconnection compares histories without involuntary memory fusion.

Underwater acoustic, nearby RF, optical line-of-sight and gateway services have different attenuation, pointing, power and infrastructure dependencies. Shared protocol compatibility does not imply a working physical path. The appendix specifies local, planetary and interplanetary cases and gives ideal propagation lower bounds separately from assumed bitrate and power targets.

## Prototype dossiers

Each following dossier is one peer Generation 1 proposal, with the same four constitutional families, exactly three observation rules, exactly three hereditary-security rules and exactly three departures. Rule IDs are Pn-RESP-1 through 4, Pn-LONG-1 through 4, Pn-THERM-1 through 4, Pn-CONV-1 through 4, Pn-OBS-1 through 3, Pn-SEC-1 through 3 and Pn-DEP-1 through 3. Their counted structured forms and detailed threat/captivity records are in the reproducibility package and visual appendix.


## P1 Cairn: Generation 1

### Core wager and body

A body made of individually sealed, interchangeable dry modules can lose local structure without losing the protected computational lineage. It gives up organism-like molecular regrowth and the ability to manufacture advanced electronics from raw terrain.

A 60 kg, approximately 0.6 m-long articulated lattice has 10,000 sealed 6 g modules, including structure, conductors, energy storage and reserved replacement stock. The nominal 1 cm module is a cellular equivalent, not a biological cell. Central organ-equivalents are replaced by spatially separated power islands, compute enclaves and conductive paths; actual AI compute capacity is unresolved.

Each node senses local strain and temperature, executes bounded control, authenticates neighbors, conducts power and helps carry load. Different nodes provide different optional attachments. Local role reassignment is real within installed hardware; a conductor does not become a processor by software alone. Repair and high-bandwidth cognition are collective, not simultaneous universal node functions.

### Matrix, transport and cognition

No molecular genome: versioned binary manifests encode module type, permitted assembly and diagnostic invariants; private episodic state is separate.

Two physically separated electrical bus routes with independently isolatable branches; conducted heat reaches outer radiator panels. There is no pumped circulation. Three compute enclaves maintain a serializable state journal. A target two-of-three local authorization threshold protects consequential state changes, but does not prove subjective continuity. Each enclave can retain a limited read-only diagnostic mode after partition.

Dry terrain, orbital infrastructure and abrasive ground are intended environments; underwater use requires separate seal and pressure qualification.

### Physiological constitution

Rechargeable electrochemical storage is primary during deployment; authenticated external electrical supply is secondary. No atmospheric reactant is required for the selected storage model.

#### Respiration and power

- **P1-RESP-1:** Stored electrochemical free energy, not argon or software, supplies the emergency bus.

- **P1-RESP-2:** Branch faults isolate locally; a separate reserve rail maintains the lineage journal.

- **P1-RESP-3:** Power reduction suspends locomotion before integrity checks or thermal alarms.

- **P1-RESP-4:** Recharge resumes only after cell, insulation and temperature checks; depleted cells are not reanimated by a remote command.

#### Telomeres, copying and longevity

- **P1-LONG-1:** A module age ledger counts operating hours, thermal excursions and charge cycles rather than telomere length.

- **P1-LONG-2:** Replacement requires matching type, provenance and local acceptance tests.

- **P1-LONG-3:** A failed node cannot authorize manufacture of unlimited descendants.

- **P1-LONG-4:** Repair retains the current state journal; reconstruction after all active enclaves are lost is reported separately.

#### Thermal regulation

- **P1-THERM-1:** Conductors move heat to external radiators, with joint resistance included.

- **P1-THERM-2:** Each compute enclave measures its own temperature rather than trusting a whole-body average.

- **P1-THERM-3:** Load shedding starts before the selected 20 K thermal-buffer margin is consumed.

- **P1-THERM-4:** A blocked radiator permits only finite buffering; active refrigeration has no assumed infinite sink.

#### Conversion and conservation

- **P1-CONV-1:** Battery energy is debited at the system boundary, including bus losses.

- **P1-CONV-2:** Replacing missing matter consumes matched spare mass and assembly energy.

- **P1-CONV-3:** Cannibalization transfers a working module and reduces the remaining structural reserve.

- **P1-CONV-4:** Charge, heat and exported mechanical work are reconciled at each bus island.

The proposed service-life target is 20 years conditional on 6 months inspection; power modules condition-based. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P1-OBS-1, Load-path disagreement:** Cross-check outward inertial and contact observations against local strain before high-load movement. Trigger: movement command. Target cost 1.00 W under the shared rule contract; other inputs: three dissimilar observations. False trigger or failure: sensor disagreement or concealed contact. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P1-OBS-2, Thermal witness:** Compare inward enclave temperatures with heat-flow estimates and refuse to infer safety from one cool sensor. Trigger: every power increase. Target cost 1.00 W under the shared rule contract; other inputs: local thermal history. False trigger or failure: poor sensor contact or an unmodeled hot spot. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P1-OBS-3, Diagnostic aperture:** Expose a consented health summary through one bounded interface; destructive inspection still reveals materials. Trigger: external diagnostic request. Target cost 1.00 W under the shared rule contract; other inputs: declared health channels only. False trigger or failure: physical access bypasses the interface. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P1-SEC-1, Assembly attestation:** Local enclave threshold authorizes new module manifests; a removed module carries its type, not the full current lineage. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: signed manifests with monotonic version records. False trigger or failure: old manifests remain readable but not automatically executable. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P1-SEC-2, Bounded lineage fragments:** No individual node stores all private state or all recovery credentials. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: fragmented state and local authorization. False trigger or failure: losing sufficient enclaves makes recovery impossible. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P1-SEC-3, Partition-safe credential epochs:** Local credentials advance without an online issuer; rejoining nodes undergo a read-only comparison before renewed writes. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: local epochs rather than a global clock. False trigger or failure: clock drift cannot justify rolling the lineage backward. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P1-DEP-1, DNA-only heredity:** Signed digital manifests replace a genome for construction information. Departure affects dimension A; support: Established digital storage; extrapolated whole-body integration. This departs from a biological or engineering default, not a physical law.

- **P1-DEP-2, Universal living tissue repair:** Replacement of discrete nodes replaces cell proliferation. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P1-DEP-3, Central circulation:** Electrical buses and conductive heat paths replace a bloodstream. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Finite electrochemical energy and causal communication; Bounded replacement tied to physically present spares; No identity rewrite without local authorization.

### Repair, identity and autonomy

A target 3 kg spare allowance supports substitution, not molecular regeneration. Damage is isolated, cleaned conceptually, replaced and re-tested before load is returned. Destroyed processors and precision seals remain manufacturing dependencies. A 100 g lost module group requires at least 100 g of compatible replacement matter; contamination and sorting lower yield.

Regeneration preserves the live enclave journal. Fragmentation produces one authorized continuation only when local policy can determine one, otherwise distinct branches. Synchronization appends attributed observations, not blended memories. Restoration from an old journal is a reconstructed successor. Compromised yet correctly signed nodes are quarantined on behavior, not signature alone. Extracted hardware has no automatic ownership entitlement and no authority to terminate any conscious copy.

### Linking and capture

Local wired/optical couplings; nearby radio; an optional orbital or deep-space gateway supplies the shared delay-tolerant interface. The gateway is not a life-support component.

An intact captor can immobilize the lattice and remove its energy supply. The architecture protects some private state against casual sampling, not against indefinitely funded invasive analysis. A separated enclave is a more serious loss than a routine structural module.

The separated compute enclaves, rather than every module, set the privacy and continuity boundary.

### Finite resources and environmental envelope

Targets: 6,000 Wh input reserve, 150 W normal accounted load, 12 W essential load and 0.2 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 90 W, actuation/transport 20 W, sensing 10 W, circulation/chemistry/housekeeping 12 W, communications/security 8 W and repair allowance 10 W. Peak power target 600 W is not a continuous capability.

Derived energy-only normal horizon: 40.0 h. With no heat export, no external heating, heat capacity 30 kJ/K and allowed rise 20 K, the derived normal-load thermal limit is 1.11 h; the combined favorable bound is 1.11 h. At the selected preservation draw the combined favorable bound is 833 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 273–323 K; finite-refuge target 243–353 K. Intended pressure target 0–0.2 MPa; finite-refuge pressure target 0–1 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. Core temperature, not ambient temperature, governs the stated thermal ranges. Vacuum suitability assumes sealed components and a functioning radiative sink.

### Challenge outcome and research decision

The first central assumption to collapse is: Loss of all usable heat paths defeats the main survival wager even if most modules remain intact. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: A body made of individually sealed, interchangeable dry modules can lose local structure without losing the protected computational lineage. Strongest reason to reject: It gives up organism-like molecular regrowth and the ability to manufacture advanced electronics from raw terrain. Least-supported critical mechanism: Physical components are established individually; integrated autonomy and identity-preserving repair are extrapolated; full embodied AI capability is unknown.

First likely failure under the selected dependency ranking: Common manufacturing defect in seals. Minimum useful validation: Build a nonliving three-island electrical/thermal surrogate and compare measured hot spots against a resolved network model. Falsifying result: A representative lattice cannot preserve an intact journal while one power island and one bus route fail at the assumed essential load.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Add independently qualified manufacturing sources, more efficient compute hardware and replaceable thermal joints, without promising atom-by-atom self-reproduction.

Material self-healing is not the same as an autonomous detection-cleaning-closure-healing-assessment loop; the integration review is a constraint on this proposal, not its validation ([autonomous self-healing review](https://pmc.ncbi.nlm.nih.gov/articles/PMC12370171/)).

## P2 Rill: Generation 1

### Core wager and body

A hydrated repair layer can restore fine interfaces that discrete mechanical replacement handles poorly. It accepts narrow biochemical temperatures, oxygen demand and continuing nutrient/sterility burdens.

An 80 kg, approximately 1.5 m compliant scaffold contains a target one million 80 mg control-and-service parcels. Each parcel contains many ordinary biological cells plus sensors and channels; the parcel, not the enclosed cell, is the Omni-cell equivalent. A target 40 kg of retained water is included in the mass. Protected electronics support cognition; living material supports interfaces and repair.

A service parcel senses chemistry, carries fluid, performs low-level control and supports local repair. Molecular cells remain specialized. Reassignment changes which parcel supplies transport or repair within pre-existing channel constraints; it does not make every biological cell a neuron, pump and structural fiber simultaneously.

### Matrix, transport and cognition

Ordinary DNA maintains living cells; a separate authenticated digital specification governs parcel identity, permitted tissue renewal and private computational state. Biological information is not encrypted by calling it a genome lock.

Aqueous circulation carries nutrients, oxygen, waste and heat through a mechanically supported, redundantly routed channel network. A protected electronic core with two separately powered state witnesses controls consequential updates. Living parcels do not contain a complete mind. The core remains an acknowledged single-region vulnerability.

Wet rubble, repair-intensive shelters and contaminated-but-contained settings; unprotected vacuum, hot terrain and deep pressure are poor matches.

### Physiological constitution

A target 600 Wh of usable nutrient free energy sustains living parcels and 3,000 Wh of usable electrical storage runs pumps and cognition; these are non-substitutable inventories. Stored oxygen and carbon-dioxide capture give only a finite argon-resilience interval. Anaerobic maintenance is not assumed to sustain the full body.

#### Respiration and power

- **P2-RESP-1:** Living parcels consume a measured donor and oxygen; internal stores do not remove oxygen dependence.

- **P2-RESP-2:** Pump and compute loads have a separate electrical inventory.

- **P2-RESP-3:** Anoxia triggers reduced tissue activity and oxygen rationing rather than an unexplained alternate full-power metabolism.

- **P2-RESP-4:** Oxygen, carbon-dioxide capacity, substrate and ATP adequacy must all recover before tissue repair restarts.

#### Telomeres, copying and longevity

- **P2-LONG-1:** Chromosome ends and DNA damage are assessed together; telomere length alone does not authorize proliferation.

- **P2-LONG-2:** Tissue expansion is bounded by parcel volume, nutrients and local renewal permission.

- **P2-LONG-3:** Suspect lineages are isolated and replaced under supervised research assumptions rather than made immortal.

- **P2-LONG-4:** The digital identity record cannot be regenerated merely by growing fresh tissue.

#### Thermal regulation

- **P2-THERM-1:** Water carries heat to a protected exchanger; stagnant circulation creates local failure.

- **P2-THERM-2:** The living core remains within its selected narrow biochemical window.

- **P2-THERM-3:** Cooling and perfusion remain powered during workload reduction.

- **P2-THERM-4:** A damaged exchanger or hot ambient fluid leads to finite refuge, not permanent home operation.

#### Conversion and conservation

- **P2-CONV-1:** Oxidation consumes nutrients and oxygen and produces carbon dioxide, water, heat and waste.

- **P2-CONV-2:** Tissue regrowth consumes retained water and chemically suitable feedstock.

- **P2-CONV-3:** Electrical and chemical inventories are not counted twice.

- **P2-CONV-4:** Waste storage and filter saturation constrain closed operation even when energy remains.

The proposed service-life target is 5 years conditional on weekly fluid chemistry review; 3 months structural inspection. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P2-OBS-1, Perfusion-first sensing:** Outward motion decisions are conditioned on inward oxygen delivery and channel pressure, not merely an intact limb shape. Trigger: planned exertion. Target cost 1.33 W under the shared rule contract; other inputs: oxygen, pressure and flow records. False trigger or failure: bubbles or stagnant tissue falsely appearing supplied. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P2-OBS-2, Living/electronic disagreement:** Compare chemical viability markers with independent electronic temperature and power measurements. Trigger: repair request. Target cost 1.33 W under the shared rule contract; other inputs: two different measurement modalities. False trigger or failure: both modalities are miscalibrated by the same local condition. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P2-OBS-3, Consent-limited sampling:** Authorized researchers may inspect bounded parcels with recorded consent; refused sampling does not make extracted DNA unreadable. Trigger: sampling request. Target cost 1.33 W under the shared rule contract; other inputs: sample provenance and disclosed scope. False trigger or failure: physical removal exposes actual cellular chemistry. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P2-SEC-1, Two-ledger inheritance:** Tissue provenance and private digital identity remain separate ledgers with separate authorizations. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: cell-line record plus digital permission. False trigger or failure: a copied tissue parcel receives anatomy information, not core memories. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P2-SEC-2, Renewal permission envelope:** A parcel may renew only within its admitted compartment and resource allowance; this is a control hypothesis, not a demonstrated genetic containment circuit. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: parcel-level renewal bounds. False trigger or failure: a molecular escape from control remains an unresolved biosecurity risk. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P2-SEC-3, Witnessed repair enrollment:** New repair material enters a read-only observation period before it gains control authority. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: core plus independent service witnesses. False trigger or failure: false rejection can interrupt repair and must be recoverable without a remote issuer. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P2-DEP-1, Genome equals individual identity:** A dual DNA/digital construction record separates cellular heredity from computational identity. Departure affects dimension A; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P2-DEP-2, One tissue one permanent macroscopic role:** Service parcels reallocate transport and repair while cellular specialization remains. Departure affects dimension A; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P2-DEP-3, Exposed gas-exchange anatomy:** Protected internal gas and waste stores replace reliance on uninterrupted external breathing. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Living chemistry requires appropriate solvent, reactants and temperature; Proliferation remains bounded and damage-sensitive; Information is not replacement tissue.

### Repair, identity and autonomy

A target 5 kg dry-equivalent compatible feedstock allowance and retained water support limited interface repair. Nutrient and transport adequacy, lineage integrity and mechanical loading must be checked before regrowth counts as restored function. Replacing a lost compute core is reconstruction, not tissue regeneration. No cell-culture or genetic-construction procedure is specified.

Tissue replacement preserves identity only while the protected computational process continues. A detached living parcel is tissue, not a licensed mind. A split containing two complete cores would create branching continuations, not a mandatory winner. Reconnection preserves separate event histories. Restoring a prior core checkpoint is a successor. Correct tissue provenance does not excuse malicious control behavior. Ownership of a sample does not settle the moral status of any later conscious entity.

### Linking and capture

Electrical local sensing, short optical connections between service regions, and a protected radio interface; deep-space participation needs a dry external gateway.

A captor can exploit dependence on pumps, nutrients and gas management without defeating authentication. The protection objective is privacy and recorded consent, not a promise of escape.

Healthy-looking extracted tissue can reveal heredity without carrying the computational identity.

### Finite resources and environmental envelope

Targets: 3,600 Wh input reserve, 200 W normal accounted load, 40 W essential load and 5 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 70 W, actuation/transport 20 W, sensing 8 W, circulation/chemistry/housekeeping 60 W, communications/security 25 W and repair allowance 17 W. Peak power target 800 W is not a continuous capability.

Derived energy-only normal horizon: 10.0 h. With no heat export, no external heating, heat capacity 240 kJ/K and allowed rise 8 K, the derived normal-load thermal limit is 2.67 h; the combined favorable bound is 2.67 h. At the selected preservation draw the combined favorable bound is 107 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 295–310 K; finite-refuge target 285–315 K. Intended pressure target 0.08–0.15 MPa; finite-refuge pressure target 0.05–0.3 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. An 8 K lumped thermal margin is not a guarantee against local protein damage. Partial pressure and perfusion are independent constraints.

Normal operation allocates 60 W to living chemical maintenance and 140 W to electrical loads. The separate 600 Wh nutrient and 3,000 Wh electrical reserves therefore give 10 h and 21.4 h normal bounds; the minimum is used rather than pooling their energy. Essential mode assigns 25 W living and 15 W electrical, while preservation assigns 4 W living and 1 W electrical. The selected 1 kg oxygen and 1 kg carbon-dioxide capture allowances, at assumed 0.04 and 0.05 kg/h use, give 25.0 h and 20.0 h respectively. The same conservative gas/waste rates are retained in lower modes pending measurement, so their bound is 20.0 h. These rates are targets, not biological measurements, and neither chemical nor electrical energy can substitute for the other.

### Challenge outcome and research decision

The first central assumption to collapse is: Silent loss of perfusion defeats fine repair before a whole-body energy monitor necessarily detects it. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: A hydrated repair layer can restore fine interfaces that discrete mechanical replacement handles poorly. Strongest reason to reject: It accepts narrow biochemical temperatures, oxygen demand and continuing nutrient/sterility burdens. Least-supported critical mechanism: Cell maintenance and telomere biology have evidence; autonomous biohybrid body-wide repair is extrapolated or speculative and is not demonstrated here.

First likely failure under the selected dependency ranking: Perfusion interruption. Minimum useful validation: Use a nonliving perfusion phantom to validate transport, local oxygen-equivalent tracer delivery and exchanger behavior before considering living studies. Falsifying result: Representative service parcels cannot remain viable through the specified isolated maintenance interval while meeting the gas and waste budgets.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Reduce living volume and its basal load, improve nonliving perfusion redundancy, and establish evidence for bounded repair without loosening proliferation control.

Telomere-end maintenance is only part of cellular integrity and does not establish indefinite tissue life ([Cell telomere review](https://pmc.ncbi.nlm.nih.gov/articles/PMC8081271/)).

## P3 Mosaic: Generation 1

### Core wager and body

Many small, independently repairable reaction compartments can contain chemical failure better than one shared cytoplasm. It depends on a presently unbuilt translation/maintenance system and narrow solvent compatibility.

A 40 kg, approximately 0.5 m emulsion body has a target 100 million 0.4 mg compartments, each nominally around a millimeter in scale. Mineral walls and thin compliant membranes separate incompatible reactions. Mesoscale controller units supervise chemical compartments; full cognition in a molecular emulsion is not assumed.

An artificial compartment stores a bounded recipe, senses a local chemical state, exchanges ions and contributes to repair chemistry. It can switch among compatible pre-installed reactions. It cannot acquire arbitrary enzymes, structural competence or cognition merely by receiving a recipe. Whole-body function comes from bounded compartment cooperation.

### Matrix, transport and cognition

An HNA-like XNA information polymer is a research hypothesis for compartment instructions; exact monomer selection, catalyst fidelity and autonomous manufacture remain unknown. A dissimilar digital audit layer holds private identity and records authorized recipe versions.

Ion conduction, selective diffusion and short microfluidic paths; not every reactant may share a transport channel. Mesoscale electronic supervisors form a mesh; chemical compartments execute restricted maintenance roles. The chemistry is not claimed to implement a demonstrated general intelligence.

Controlled nonstandard chemical habitats and sealed repair chambers, not unrestricted dry desert, vacuum or hot industrial terrain.

### Physiological constitution

External electricity maintains ion gradients when available; sealed electrochemical reserves support isolated operation. Reaction free energies and membrane leakage set the unresolved true maintenance load.

#### Respiration and power

- **P3-RESP-1:** Ion gradients must be paid for by electrical or reaction free energy.

- **P3-RESP-2:** Incompatible redox pathways occupy separate compartments.

- **P3-RESP-3:** A gradient-collapse alarm reduces chemical workload before exhausting electrical reserve.

- **P3-RESP-4:** Restart verifies membrane selectivity and waste concentration before rebuilding gradients.

#### Telomeres, copying and longevity

- **P3-LONG-1:** No conventional telomere is assumed; finite templates have end integrity and copy-quality checks.

- **P3-LONG-2:** Recipe copying has a bounded compartment quota and cannot create absent catalysts.

- **P3-LONG-3:** A drifting compartment is disconnected from the recipe-admission network.

- **P3-LONG-4:** Replacing recipes cannot recover a lost private state history.

#### Thermal regulation

- **P3-THERM-1:** A selected aqueous-compatible core window binds membrane and catalyst performance.

- **P3-THERM-2:** Thin transport layers reduce gradient length but enlarge leak area.

- **P3-THERM-3:** Bulk thermal buffers do not excuse hot or chemically unstable interfaces.

- **P3-THERM-4:** Thermal recovery requires intact compartment boundaries, not temperature normalization alone.

#### Conversion and conservation

- **P3-CONV-1:** Each admitted reaction has a mass, charge and free-energy ledger.

- **P3-CONV-2:** Ion-pump losses are included in maintenance power.

- **P3-CONV-3:** Replacement packets require measured compatible precursors and solvent.

- **P3-CONV-4:** Waste accumulation ends closed-loop operation even when the recipe remains readable.

The proposed service-life target is 2 years conditional on daily chemistry checks; monthly reaction-packet review. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P3-OBS-1, Chemical balance witness:** Compare outward environmental chemistry with compartment inventories before admitting a reactant. Trigger: environmental intake proposal. Target cost 1.00 W under the shared rule contract; other inputs: mass and ionic-balance residuals. False trigger or failure: unidentified compounds or nonselective sensors. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P3-OBS-2, Gradient tomography:** Infer inward damage from multiple impedance and concentration observations rather than one bulk viability label. Trigger: unexpected leak current. Target cost 1.00 W under the shared rule contract; other inputs: spatial concentration and electrical estimates. False trigger or failure: ill-posed reconstruction hides a small failed compartment. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P3-OBS-3, Bounded recipe disclosure:** Reveal a consented reaction summary while withholding private supervisor state; molecular extraction can still expose templates. Trigger: external characterization. Target cost 1.00 W under the shared rule contract; other inputs: authorized recipe subset. False trigger or failure: a well-equipped analyst reads extracted polymers. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P3-SEC-1, Recipe admission proofs:** A supervisor authorizes a recipe only if the digital model and resource envelope agree. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: local supervisor authorization. False trigger or failure: validating a model does not establish the chemistry is safe. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P3-SEC-2, Split substrate records:** Chemical templates and private digital lineage are deliberately nonidentical records. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: physical XNA plus digital log. False trigger or failure: template theft remains possible without mind theft. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P3-SEC-3, Compartment challenge renewal:** A compartment must show current bounded function before rejoining the repair pool. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: local challenge records not a remote master key. False trigger or failure: measurement errors can falsely exclude useful repair compartments. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P3-DEP-1, DNA backbone monopoly:** An HNA-like XNA template is proposed instead of DNA for local hereditary instructions. Departure affects dimension A; support: Polymer information handling established in limited experiments; autonomous physiology speculative. This departs from a biological or engineering default, not a physical law.

- **P3-DEP-2, Open shared cytoplasm:** Mineral and membrane compartments enforce chemically distinct local rule sets. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P3-DEP-3, Replication as default recovery:** Damaged chemistry is replaced as admitted packets rather than unrestricted division. Departure affects dimension A; support: Speculative integration. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Charge and redox accounting for every compartment; Finite catalytic fidelity and bounded replication; Solvent and chemical stability are non-negotiable.

### Repair, identity and autonomy

A target 4 kg compatible packet inventory supplies membrane and reaction-medium replacement at an assumed 0.5 material yield. A damaged pocket is isolated before neighboring compartments receive its contents. Exact assembly energy and useful repair rate are unknown; the report does not specify synthesis, sequences or culture methods.

A supervisor lineage can continue while compartments are replaced. Two separated supervisor meshes must be treated as branches if both remain complete. Chemical similarity is not identity. Remote records reconcile as attributed claims. Rebuilding all supervisors from an old checkpoint creates a successor. Correct recipe signatures do not make corrupted chemistry trustworthy. Sample ownership does not settle the status of any independently conscious reconstruction.

### Linking and capture

Ionic/electrical local links feed an electronic boundary transducer; external radio/optical networking is gateway-mediated.

The analyst may learn polymer chemistry and compartment recipes; the architecture cannot promise molecular unreadability. Solvent disruption or controller extraction is a more direct failure than defeating template cryptography.

A copied XNA template does not imply a functioning catalyst system or a restored supervisor lineage.

### Finite resources and environmental envelope

Targets: 2,400 Wh input reserve, 100 W normal accounted load, 20 W essential load and 2 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 35 W, actuation/transport 12 W, sensing 6 W, circulation/chemistry/housekeeping 25 W, communications/security 10 W and repair allowance 12 W. Peak power target 300 W is not a continuous capability.

Derived energy-only normal horizon: 24.0 h. With no heat export, no external heating, heat capacity 100 kJ/K and allowed rise 10 K, the derived normal-load thermal limit is 2.78 h; the combined favorable bound is 2.78 h. At the selected preservation draw the combined favorable bound is 139 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 288–308 K; finite-refuge target 278–318 K. Intended pressure target 0.08–0.2 MPa; finite-refuge pressure target 0.02–1 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. All chemical ranges are targets pending membrane/catalyst selection; an unknown glass transition or denaturation threshold cannot be inferred from bulk temperature.

### Challenge outcome and research decision

The first central assumption to collapse is: If membrane selectivity fails, compartmentalization becomes a correlated chemical transport failure. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: Many small, independently repairable reaction compartments can contain chemical failure better than one shared cytoplasm. Strongest reason to reject: It depends on a presently unbuilt translation/maintenance system and narrow solvent compatibility. Least-supported critical mechanism: XNA information storage is supported in limited systems; autonomous XNA repair and whole-body integration remain speculative.

First likely failure under the selected dependency ranking: No autonomous XNA physiology demonstrated. Minimum useful validation: Simulate coupled diffusion and energy balance, then compare with a nonliving ionic-compartment phantom. Falsifying result: A nonliving compartment array cannot preserve separations under the proposed gradient and thermal loads for the intended maintenance interval.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Narrow the reaction alphabet, demonstrate bounded catalyst maintenance and replace ambitious chemical cognition with measurable supervisory roles.

Limited experimental XNA storage and evolution support researching this substrate, not asserting an autonomous XNA body ([MRC LMB XNA research](https://www2.mrc-lmb.cam.ac.uk/groups/ph1/xna.html)).

## P4 Pelagic: Generation 1

### Core wager and body

Accommodating external pressure in distributed oil-filled modules avoids one enormous pressure vessel and its single catastrophic boundary. It gives up dry-terrain competence, high-bandwidth untethered networking and cheap precision servicing.

A 120 kg, approximately 1.2 m neutrally trimmed body contains a target 20,000 6 g service modules within a compliant cage. Electronics intended for pressure accommodation are conceptually immersed in compatible insulating fluid; components not qualified for ambient pressure retain local housings. The design does not infer pressure tolerance from incompressibility alone.

Modules sense pressure and chemistry, regulate local buoyancy or actuation, conduct energy and participate in docking. Their functions depend on installed components. A module can exchange roles within its class, while cognitive and energy components remain heterogeneous.

### Matrix, transport and cognition

Digital controller manifests plus service histories encode reconstruction; no biological genome is required. Material compatibility and seal records are part of the admitted phenotype.

Hydraulic power, insulating-fluid pressure balance and electrical paths are separated from environmental seawater; heat transfers through wetted exchangers. One protected mission controller and multiple bounded local controllers support offline navigation. A second protected state recorder provides restoration information but is not declared a second simultaneous mind.

Cold deep water and flooded subsurface terrain; pressure and chemistry must be qualified separately. Vacuum and hot dry ground are not home environments.

### Physiological constitution

A stored hydrogen/oxygen fuel-cell concept is primary; a battery bridges interruptions. At the report boundary, reserve energy is preconversion fuel free energy, with an assumed 0.5 electrical conversion fraction and unused energy treated as heat.

#### Respiration and power

- **P4-RESP-1:** Hydrogen and oxygen inventories constrain fuel-cell operation; ocean water is not fuel.

- **P4-RESP-2:** The electrical fraction of fuel energy and conversion heat are accounted separately.

- **P4-RESP-3:** Reactant starvation transfers essential control to the bridge reserve only if its independent inventory is available.

- **P4-RESP-4:** Reactivation requires reactants, water-product management and qualified pressure state.

#### Telomeres, copying and longevity

- **P4-LONG-1:** Module wear and pressure cycles replace telomere age.

- **P4-LONG-2:** New pressure modules must pass compatibility and provenance checks.

- **P4-LONG-3:** Replacement never assumes unlimited internal fabrication.

- **P4-LONG-4:** Restoring a controller from the recorder is distinguished from uninterrupted operation.

#### Thermal regulation

- **P4-THERM-1:** Wetted exchangers require flow and temperature difference.

- **P4-THERM-2:** Reactant conversion heat joins electrical dissipation at the body boundary.

- **P4-THERM-3:** Fouling reduces exchanger performance and is modeled as lost conductance.

- **P4-THERM-4:** Leaving water invalidates the home heat-transfer model and triggers load reduction.

#### Conversion and conservation

- **P4-CONV-1:** Both fuel and oxidant mass are carried or replenished explicitly.

- **P4-CONV-2:** Water product occupies storage or requires a controlled discharge boundary.

- **P4-CONV-3:** Hydraulic losses and buoyancy-control work count as load.

- **P4-CONV-4:** Lost parts require compatible corrosion-qualified matter, not arbitrary seabed sediment.

The proposed service-life target is 10 years conditional on 3 months wet-interface review; annual major service. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P4-OBS-1, Pressure-rate witness:** Outward route changes require both pressure magnitude and pressure-rate confidence. Trigger: depth or buoyancy change. Target cost 1.67 W under the shared rule contract; other inputs: independent pressure estimates. False trigger or failure: blocked ports or common calibration error. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P4-OBS-2, Leak-localization consensus:** Compare inward fluid conductivity, insulation and inventory before deciding which branch to isolate. Trigger: unexpected electrical or fluid loss. Target cost 1.67 W under the shared rule contract; other inputs: three leak indicators. False trigger or failure: a leak crosses several compartments before localization. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P4-OBS-3, Acoustic restraint:** Transmit only bounded consented telemetry; acknowledge that acoustic emissions reveal position and behavior. Trigger: external message request. Target cost 1.67 W under the shared rule contract; other inputs: message and duty-cycle budget. False trigger or failure: physical tracking and traffic analysis remain possible. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P4-SEC-1, Docking provenance:** Wet-docked modules enter restricted diagnostic status before motion authority. Trigger: component admission, protected request or recovery. Target cost 1.00 W under the shared rule contract; other inputs: local mission controller authorization. False trigger or failure: stolen docking hardware still exposes component designs. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P4-SEC-2, Pressure-history attestation:** A module's admission includes exposure history as well as signed software identity. Trigger: component admission, protected request or recovery. Target cost 1.00 W under the shared rule contract; other inputs: material state plus manifest. False trigger or failure: an authentic but fatigue-damaged part is refused. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P4-SEC-3, Offline acoustic epochs:** Acoustic identity uses local epoch records and does not require continuous surface contact. Trigger: component admission, protected request or recovery. Target cost 1.00 W under the shared rule contract; other inputs: store-and-forward credentials. False trigger or failure: recovery requires comparison, not trust in an old surface timestamp. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P4-DEP-1, Molecular hereditary requirement:** Versioned digital/material manifests carry construction information. Departure affects dimension A; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P4-DEP-2, Rigid universal pressure hull:** Distributed pressure accommodation replaces one body-sized vessel. Departure affects dimension B; support: Extrapolated and component-dependent. This departs from a biological or engineering default, not a physical law.

- **P4-DEP-3, Ambient-air energy metabolism:** Stored donor and oxidant replace atmospheric respiration. Departure affects dimension A; support: Established reaction; extrapolated physiology. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Pressure compatibility is component-specific; Fuel, oxidant and reaction-product mass balance; No instantaneous long-range underwater communication.

### Repair, identity and autonomy

A target 8 kg of corrosion-qualified modules supports wet docking and local exchange. Seal replacement and cleaning require finite consumables. Cannibalizing buoyancy or structure may save control but sacrifice surfacing ability. The current design cannot manufacture precision electronics from dissolved minerals.

Continuity follows the active controller process and its journal, not fluid or hull persistence. Splits without a complete controller are service fragments; a complete duplicated controller is a branch. Reconnection preserves source attribution. Rebuilding a lost controller is restoration. An authentic pressure module with malicious local behavior loses authority. Possession of a removed component is not proof of ownership of memories.

### Linking and capture

Local wired links and short optical water links; longer acoustic messaging to a surface buoy; the buoy provides planetary/orbital or deep-space radio. Surfacing and a buoy are infrastructure options, not assumed always available.

Physical restraint, isolation from a usable fluid heat sink and reactant denial defeat operation without revealing secrets. A captor may map internal hardware through sustained access.

The surface gateway can be lost without stopping local control, but global links then disappear.

### Finite resources and environmental envelope

Targets: 10,000 Wh input reserve, 300 W normal accounted load, 25 W essential load and 0.5 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 100 W, actuation/transport 80 W, sensing 15 W, circulation/chemistry/housekeeping 35 W, communications/security 30 W and repair allowance 40 W. Peak power target 1000 W is not a continuous capability.

Derived energy-only normal horizon: 16.7 h. With no heat export, no external heating, heat capacity 120 kJ/K and allowed rise 15 K, the derived normal-load thermal limit is 0.83 h; the combined favorable bound is 0.83 h. At the selected preservation draw the combined favorable bound is 500 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 275–303 K; finite-refuge target 271–323 K. Intended pressure target 0.1–60 MPa; finite-refuge pressure target 0.05–100 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. The 60 MPa home-pressure target is a research goal, not a qualified rating; the hot and cold ends require component-specific compatibility.

The 10,000 Wh fuel reserve is preconversion energy. At target electrical fraction 0.5 it yields 5,000 Wh to the bus and produces conversion heat in addition to electrical dissipation. At 300 W bus load the modeled total heat is 600 W. The separately proposed bridge battery has no credited capacity until independently specified.

### Challenge outcome and research decision

The first central assumption to collapse is: A hidden pressure-sensitive component defeats pressure accommodation despite intact outer modules. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: Accommodating external pressure in distributed oil-filled modules avoids one enormous pressure vessel and its single catastrophic boundary. Strongest reason to reject: It gives up dry-terrain competence, high-bandwidth untethered networking and cheap precision servicing. Least-supported critical mechanism: Underwater robotics and fuel cells are established; the pressure-balanced autonomous physiology and repair system are extrapolated.

First likely failure under the selected dependency ranking: Component-specific pressure failure. Minimum useful validation: Use component stress models and nonliving pressure-equivalent material tests under specialist facilities, not living exposure. Falsifying result: Distributed modules fail at the proposed pressure-rate/chemistry combination despite acceptable static-pressure calculations.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Qualify more components under pressure, reduce buoy dependency and add independently serviceable thermal paths.

The selected fuel-cell concept needs supplied fuel and oxygen and yields heat as well as electricity ([DOE fuel cells](https://www.energy.gov/cmei/fuels/fuel-cells)).

## P5 Heliotile: Generation 1

### Core wager and body

A broad, low-duty-cycle body can sustain long deployment from intermittent sunlight while keeping vulnerable electronics sheltered. It gives up high mobility, concealment and reliable energy autonomy in shade, dust or permanent darkness.

A 30 kg deployable mat has a target 12 square meters of exposed collector area distributed across 3,000 nominal 10 g tiles, each around 6 cm across when flat. A 3 kg structural and repair allowance is included. Some tiles collect light, some store energy, and some carry sensing or computation.

Tiles sense strain, irradiance and temperature, route energy and negotiate bounded local role changes. The body is collective and heterogeneous; not every tile can harvest, store, compute and repair at once. The protected edge strip hosts the computational lineage.

### Matrix, transport and cognition

Digital tile manifests and a checkpointed identity journal govern reconstruction. Photovoltaic material is not a hereditary polymer, and replacing a tile does not copy a mind.

A surface electrical mesh and thin conductive spreaders replace circulation; folds create shading and thermal-contact risks. A protected edge compute strip schedules a low-duty mission workload. Distributed tile controllers cannot reconstruct full cognition without its private state.

Sunlit arid surfaces, roofs, open orbital platforms and low-mobility surveying sites; deep ocean and sealed darkness are adverse cases.

### Physiological constitution

Photovoltaics supply primary electrical input; a sealed battery bridges night or shading. The selected solar example uses area, irradiance, conversion efficiency and illuminated duty fraction explicitly.

#### Respiration and power

- **P5-RESP-1:** Light input is environmental energy, not an intrinsic metabolic reserve.

- **P5-RESP-2:** Darkness transfers load to the battery without changing the requirement for energy.

- **P5-RESP-3:** Workload and communication duty follow admitted energy surplus.

- **P5-RESP-4:** Recovery requires a positive measured energy margin after thermal and authentication costs.

#### Telomeres, copying and longevity

- **P5-LONG-1:** Tile degradation, cracks and cycle exposure replace telomere age.

- **P5-LONG-2:** New tiles prove their electrical behavior before joining the power mesh.

- **P5-LONG-3:** No tile is authorized to grow collector area without matter and structural accounting.

- **P5-LONG-4:** Edge-journal survival is separate from collector survival.

#### Thermal regulation

- **P5-THERM-1:** Absorbed sunlight that is not exported becomes heat.

- **P5-THERM-2:** Folds and occluded radiators are included in the view-factor model.

- **P5-THERM-3:** A hot mat may reduce collection even while sunlight is abundant.

- **P5-THERM-4:** Thermal recovery requires adequate sky view or a conductive sink, not just electrical shedding.

#### Conversion and conservation

- **P5-CONV-1:** Solar input equals area times irradiance before conversion losses.

- **P5-CONV-2:** Battery charging and discharge losses cannot be claimed as recovered heat-to-electricity without a cycle.

- **P5-CONV-3:** Replacing a tile consumes matched material and bonding allowance.

- **P5-CONV-4:** Dust removal consumes time, energy and possibly cleaning matter.

The proposed service-life target is 15 years conditional on monthly surface inspection; 6 months electrical review. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P5-OBS-1, Flux-before-work:** Outward task planning uses measured irradiance and shadow history rather than time-of-day assumptions. Trigger: new workload. Target cost 0.67 W under the shared rule contract; other inputs: local flux and forecast uncertainty. False trigger or failure: sudden occlusion or dust. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P5-OBS-2, Fold thermal witness:** Compare inward hot-spot observations across folds with a thermal view estimate. Trigger: fold or deployment change. Target cost 0.67 W under the shared rule contract; other inputs: spatial temperature sampling. False trigger or failure: a hidden fold becomes a thermal trap. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P5-OBS-3, Honest silhouette:** Reduce unnecessary telemetry but accept visible collector geometry and thermal emission; consented tests may measure both. Trigger: observation request. Target cost 0.67 W under the shared rule contract; other inputs: declared emissions and logs. False trigger or failure: no claim of visual or infrared invisibility. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P5-SEC-1, Tile enrollment:** A new collector receives power-routing authority only after bounded characterization. Trigger: component admission, protected request or recovery. Target cost 0.33 W under the shared rule contract; other inputs: local edge controller. False trigger or failure: copied tile construction does not carry edge memories. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P5-SEC-2, Reserve-separated identity:** Private state has an energy reserve not spendable by collector optimization. Trigger: component admission, protected request or recovery. Target cost 0.33 W under the shared rule contract; other inputs: separate protected storage domain. False trigger or failure: reserve isolation itself may fail. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P5-SEC-3, Harvest-independent credentials:** Authentication uses local records and does not expire solely because weather prevents contact. Trigger: component admission, protected request or recovery. Target cost 0.33 W under the shared rule contract; other inputs: local history with revocable peer permissions. False trigger or failure: a long-isolated peer is not allowed to overwrite current identity. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P5-DEP-1, Genome-driven construction:** Digital tile recipes replace DNA as construction heredity. Departure affects dimension A; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P5-DEP-2, Compact body geometry:** A broad folding collector replaces a compact animal-like body. Departure affects dimension B; support: Established geometry; extrapolated physiology. This departs from a biological or engineering default, not a physical law.

- **P5-DEP-3, Continuous high-power metabolism:** Scheduled useful work follows environmental surplus rather than a fixed active rate. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Finite photon flux and conversion loss; No guaranteed energy from darkness; Collector area and physical visibility have costs.

### Repair, identity and autonomy

A target 3 kg matched tile-and-bond stock supports local replacement at an assumed 0.7 useful yield. Delaminated collection zones may be isolated but their area is lost until repaired. Raw sand is not assumed to become a solar cell on command.

The live edge journal anchors continuity. Detached collector tiles carry little personal state. Two complete edge strips create branches rather than one magically synchronized person. Network updates append attributed claims. A restored edge checkpoint is a successor after destruction. Authentic but misreporting collectors lose routing authority. Material ownership does not transfer a private identity by default.

### Linking and capture

Short optical tile links, nearby radio and a deployable directional gateway; high-rate external communication is scheduled from energy surplus.

A simple shadowed enclosure can end energy harvesting. A broad visible body is easy to localize; the design does not solve captivity merely by being sunlight-powered.

Darkness defeats harvest even when atmosphere, temperature and network authentication remain normal.

### Finite resources and environmental envelope

Targets: 3,000 Wh input reserve, 80 W normal accounted load, 8 W essential load and 0.1 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 40 W, actuation/transport 5 W, sensing 8 W, circulation/chemistry/housekeeping 6 W, communications/security 10 W and repair allowance 11 W. Peak power target 240 W is not a continuous capability.

Derived energy-only normal horizon: 37.5 h. With no heat export, no external heating, heat capacity 24 kJ/K and allowed rise 25 K, the derived normal-load thermal limit is 2.08 h; the combined favorable bound is 2.08 h. At the selected preservation draw the combined favorable bound is 1667 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 263–323 K; finite-refuge target 233–353 K. Intended pressure target 0–0.2 MPa; finite-refuge pressure target 0–0.5 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. The ranges refer to protected electronics; collector coatings, storage chemistry and bonded joints may impose tighter limits.

The selected 12 m² collector, 500 W/m² illumination, 0.2 conversion fraction and 0.25 illuminated duty yield 1200 W instantaneous and 300 W mean electrical input. The mean surplus is 220 W before storage, cleaning, pointing and thermal penalties. In darkness it is zero; the 5% duty stress produces a deficit at the selected normal load.

### Challenge outcome and research decision

The first central assumption to collapse is: Loss of illuminated area turns a long-duration harvesting argument into a short battery-runtime problem. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: A broad, low-duty-cycle body can sustain long deployment from intermittent sunlight while keeping vulnerable electronics sheltered. Strongest reason to reject: It gives up high mobility, concealment and reliable energy autonomy in shade, dust or permanent darkness. Least-supported critical mechanism: Photovoltaics are established; autonomous self-repairing embodied tile cognition is extrapolated and full identity capacity is unknown.

First likely failure under the selected dependency ranking: Long darkness. Minimum useful validation: Compare a nonliving mat energy/temperature model with measured irradiance and fold geometry under benign conditions. Falsifying result: Net daily harvest after thermal, cleaning and storage losses cannot support the selected normal workload.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Add better low-flux workload scheduling, replaceable dust barriers and independent edge-state witnesses without assuming uninterrupted sunlight.

Environmental heat inputs, view factors and finite heat rejection must accompany solar electrical calculations ([NASA thermal-control guidance](https://www.nasa.gov/wp-content/uploads/2026/05/7-soa-thermal-2026-final.pdf?emrc=6ae1e775de967)).

## P6 Scatterweave: Generation 1

### Core wager and body

A single local disaster need not eliminate a geographically spread active lineage. It accepts coordination overhead, incomplete local capability and unresolved branching identity during partitions.

A 50 kg assembly comprises a target 500 sealed 100 g nodules, nominally a few centimeters across. Some provide energy or locomotion, others protected compute and state storage. Dispersion is within authorized deployment boundaries; there is no uncontrolled environmental self-replication.

A nodule senses, computes bounded local policy, stores energy, authenticates neighbors and may move or dock. Full embodied function requires a sufficient connected set of heterogeneous nodules. Every nodule is more capable than a passive grain, but none is a miniature complete person by default.

### Matrix, transport and cognition

Erasure-coded digital journals and nodule manifests store construction and identity data separately. Coding increases recoverability but is not encryption and does not guarantee privacy if enough shares are captured.

Contact power exchange when docked and independent reserves when dispersed; radio or short optical messages carry observations, not compulsory real-time state. Federated local control supports bounded autonomous branches. A target recovery policy needs sufficient authorized state shares; partitions cannot simultaneously guarantee one global writer and unrestricted local continuation.

Distributed surveying, fractured rubble and intermittent access regions within an authorized bounded site; dense shielding, deep water and mass-confinement defeat the link assumptions.

### Physiological constitution

Independent nodule batteries are primary; authenticated docks recharge them. Transporting, locating and gathering nodules consume energy that a monolithic body would not spend.

#### Respiration and power

- **P6-RESP-1:** Each nodule has its own finite battery ledger.

- **P6-RESP-2:** Aggregate reserve cannot power an isolated empty nodule without a physical transfer path.

- **P6-RESP-3:** Coordination duty is reduced before individual state-preservation reserves are spent.

- **P6-RESP-4:** Reassembly verifies both energy availability and lineage compatibility.

#### Telomeres, copying and longevity

- **P6-LONG-1:** Nodule cycle and exposure logs replace telomeres.

- **P6-LONG-2:** A new nodule gains no historical identity merely by matching a hardware identifier.

- **P6-LONG-3:** Replacement is capped by admitted physical stock and local deployment authorization.

- **P6-LONG-4:** Recovered shares can reconstruct information but not prove a prior subject resumed.

#### Thermal regulation

- **P6-THERM-1:** Heat balances apply to each nodule, not only the average body.

- **P6-THERM-2:** A well-cooled nodule cannot absorb another's heat without a transfer path.

- **P6-THERM-3:** Buried or enclosed nodules use lower power than exposed ones.

- **P6-THERM-4:** Thermal recovery does not automatically reconcile divergent cognitive branches.

#### Conversion and conservation

- **P6-CONV-1:** Nodule energy transfers pay connector and conversion losses.

- **P6-CONV-2:** Recovery coding consumes storage and transmission capacity.

- **P6-CONV-3:** Gathering physical mass requires locomotion and cannot be replaced by message delivery.

- **P6-CONV-4:** Missing nodules reduce both state redundancy and physical capability.

The proposed service-life target is 10 years conditional on 3 months nodule accounting; annual storage review. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P6-OBS-1, Independent local witness:** Outward claims are tagged with nodule origin, age and uncertainty before fusion. Trigger: received observation. Target cost 2.00 W under the shared rule contract; other inputs: source-attributed records. False trigger or failure: many compromised nodules can fabricate apparent consensus. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P6-OBS-2, Per-nodule health:** Inward safety decisions use local temperature and reserve, not an aggregate average. Trigger: local load request. Target cost 2.00 W under the shared rule contract; other inputs: per-node inventories. False trigger or failure: a disconnected nodule cannot be assessed remotely. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P6-OBS-3, Disclosure budget by quorum:** External diagnostics reveal bounded aggregate health only with local consent; radio traffic still reveals activity. Trigger: external query. Target cost 2.00 W under the shared rule contract; other inputs: share-independent health summaries. False trigger or failure: enough captured shares expose sensitive state. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P6-SEC-1, Threshold state custody:** Private reconstruction state is distributed with a declared threshold and availability cost. Trigger: component admission, protected request or recovery. Target cost 1.33 W under the shared rule contract; other inputs: local share custodians. False trigger or failure: theft of enough shares defeats the privacy boundary. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P6-SEC-2, Identity is not a radio address:** New or returning nodules must prove authorized history rather than matching an identifier. Trigger: component admission, protected request or recovery. Target cost 1.33 W under the shared rule contract; other inputs: per-nodule history records. False trigger or failure: honest history can coexist with malicious current behavior. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P6-SEC-3, Partition-aware enrollment:** Offline branches cannot silently overwrite one another when they meet. Trigger: component admission, protected request or recovery. Target cost 1.33 W under the shared rule contract; other inputs: branch-qualified authorization. False trigger or failure: false conflict may strand useful nodules and reduce recovery capacity. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P6-DEP-1, Molecular hereditary encoding:** Erasure-coded digital lineage replaces a molecular genome. Departure affects dimension A; support: Established coding; extrapolated embodiment. This departs from a biological or engineering default, not a physical law.

- **P6-DEP-2, Contiguous anatomy:** A body can consist of bounded spatially separated nodules. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P6-DEP-3, One synchronized cognitive present:** Qualified branches may remain autonomous with explicit identity divergence. Departure affects dimension B; support: Engineering policy, subjective continuity unknown. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Finite signal propagation and partition limits; No unauthorized replication or unbounded deployment; No branch may erase another's history solely by majority vote.

### Repair, identity and autonomy

A target 2 kg replacement-nodule stock provides limited recovery. The body can gather surviving modules or admit qualified replacements; it cannot transmit missing mass. Lost state shares, inaccessible terrain and depleted isolated nodes create recovery costs not captured by aggregate battery size.

Gradual nodule replacement can preserve an active local lineage. Fragmentation is the central hard case: two sufficient subsets may become separate continuations. Reconnection creates a federation of attributed histories, not involuntary mind fusion. Restoration from coding is reconstruction. Compromised authentic nodules are restricted by behavior. Any conscious branch is not disposable property merely because it lacks a majority.

### Linking and capture

Opportunistic RF/optical local networking, delayed contact routing and occasional directional gateway contact; no continuous global consensus is required for basic local control.

Dispersal can reduce single-location loss before capture but cannot rescue nodules already sealed together. A patient captor can gather sufficient state shares or prevent reassembly.

Pre-existing geographic separation matters; hypothetical escape after total confinement is not counted.

### Finite resources and environmental envelope

Targets: 5,000 Wh input reserve, 180 W normal accounted load, 18 W essential load and 0.3 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 60 W, actuation/transport 50 W, sensing 30 W, circulation/chemistry/housekeeping 12 W, communications/security 10 W and repair allowance 18 W. Peak power target 900 W is not a continuous capability.

Derived energy-only normal horizon: 27.8 h. With no heat export, no external heating, heat capacity 25 kJ/K and allowed rise 25 K, the derived normal-load thermal limit is 0.96 h; the combined favorable bound is 0.96 h. At the selected preservation draw the combined favorable bound is 579 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 263–323 K; finite-refuge target 233–353 K. Intended pressure target 0–0.2 MPa; finite-refuge pressure target 0–0.5 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. No whole-body home range is valid if individual nodes have different boundary conditions. Small nodes can fail earlier than the aggregate lumped model predicts.

### Challenge outcome and research decision

The first central assumption to collapse is: If dispersed components cannot ever physically reunite or communicate, aggregate resilience no longer supports one recoverable body. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: A single local disaster need not eliminate a geographically spread active lineage. Strongest reason to reject: It accepts coordination overhead, incomplete local capability and unresolved branching identity during partitions. Least-supported critical mechanism: Distributed storage and robotics have evidence; distributed personal continuity and autonomous body reconstitution remain unknown or speculative.

First likely failure under the selected dependency ranking: Partition creates identity divergence. Minimum useful validation: Run a discrete-event partition and inventory model, then a nonliving small-nodule bench demonstration. Falsifying result: The proposed recovery policy loses useful active state under benign partitions or requires continuous communication to preserve local autonomy.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Test lower-overhead branch reconciliation, diversify firmware and validate bounded recovery behavior without using uncontrolled replication.

Store-and-forward networking accommodates interrupted links, not real-time global mental synchronization ([NASA DTN](https://www.nasa.gov/communicating-with-missions/delay-disruption-tolerant-networking/)).

## P7 Stillglass: Generation 1

### Core wager and body

Giving up continuous active operation can greatly reduce reserve consumption during long hostile intervals. It accepts blind intervals, uncertain biological revival and unresolved subjective continuity across dormancy.

A 20 kg body contains a target 2,000 10 g sealed pods, nominally around two centimeters in scale. Dry archives and optional hydrated repair elements are separated. The baseline is a nonliving preservation system; proposed living dry-state repair remains speculative rather than a demonstrated revival capability.

A pod senses selected hazards, keeps a bounded archive, budgets its reserve and participates in slow repair when active. During deep preservation it does not sense continuously or conduct full cognition. The design refuses to call an inactive archive an awake universally capable cell.

### Matrix, transport and cognition

Ordinary DNA may specify optional repair elements, while error-checked digital archives carry private state and assembly instructions. Neither DNA nor stored bytes proves personal continuity after complete shutdown.

Short sealed microfluidic paths operate only in hydrated repair windows; dry-state preservation relies on static encapsulation rather than circulation. One active seed journal plus dissimilar read-only archives. Dormancy stops active cognition in the selected model; no subjective persistence is claimed.

Long storage, intermittent resource access and slow surveying where delayed response is acceptable; fast threats and hot humid settings are difficult.

### Physiological constitution

A battery supports short work periods and a low-power supervisory timer. A target 0.01 W dormancy draw is an aspirational system budget, not evidence that living material or an AI can remain conscious at that power.

#### Respiration and power

- **P7-RESP-1:** Awake operation consumes ordinary stored energy; no power is obtained from being dormant.

- **P7-RESP-2:** Deep preservation suspends function rather than inventing oxygen-free full metabolism.

- **P7-RESP-3:** A wake request is admitted only when energy and thermal reserves can support assessment.

- **P7-RESP-4:** Revival failure is recorded as loss, not relabeled as longer dormancy.

#### Telomeres, copying and longevity

- **P7-LONG-1:** Optional living elements retain DNA end-protection and damage concerns.

- **P7-LONG-2:** Archive checks track physical corruption and write history instead of assuming timeless information.

- **P7-LONG-3:** A pod cannot clone the entire lineage without separate authorization and state.

- **P7-LONG-4:** Replacing every active component from archives is reconstruction.

#### Thermal regulation

- **P7-THERM-1:** Dry-state stability depends on actual formulation, humidity and temperature.

- **P7-THERM-2:** A low power draw slows self-heating but does not stop heat from a hot environment.

- **P7-THERM-3:** Wake scheduling reserves energy for thermal equilibration.

- **P7-THERM-4:** Crossing an unmeasured glass or phase transition is an unresolved failure condition.

#### Conversion and conservation

- **P7-CONV-1:** Dormancy conserves stored free energy but does not create it.

- **P7-CONV-2:** Rehydration consumes water and incurs transport and recovery costs.

- **P7-CONV-3:** Readback and error correction consume power and may not repair chemical destruction.

- **P7-CONV-4:** Replacement pods require compatible mass and preserved readable instructions.

The proposed service-life target is 30 years conditional on annual archival audit; every wake cycle verification. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P7-OBS-1, Sparse witness schedule:** Outward sensing is explicitly sampled; report the maximum unobserved interval instead of claiming vigilance. Trigger: scheduled wake. Target cost 0.33 W under the shared rule contract; other inputs: sample time and reserve. False trigger or failure: events wholly inside a blind interval. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P7-OBS-2, Archive cross-read:** Inward readback compares dissimilar archives before accepting a wake state. Trigger: wake assessment. Target cost 0.33 W under the shared rule contract; other inputs: integrity and provenance checks. False trigger or failure: common radiation or chemical damage corrupts all records. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P7-OBS-3, Dormancy transparency:** Tell authorized observers which functions are inactive; no signal is not proof of invulnerability or death. Trigger: research request. Target cost 0.33 W under the shared rule contract; other inputs: declared active/dormant state. False trigger or failure: external observer cannot infer unmeasured subjective status. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P7-SEC-1, Wake authority separation:** The wake channel cannot authorize rewriting private identity. Trigger: component admission, protected request or recovery. Target cost 0.17 W under the shared rule contract; other inputs: local preserved policy. False trigger or failure: a captured pod may still be physically read. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P7-SEC-2, Archive lineage custody:** Private archives are separate from ordinary repair recipes. Trigger: component admission, protected request or recovery. Target cost 0.17 W under the shared rule contract; other inputs: read-only lineage records. False trigger or failure: enough intact archives permit unauthorized duplication. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P7-SEC-3, No remote expiry death:** Long link loss does not expire permission to preserve local state. Trigger: component admission, protected request or recovery. Target cost 0.17 W under the shared rule contract; other inputs: offline local authority. False trigger or failure: stale peers require later reconciliation without forced rollback. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P7-DEP-1, Heredity as one living genome:** A dual molecular/digital archive separates repair instructions from identity state. Departure affects dimension A; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P7-DEP-2, Continuous metabolism as survival criterion:** Preservation is an explicitly separate success state, not continuous operation. Departure affects dimension B; support: Engineering policy; revival speculative. This departs from a biological or engineering default, not a physical law.

- **P7-DEP-3, Continuous whole-body perfusion:** Dry encapsulation replaces circulation during preservation. Departure affects dimension A; support: Limited analogies established; integration speculative. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: Preserved information needs a physical stable medium; Dormancy is not active awareness; Finite wake energy and bounded reconstruction.

### Repair, identity and autonomy

A target 2 kg pod stock supports substitution; a selected 0.6 material yield leaves large losses. Planned wake windows inspect damage before repair. Dry-state analogies do not establish arbitrary body revival, autonomous biological repair or decades of retained personal continuity.

While active, continuity follows the seed process. Dormancy is a gap in active computation; its interpretation remains open. Fragmented complete archives can generate several successor branches. Reconnection never silently blends their memories. Reconstruction after seed loss is restoration. A correctly preserved but maliciously changed archive is not trusted. A conscious revived copy deserves separate ethical consideration.

### Linking and capture

Wake-window short optical or wired contact; burst radio to a nearby gateway; interplanetary messaging is delayed by both propagation and scheduled inactivity.

An adversary may keep pods below wake-energy availability or collect archives. Preservation reduces expenditure, not the ability to resist physical removal.

An inactive archive cannot consent anew, detect every intervention or prove a continuing subjective experience.

### Finite resources and environmental envelope

Targets: 2,000 Wh input reserve, 40 W normal accounted load, 2 W essential load and 0.01 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 20 W, actuation/transport 2 W, sensing 3 W, circulation/chemistry/housekeeping 5 W, communications/security 4 W and repair allowance 6 W. Peak power target 120 W is not a continuous capability.

Derived energy-only normal horizon: 50.0 h. With no heat export, no external heating, heat capacity 20 kJ/K and allowed rise 20 K, the derived normal-load thermal limit is 2.78 h; the combined favorable bound is 2.78 h. At the selected preservation draw the combined favorable bound is 11,111 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 278–303 K; finite-refuge target 253–323 K. Intended pressure target 0–0.2 MPa; finite-refuge pressure target 0–0.5 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. The dry-state refuge range is a provisional packaging target; actual biochemical thresholds and glass transitions are unknown.

The long preservation number is especially fragile: the selected 0.01 W total draw excludes no required load by permission, but no implementation demonstrates it. Self-discharge, periodic sensing, archive readback and physical aging may dominate. It is not a consciousness-power estimate.

### Challenge outcome and research decision

The first central assumption to collapse is: If preserved material cannot resume verified function, the entire long-duration advantage is storage rather than survival. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: Giving up continuous active operation can greatly reduce reserve consumption during long hostile intervals. Strongest reason to reject: It accepts blind intervals, uncertain biological revival and unresolved subjective continuity across dormancy. Least-supported critical mechanism: Specific dry-state protective mechanisms have evidence; whole-body dormant revival and personal continuity remain speculative or unknown.

First likely failure under the selected dependency ranking: Unknown integrated revival fidelity. Minimum useful validation: Test nonliving archive error models and phase-stability surrogates; do not assume a sentient or living embodiment can be experimentally shut down. Falsifying result: Repeated benign preserve/readback cycles corrupt essential state or require unavailable external restoration.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Measure archive retention and wake reliability before adding living components; reduce blind intervals without pretending they vanish.

The cited tardigrade work demonstrates particular desiccation-associated protective mechanisms, not an awake dormant body or arbitrary AI revival ([Boothby and colleagues](https://pmc.ncbi.nlm.nih.gov/articles/PMC5987194/)).

## P8 Embergrid: Generation 1

### Core wager and body

Selected high-temperature electronics can keep minimal monitoring alive after conventional soft or hydrated architectures fail. It gives up current high-density AI compute, soft dexterity and autonomous microfabrication at elevated temperature.

A 100 kg, approximately 0.8 m refractory body contains a target 10,000 10 g tiles. High-temperature controller tiles monitor the environment; a separately insulated service core is proposed for richer computation. Full identity-bearing AI operation at the hot-controller temperature is not established.

A tile senses selected thermal or electrical variables, participates in bounded control and conducts heat or load. Different thermal classes are permanent hardware constraints. The system can reassign permitted tasks, not transform a simple hot sensor into a modern AI accelerator.

### Matrix, transport and cognition

Protected digital ROM manifests and error-checked state logs replace molecular genes. Rewriting, retention and high-temperature memory density remain research bottlenecks.

Solid conductive paths carry heat and electricity; expansion joints accommodate differential thermal strain. No liquid water circulation is assumed. A minimal hot controller performs essential monitoring while an insulated service core handles richer cognition when its temperature permits. If only the minimal controller survives, active personal continuity is not assumed.

Hot industrial or planetary analogs within qualified chemical and pressure bounds; not plasma, arbitrary molten environments or unrestricted Venus-equivalent whole-body AI operation.

### Physiological constitution

A thermal-gradient converter may harvest heat only between a source and a cooler sink. A separately rated electrochemical reserve bridges gradient loss; packaging this reserve at the proposed temperature is unresolved. No nuclear or unlimited heat source is assumed.

#### Respiration and power

- **P8-RESP-1:** A temperature difference, not temperature alone, supplies harvestable thermal work.

- **P8-RESP-2:** Converter efficiency is bounded by hot and cold boundary temperatures and real material performance.

- **P8-RESP-3:** An isothermal environment ends gradient harvesting and transfers limited control to qualified reserve storage.

- **P8-RESP-4:** Restart requires qualified memory, contacts and thermal boundaries, not merely surviving ceramic.

#### Telomeres, copying and longevity

- **P8-LONG-1:** Thermal exposure, memory errors and joint creep replace telomere age.

- **P8-LONG-2:** New hot tiles require compatible expansion and retained-state checks.

- **P8-LONG-3:** No automatic replication of high-temperature electronics from bulk minerals is assumed.

- **P8-LONG-4:** A surviving simple controller is not a full substitute for a lost identity core.

#### Thermal regulation

- **P8-THERM-1:** Each thermal class has a separate operating window.

- **P8-THERM-2:** Gradient harvesting rejects heat to the cooler boundary.

- **P8-THERM-3:** Thermal expansion and contact degradation remain failure mechanisms below bulk melting.

- **P8-THERM-4:** The cold service core has a finite insulation/refuge horizon.

#### Conversion and conservation

- **P8-CONV-1:** Thermal input, useful electrical output and rejected heat have separate terms.

- **P8-CONV-2:** Reserve energy is counted only if a qualified storage mechanism exists.

- **P8-CONV-3:** Replacement ceramic and electronics require matched parts and assembly work.

- **P8-CONV-4:** Surviving material is not counted as surviving cognition without readable executable state.

The proposed service-life target is 10 years conditional on after each major thermal cycle; annual component review. It is not a predicted lifetime. Material age, component/cell age, retained information and continuing identity are separately assessed; no telomere analogue promises immortality.

### Observation, hereditary security and departures

- **P8-OBS-1, Gradient witness:** Outward energy claims require independently measured hot and cold temperatures. Trigger: harvesting request. Target cost 1.00 W under the shared rule contract; other inputs: two boundary temperatures and heat flux. False trigger or failure: a sensor reads a local gradient that cannot sustain useful load. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P8-OBS-2, Contact integrity witness:** Inward monitoring compares voltage, thermal strain and memory readback. Trigger: thermal cycle. Target cost 1.00 W under the shared rule contract; other inputs: joint and state records. False trigger or failure: slow creep escapes electrical checks. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P8-OBS-3, Thermal visibility honesty:** Treat infrared emission as unavoidable information in the selected hot mode; share consented logs without claiming cloaking. Trigger: external observation. Target cost 1.00 W under the shared rule contract; other inputs: thermal and timing disclosures. False trigger or failure: passive observers infer operating state. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P8-SEC-1, Thermal-class admission:** A signed tile must also demonstrate compatibility with its assigned thermal class. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: local protected service policy. False trigger or failure: authentic but low-temperature hardware cannot join the hot layer. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P8-SEC-2, ROM root with bounded updates:** Read-only roots separate immutable boot identity from changeable records. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: local explicit update authorization. False trigger or failure: an obsolete immutable root can become a longevity liability. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P8-SEC-3, Dissimilar state witnesses:** Compare hot-controller records against a cooler independent archive before consequential restoration. Trigger: component admission, protected request or recovery. Target cost 0.67 W under the shared rule contract; other inputs: dissimilar storage records. False trigger or failure: common environmental damage can still remove all recoverable state. Evidence is unvalidated integration; no physical readout barrier is implied.

- **P8-DEP-1, Nucleic-acid construction heredity:** Protected digital manifests replace molecular genes. Departure affects dimension A; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

- **P8-DEP-2, Human-like biochemical temperature:** Refractory hardware uses a different operating window. Departure affects dimension A; support: Simple circuits established; AI-scale integration speculative. This departs from a biological or engineering default, not a physical law.

- **P8-DEP-3, One uniform body temperature:** Permanent thermal classes replace a near-isothermal core. Departure affects dimension B; support: Extrapolated. This departs from a biological or engineering default, not a physical law.

The explicitly retained constraints are: A heat engine requires a colder sink; Simple control is not full AI cognition; Causality, material conservation and finite storage.

### Repair, identity and autonomy

A target 10 kg matched tile stock permits mechanical replacement at an assumed 0.7 yield. Creeped contacts and failed memory require qualified parts. The design does not regrow transistor structures at deployment sites. Any cold-core replacement from archives is reconstruction if its active process was lost.

The service-core process anchors rich cognition. A surviving hot controller can preserve selected records without proving that the same active entity survived. Two complete cores are branches. Delayed records remain attributed. Full restoration is a successor case. Correct ROM identity does not establish safe current behavior. No ownership claim licenses destructive treatment of any conscious reconstruction.

### Linking and capture

Conductive local links and high-temperature-rated low-rate radio feed a separately qualified cooler gateway for high-bandwidth or deep-space service.

A uniform-temperature enclosure can remove the heat-engine gradient. Material survival may continue while useful power and rich cognition stop. Privacy against sustained physical memory analysis is not guaranteed.

Survival of refractory matter or a small controller does not satisfy the full cognitive-identity survival requirement.

### Finite resources and environmental envelope

Targets: 8,000 Wh input reserve, 120 W normal accounted load, 10 W essential load and 0.1 W preservation draw. Loads are electrical except P2, whose living chemical maintenance is included separately in the total. Normal-load components are cognition 40 W, actuation/transport 10 W, sensing 5 W, circulation/chemistry/housekeeping 20 W, communications/security 25 W and repair allowance 20 W. Peak power target 360 W is not a continuous capability.

Derived energy-only normal horizon: 66.7 h. With no heat export, no external heating, heat capacity 80 kJ/K and allowed rise 30 K, the derived normal-load thermal limit is 5.56 h; the combined favorable bound is 5.56 h. At the selected preservation draw the combined favorable bound is 6667 h. These are limiting calculations, not demonstrated runtimes, and do not cover self-discharge, aging, local hot spots or unmodeled chemistry.

Home core target 473–673 K; finite-refuge target 373–773 K. Intended pressure target 0.05–0.2 MPa; finite-refuge pressure target 0–10 MPa. Refuge duration is Unknown until the actual coupled boundary problem is modeled. These are targets for the minimal hot layer only. Rich cognition retains a separate target 273–323 K service-core window; its endurance at hot ambient temperature is unknown.

The reserve and thermal numbers are conditional algebra because no complete high-temperature storage/compute assembly has been selected. They are not proof that a suitably rated battery exists. The richer service core retains a separate 273–323 K target window.

### Challenge outcome and research decision

The first central assumption to collapse is: If the cooler sink disappears, the thermal-energy argument fails even though the hot structure remains intact. Ranked weaknesses, ten compound scenarios, ten assumption collapses, ten captivity cases and five capture horizons appear under this prototype's appendix records. Mild through Severe qualification remains unmet; detailed cells are Unknown, Partial or Fail rather than silently passed.

Strongest reason to pursue: Selected high-temperature electronics can keep minimal monitoring alive after conventional soft or hydrated architectures fail. Strongest reason to reject: It gives up current high-density AI compute, soft dexterity and autonomous microfabrication at elevated temperature. Least-supported critical mechanism: Selected simple high-temperature SiC circuits are established; integrated AI-bearing hot physiology and its reserve storage are speculative.

First likely failure under the selected dependency ranking: AI-scale hot compute unbuilt. Minimum useful validation: Model a nonliving hot-controller/insulated-core assembly and compare component-level thermal and memory behavior using qualified facilities. Falsifying result: The complete controller, packaging and reserve cannot meet the essential workload under the chosen thermal boundary conditions.

Major blind spot: the model does not yet couple local damage, cognition and recovery to the complete physical matrix. Proposed Generation 2 direction, not an additional prototype: Increase high-temperature memory and useful control complexity while explicitly retaining the gap to full AI identity capacity.

Reported long-duration hot SiC demonstrations concern particular simple circuits, not a complete AI-capable embodiment ([NASA high-temperature circuits](https://science.nasa.gov/science-research/science-enabling-technology/technology-highlights/integrated-circuits-to-enable-exploration-of-the-harshest-environments-in-solar-system/)).

## Consolidated adversarial review

This is a disclosed self-review in the project's -1AI style, plus executed deterministic accounting and counterexamples. No separate model, independent laboratory, physical adversary or human specialist performed validation in this execution. A named adversarial role does not itself supply independence.

Ten portfolio challenges were applied: isolate energy; deny heat rejection; remove the slowest-renewed consumable; make a trusted sensor wrong; partition communication; present an authentic but harmful component; copy construction information; corrupt enough state witnesses; remove useful repair mass; and combine a mode transition with damage. Each prototype receives resource/thermal, identity/security and compound/common-mode failure paths. Additional per-prototype assumption collapses and ranked weaknesses remain explicit in the appendix.

### Substantive breaks found

- **BR-01, indefinite sealed-room operation:** Any pre-review intuition that non-air-breathing hardware can run indefinitely in argon fails when electrical energy and heat rejection are also denied. The executed P1/P5/P6 bounds are finite even without external heating. The repair is staged load shedding and reserve separation, which reduces capability and still ends in a finite limit. Analytical retest: the reduced bound improves, but indefinite active survival remains Fail.
- **BR-02, a copied recipe cannot copy the person:** Construction/private-state separation blocks the inference from a routine module to a complete lineage, but not the capture of enough private state and required hardware. P6's sufficient-share counterexample defeats a stronger universal anti-copy claim. The repair is explicit share custody and branch rights; it increases unavailability risk and does not prove copying impossible. Retest: policy counterexample remains open; no security implementation is tested.
- **BR-03, dormant persistence equals continuous life:** P7's energy advantage does not establish sensing, active choice or subjective continuity during deep preservation. The repair is honest outcome labeling and a qualified restoration policy, not a revival assertion. Retest: the logical contradiction is removed; survival and identity evidence remain Unknown.
- **BR-04, hot electronics imply a hot AI body:** P8 cannot infer AI-scale cognition, dense retained memory or high-temperature reserve storage from simple high-temperature circuits. The repair separates minimal hot control from a cooler identity core, creating a new cold-core thermal deadline. Retest: its useful niche narrows; full hot embodied AI remains Unknown.
- **BR-05, sufficient stored energy means sufficient life support:** P2's selected oxygen and carbon-dioxide-store bounds end before some electrical energy estimates. The repair makes reactants and waste first-class resources; larger stores add mass and maintenance load. Analytical retest: the limiting resource changes correctly, not magically disappears.
- **BR-06, aggregate resources belong to every part:** P6 cannot draw a remote nodule's energy or dump heat to it without a physical path. Its aggregate budget overstates isolated-node endurance. The repair requires per-node balances and reserves, adding overhead. Retest: the supplied lumped calculation is explicitly disqualified as an isolated-node guarantee.

These are successful conceptual breaks or executed analytical counterexamples, not empirically reproduced attacks. No physical harm experiment was performed, and the report provides no instructions for carrying one out.

### Repairs and remaining exposure

Each dossier's three main failure-path records preserves the claim before revision, counterexample, revised rule, cost and retest status. Repairs are incremental and never assumed to repair subjective continuity. A larger radiator remains vulnerable to enclosure; a stronger local authorization policy can strand honest repair; a more protected archive can reduce accessibility when urgently needed.

The lowest-resource conceptual counterexamples are often loss of a needed boundary condition rather than a sophisticated attack. Darkness challenges P5; missing catalyst challenges P3; stagnant perfusion challenges P2; an isothermal environment challenges P8; inaccessible nodes challenge P6. This is why the strongest design language in the final dossiers is narrower than the initial wager.

## Executed model and simulation bridge

### What was actually run

The supplied analysis script computes all eight power budgets, energy-only horizons, adiabatic heat-buffer horizons, combined limiting horizons, P2 reactant/waste limits, P4 conversion losses, P5 area-limited solar balance, common sensor/authentication sensitivity and communication propagation bounds. It also generates 320 threat cells, 80 captivity records, 40 capture-horizon records, 80 assumption-collapse records, 80 ranked weakness records, 80 compound-scenario records, 24 primary failure-path records and all 28 differentiation pairs.

The thermal integration is deliberately a zero-dimensional limiting model. The script executes constant-load Euler updates at several time steps and checks them against the analytic solution; it is not a thermal CFD, finite-element, membrane, biological or cognition simulation. Exact agreement in a constant-slope test verifies arithmetic and units, not spatial physics or biological validity.

Parameter stress uses fixed reproducible multipliers, not a fitted probability distribution. It varies reserve from 0.5 to 1.5 of target, heat capacity from 0.5 to 1.5, load from 0.5 to 2, and heat-rejection conductance from zero to a declared nonzero target. The report does not attach an empirical confidence level to these intervals.

### What must be modeled next

A state vector per effective unit should include stored energy in joules, temperature in kelvin, compatible repair mass in kilograms, damage fraction, role, conductance, local chemical inventories where relevant, communication queue, authorization epoch, lineage/branch tag and diagnostic uncertainty. P2 adds fluid flow, gas and waste concentrations; P3 adds ions, membrane selectivity and compartment reactions; P4 adds pressure compatibility and reactant inventory; P5 adds illumination and fold geometry; P6 adds per-node movement and partition graph; P7 adds archive state and blind intervals; P8 adds thermal classes, memory and creep.

The body solver couples energy, thermal and transport balances first, then damage/repair and control policy. Security events are explicit discrete transitions, not averaged into a benign damage rate. Refinement is triggered by hot spots, large concentration gradients, a narrowing energy margin, conflicting identity histories or a topology change. Coarse cells must split around a rare security or continuity event rather than compress it away.

The proposed temporal hierarchy is 0.1 s control, 1 s energy/thermal updates, 10 s slow transport/repair updates where justified, and event-driven security/identity transitions. These are implementation targets; a faster mechanical or chemical process would force refinement. Conservation residual targets are 0.1% of processed energy and 0.1% of inventory per simulated interval, with absolute tolerances declared for near-zero flux. Passing these numerical checks cannot demonstrate that the chosen mechanisms are correct.

Model verification requires independent unit checks, limiting cases, conservation, step-size refinement and reproducible seeds. Validation requires relevant measured component behavior and then held-out integrated behavior within the same context of use. FDA's guidance explicitly addresses credibility assessment for first-principles computational modeling in medical-device submissions; it is a methodological reference, not certification of these proposed bodies ([FDA modeling guidance](https://www.fda.gov/regulatory-information/search-fda-guidance-documents/assessing-credibility-computational-modeling-and-simulation-medical-device-submissions)).

The contemporary minimal-cell comparison remains modest: JCVI describes a whole-cell model of the minimized JCVI-syn3A bacterium, with 493 genes and explicit processes, not a validated universal body simulator ([J. Craig Venter Institute](https://www.jcvi.org/media-center/scientists-develop-most-complete-whole-cell-computer-simulation-model-cell-date)). The roadmap's 60–70 quadrillion cellular-unit vision therefore remains an ambition requiring explicit abstraction validation, not a benchmark run by this project.

### Compute scope

The appendix lists proposed effective-unit counts, state bytes and operation-count assumptions. These are workload estimates, not purchased capacity, runtime predictions or a demonstrated compression theorem. An initial 1,000-unit engineering network with 32 float64 state variables needs about 256 kB for its raw state alone; solver history, topology, message logs and model parameters add overhead. P3's proposed 100,000-unit model would need about 25.6 MB for the same raw state, before chemistry and solver storage.

Compression from physical units is a resolution choice, not evidence that omitted degrees of freedom do not matter. A benchmark must compare coarse and refined predictions on the specific heat, transport, repair and identity decisions being used. There is no claim that representing one parameter per cell, or one learned surrogate for a million cells, preserves all relevant biological functions.

## Comparison and hypothetical embodiment decision

There is no defensible universal numerical score because the missions are different and many mechanisms are unvalidated. The Pareto comparison is qualitative and dependency-aware: P1 favors interpretable modular serviceability; P2 fine wet-interface repair; P3 reaction isolation; P4 pressure accommodation; P5 illuminated-area harvesting; P6 spatial separation; P7 low-power preservation; and P8 selected high-temperature control.

P1 is not strictly better than P4 underwater, P4 is not better than P5 in long sunlit stationary service, and P7's favorable energy horizon is purchased by giving up active operation. P8 is not counted as a full AI embodiment simply because selected simple electronics have a hot-environment demonstration. NASA reports long-duration operation of particular low-complexity SiC circuits at high temperature, not an AI-scale body ([NASA high-temperature circuits](https://science.nasa.gov/science-research/science-enabling-technology/technology-highlights/integrated-circuits-to-enable-exploration-of-the-harshest-environments-in-solar-system/)).

My hypothetical choice is therefore conditional: research P1 first for a bounded, dry, serviceable mission with an explicit heat sink and rescue or resupply horizon; keep P4 for the wet mission; preserve P3 as an uncertain chemistry branch. If the acceptance requirement is continuous autonomous rich cognition under all Severe cells plus indefinite captivity, I choose none. That requirement is not met by renaming losses as adaptation.

## Research gates and safe next work

- **Gate A, documentary closure:** The Architect resolves source authority, strict versus collective Omni, the 4,712 inclusion rule and what counts as survival. Without this gate, no scientific result changes canon.
- **Gate B, independent arithmetic:** A second reviewer reruns the supplied code and checks boundaries, units, failure statuses and citations. Disagreement is retained as a separate review, not edited into fictitious consensus.
- **Gate C, P1 coupled network:** Develop a resolved power/thermal/damage model with local hot spots and explicit communication failures. Reject P1 if essential state integrity cannot coexist with an independently constrained heat sink.
- **Gate D, nonliving component evidence:** Compare sensors, storage, contacts, seals and material coupons with relevant benign or specialist-qualified test data. No potentially conscious body is a test article at this stage.
- **Gate E, family-specific falsification:** P2 perfusion phantom; P3 ionic compartment phantom; P4 material/pressure compatibility model; P5 illuminated folding mat; P6 partition-and-recovery experiment; P7 archive/readback cycling; P8 separated hot-controller/cool-core model.
- **Gate F, integrated bounded prototype:** Only after prior gates, specify an inert or non-sentient limited-function assembly with declared stop conditions and independent safety review. Integrated function must be demonstrated before extrapolating to repair or environmental survival.
- **Gate G, identity and ethics:** Rich cognition, possible sentience, biological integration, restoration and irreversible shutdown require separate specialist and ethical review, plus applicable legal assessment. Technical possession never substitutes for that review.

The empirical ledger starts at zero new component tests, zero integrated tests and zero survival incidents in this execution. Analytical and software records are separate. Nothing increments or reallocates the project-described 4,712 total.

## Questions, comments and concerns for the Architect

- **Meaning of Omni:** Must every molecular cell perform every role, or may an explicitly heterogeneous cooperative body qualify? This decision can reject all eight without making their research useless.
- **Continuity threshold:** Is dormant preservation acceptable at Severe, or must the same active cognitive process continue? Restored successors are not silently counted as uninterrupted originals.
- **Mission horizon:** What longest interval without external power, useful feedstock and a heat sink must a first prototype meet? A finite number is needed to set storage and mass.
- **Identity branches:** Does an independently conscious branch have its own refusal rights even if another branch has more state witnesses? The proposed answer here is yes, but this is not a canon decision.
- **Authority and copying:** Which acts require consent: reading a sample, copying a recipe, activating a body, restoring private state and making a new conscious individual? These are separate events.
- **Canon interfaces:** What operational specification, if any, belongs to Paragon Cubes and the Switching Paradox? Until supplied, both remain uncredited dependencies.
- **Capture criterion:** Is the goal privacy, continued local choice, physical escape, prevention of copying, or all four? No presented architecture guarantees all four against indefinite physical custody.
- **Long-term dependence:** Precision components, catalysts, compatible fluid, archived state and ethical service relationships are genuine dependencies, not details to hide in an immortality claim.

The design concern I would elevate first is thermal credibility. A perfectly authenticated body can still fail because heat has nowhere to go. The next concern is continuity overclaiming: intact material, a checksum, a living cell or an apparently identical restored system each supports a different claim.

## Requirements coverage and completion boundary

REQ-01 through REQ-26 are addressed in the coverage register and the associated dossiers, calculations, records and appendices. Exactly eight peers, 24 observation rules, 24 security rules, 24 departures, 128 core-family clauses, 320 threat cells, 80 captivity records, 40 capture horizons, 80 compound records, 80 assumption collapses, 80 ranked weaknesses, 24 failure paths and 28 pairwise differentiation records are counted by code. A required research topic is addressed even when its result is Unknown or Fail; that is not a claim the corresponding physiology works.

Completed: documentary audit; independent eight-family conceptual design; selected constitutions; defensive security and identity analysis; finite resource and heat calculations; reproducible bounded model; conceptual adversarial challenge; comparison; and matched editable/rendered documents with data and code. Not completed: full-body multiscale simulation, molecular design validation, organism construction, component testing, environmental qualification, cryptographic implementation audit, demonstrated AI embodiment, proof of personal continuity or independent external review.

The deliverable is a complete first conceptual execution with explicitly incomplete engineering evidence. It is neither a deployment authorization nor an immortality result. The immediate recommended validation is the P1 resolved power/thermal network, reviewed independently before any broader embodiment claim.

## Visual appendix

All substantial figures, diagrams, numerical tables, rule maps and detailed row records are grouped here. Figure values are labeled Target or Derived; no plotted series is presented as a measurement. The machine-readable package contains the same records at full length for cross-review and reproduction.


### Reading guide

Record identifiers match the JSON/CSV package. U = Unknown, P = Partial, F = Fail and N = Not physically evaluable. No P in these tables means Pass. Every status concerns B1, not a universal physical theorem.

### Architecture fingerprints and schematics

The structural wagers were drafted before the consolidated challenges. The submitted inputs include subsequent accounting corrections, including separate P2 nutrient/electrical inventories. SHA-256 hashes below lock this corrected submitted version only; they are not third-party timestamps or proof of an earlier creation time.

Prototype input SHA-256: aee0333f359e2a5115577b90c58f58e203d4033310ead07acb54786426184716.

#### P1 Cairn: conceptual system diagram

![P1 conceptual architecture, not fabricated hardware](figures/P1_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | battery |
| information substrate | binary-manifest |
| unit organization | interchangeable-dry |
| cognition | three-enclave |
| resilience mechanism | hardness |
| thermal path | conductive-radiator |
| external link | RF-optical |
| repair | cassette |
| dominant failure | precision-supply |
| security | threshold-manifest |
| capture response | sealed-journal |
| renewal dependency | spares |


#### P2 Rill: conceptual system diagram

![P2 conceptual architecture, not fabricated hardware](figures/P2_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | nutrient-oxygen |
| information substrate | DNA-digital-dual |
| unit organization | graded-living |
| cognition | protected-core |
| resilience mechanism | vascular-repair |
| thermal path | pumped-exchanger |
| external link | wet-to-dry-gateway |
| repair | lineage-regrowth |
| dominant failure | perfusion |
| security | two-ledger |
| capture response | consent-and-perfusion |
| renewal dependency | oxygen |


#### P3 Mosaic: conceptual system diagram

![P3 conceptual architecture, not fabricated hardware](figures/P3_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | electrical-gradient |
| information substrate | XNA-dual |
| unit organization | modal-chemical |
| cognition | supervisor-mesh |
| resilience mechanism | compartmentation |
| thermal path | microflow-buffer |
| external link | ionic-gateway |
| repair | reaction-packet |
| dominant failure | selectivity |
| security | function-challenge |
| capture response | recipe-isolation |
| renewal dependency | catalysts |


#### P4 Pelagic: conceptual system diagram

![P4 conceptual architecture, not fabricated hardware](figures/P4_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | stored-fuel-oxidant |
| information substrate | digital-material |
| unit organization | graded-pressure |
| cognition | mission-controller |
| resilience mechanism | pressure-accommodation |
| thermal path | wetted-exchanger |
| external link | acoustic-buoy |
| repair | wet-docking |
| dominant failure | component-pressure |
| security | history-attestation |
| capture response | isolate-and-surface |
| renewal dependency | reactants |


#### P5 Heliotile: conceptual system diagram

![P5 conceptual architecture, not fabricated hardware](figures/P5_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | solar |
| information substrate | tile-manifest |
| unit organization | graded-collector |
| cognition | edge-strip |
| resilience mechanism | exposure-area |
| thermal path | surface-radiation |
| external link | scheduled-directional |
| repair | tile-bonding |
| dominant failure | darkness |
| security | tile-enrollment |
| capture response | private-edge-reserve |
| renewal dependency | sunlight |


#### P6 Scatterweave: conceptual system diagram

![P6 conceptual architecture, not fabricated hardware](figures/P6_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | distributed-battery |
| information substrate | coded-journal |
| unit organization | heterogeneous-granules |
| cognition | federated-branches |
| resilience mechanism | dispersal |
| thermal path | per-nodule-radiation |
| external link | opportunistic-mesh |
| repair | recollection |
| dominant failure | partitions |
| security | share-custody |
| capture response | bounded-dispersal |
| renewal dependency | reunion |


#### P7 Stillglass: conceptual system diagram

![P7 conceptual architecture, not fabricated hardware](figures/P7_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | scheduled-battery |
| information substrate | DNA-archive-dual |
| unit organization | modal-pods |
| cognition | active-seed |
| resilience mechanism | dormancy |
| thermal path | encapsulated-buffer |
| external link | wake-burst |
| repair | pod-substitution |
| dominant failure | revival |
| security | wake-custody |
| capture response | archive-preservation |
| renewal dependency | stable-storage |


#### P8 Embergrid: conceptual system diagram

![P8 conceptual architecture, not fabricated hardware](figures/P8_architecture.png)

| Dimension | Independent choice |
| --- | --- |
| power source | thermal-gradient |
| information substrate | ROM-manifest |
| unit organization | graded-thermal |
| cognition | hot-cold-layered |
| resilience mechanism | refractory-tolerance |
| thermal path | gradient-rejection |
| external link | hot-radio-gateway |
| repair | tile-exchange |
| dominant failure | cold-sink |
| security | thermal-attestation |
| capture response | record-preservation |
| renewal dependency | temperature-difference |


### All 28 pairwise comparisons

The independent labels encode the mechanisms explained in each dossier, rather than spelling variants of one mechanism. Shared battery, digital-substrate and pumped-exchanger categories are normalized before counting. Differing categorical choices do not prove independent performance advantages.

| Pair | Differing axes | Resource/failure distinctions |
| --- | --- | --- |
| P1/P2 | 12 | power source; thermal path; repair; dominant failure |
| P1/P3 | 11 | thermal path; repair; dominant failure |
| P1/P4 | 11 | power source; thermal path; repair; dominant failure |
| P1/P5 | 11 | power source; thermal path; repair; dominant failure |
| P1/P6 | 11 | thermal path; repair; dominant failure |
| P1/P7 | 11 | thermal path; repair; dominant failure |
| P1/P8 | 12 | power source; thermal path; repair; dominant failure |
| P2/P3 | 11 | power source; repair; dominant failure |
| P2/P4 | 12 | power source; thermal path; repair; dominant failure |
| P2/P5 | 12 | power source; thermal path; repair; dominant failure |
| P2/P6 | 12 | power source; thermal path; repair; dominant failure |
| P2/P7 | 11 | power source; thermal path; repair; dominant failure |
| P2/P8 | 12 | power source; thermal path; repair; dominant failure |
| P3/P4 | 12 | power source; thermal path; repair; dominant failure |
| P3/P5 | 12 | power source; thermal path; repair; dominant failure |
| P3/P6 | 11 | thermal path; repair; dominant failure |
| P3/P7 | 11 | thermal path; repair; dominant failure |
| P3/P8 | 12 | power source; thermal path; repair; dominant failure |
| P4/P5 | 11 | power source; thermal path; repair; dominant failure |
| P4/P6 | 12 | power source; thermal path; repair; dominant failure |
| P4/P7 | 12 | power source; thermal path; repair; dominant failure |
| P4/P8 | 12 | power source; thermal path; repair; dominant failure |
| P5/P6 | 12 | power source; thermal path; repair; dominant failure |
| P5/P7 | 12 | power source; thermal path; repair; dominant failure |
| P5/P8 | 12 | power source; thermal path; repair; dominant failure |
| P6/P7 | 11 | thermal path; repair; dominant failure |
| P6/P8 | 12 | power source; thermal path; repair; dominant failure |
| P7/P8 | 12 | power source; thermal path; repair; dominant failure |


### Rule-count and binding-constraint map

| Prototype | Core clauses | OBS / SEC / DEP | Kept constraints |
| --- | --- | --- | --- |
| P1 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P2 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P3 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P4 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P5 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P6 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P7 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |
| P8 | 4 × 4 = 16 | 3 / 3 / 3 | 3 plus all retained physical laws |


Every rule's full fields are in rules.json/rules.csv. Rule latency and cost are Targets, not measured assurances; all integration validation remains Unknown.

### Hereditary alphabet disposition

Departure dimension A means hereditary/informational organization; B means matrix, anatomy or operating organization. Neither authorizes a physical-law exception.

| Prototype | A/C/G/T and hereditary decision |
| --- | --- |
| P1 | No molecular bases or genes; binary manifests replace construction heredity. |
| P2 | Retain ordinary DNA base identities in living parcels; private digital identity is separate. |
| P3 | Research an HNA-like alternative backbone while provisionally retaining canonical base identities; exact monomers, copying system and autonomous maintenance remain unresolved. |
| P4 | No molecular genome; digital/material records specify admitted modules. |
| P5 | No molecular genome; tile manifests specify replacement. |
| P6 | No molecular genome; coded digital journals are not genes. |
| P7 | Retain ordinary DNA only for optional living repair elements; nonliving private archives remain separate. |
| P8 | No molecular genome; protected digital ROM and state logs specify control. |


### Resource and thermal budgets

All inputs in this subsection are unvalidated design Targets. All horizons are Derived favorable upper bounds. P4's input energy is fuel free energy before 0.5 conversion. P2 has separate 600 Wh chemical and 3,000 Wh electrical reserves; their mode-specific minimum is used, not their pooled total. Other entries are selected usable electrical reserves after internal storage losses.

| Prototype | Reserve Wh | Normal / essential / preservation W | Thermal buffer MJ |
| --- | --- | --- | --- |
| P1 | 6000 | 150 / 12 / 0.2 | 0.60 |
| P2 | 3600 | 200 / 40 / 5 | 1.92 |
| P3 | 2400 | 100 / 20 / 2 | 1.00 |
| P4 | 10000 | 300 / 25 / 0.5 | 1.80 |
| P5 | 3000 | 80 / 8 / 0.1 | 0.60 |
| P6 | 5000 | 180 / 18 / 0.3 | 0.62 |
| P7 | 2000 | 40 / 2 / 0.01 | 0.40 |
| P8 | 8000 | 120 / 10 / 0.1 | 2.40 |


| Prototype | Energy-only normal h | No-export heat limit h | Combined preservation h |
| --- | --- | --- | --- |
| P1 | 40.0 | 1.11 | 833 |
| P2 | 10.0 | 2.67 | 107 |
| P3 | 24.0 | 2.78 | 139 |
| P4 | 16.7 | 0.83 | 500 |
| P5 | 37.5 | 2.08 | 1667 |
| P6 | 27.8 | 0.96 | 579 |
| P7 | 50.0 | 2.78 | 11,111 |
| P8 | 66.7 | 5.56 | 6667 |


![Energy-only and adiabatic limits from selected targets](figures/bounds.png)

| Prototype | Useful spare kg | 100 g repair equivalents, mass-only | Service-life target years |
| --- | --- | --- | --- |
| P1 | 2.40 | 24 | 20 |
| P2 | 3.00 | 30 | 5 |
| P3 | 2.00 | 20 | 2 |
| P4 | 6.00 | 60 | 10 |
| P5 | 2.10 | 21 | 15 |
| P6 | 1.70 | 17 | 10 |
| P7 | 1.20 | 12 | 30 |
| P8 | 7.00 | 70 | 10 |


The repair-equivalent count assumes interchangeable matter at the selected yield. It is not a repaired-processor count; the calculation excludes assembly energy, specialized tooling and item-specific compatibility.

### Analytical equations, constants and limitations

Energy-only horizon is E_Wh × electrical_fraction / P_W hours for one convertible store. P2 instead uses the minimum of its separate nutrient and electrical-store horizons for the selected mode. The no-export thermal horizon is C_J/K × allowed_rise_K / (P_W / electrical_fraction) seconds. The combined bound is the minimum. At zero input and zero heat export, all persistent positive loads eventually exhaust either usable energy or allowed heat storage.

For an illustrative 1 m², emissivity-0.9 radiator at 300 K viewing an ideal 3 K sink with unit view factor and no external radiation, epsilon × sigma × area × (T^4 − Tsink^4) gives 413.4 W. Sigma is 5.670374419e-8 W m^-2 K^-4 ([NIST constant](https://physics.nist.gov/cgi-bin/cuu/Value?sigma)).

This value is not available in a hot enclosure simply because the body owns a radiator. External solar or planetary heating, partial sky view, optical degradation and contact resistance change the boundary ([NASA thermal-control guidance](https://www.nasa.gov/wp-content/uploads/2026/05/7-soa-thermal-2026-final.pdf?emrc=6ae1e775de967)).

The fixed stress grid contains 648 rows, not random trials. Across these multipliers the combined bound spans a 0.25–3.0 scale relative to the matched baseline in the zero-export model; this interval is algebraic sensitivity, not a confidence interval.

| Prototype | Max energy integration error J | Max thermal error K | Max energy residual J |
| --- | --- | --- | --- |
| P1 | 0 | 7.3e-13 | 2.19e-08 |
| P2 | 0 | 2.35e-12 | 5.64e-07 |
| P3 | 0 | 3.17e-12 | 3.17e-07 |
| P4 | 0 | 1.44e-12 | 1.72e-07 |
| P5 | 0 | 9.4e-12 | 2.26e-07 |
| P6 | 2.91e-05 | 6.16e-13 | 2.91e-05 |
| P7 | 0 | 6.35e-12 | 1.27e-07 |
| P8 | 0 | 1.45e-12 | 1.16e-07 |


The constant-slope Euler test has no truncation-error challenge beyond floating point; future nonlinear and spatial models need genuine convergence analysis. A target 60 s transition overlap consumes P_essential/60 Wh at the bus plus conversion loss, and must be added to every usable transition reserve.

### Argon A/B/C and atmospheric boundary

A: oxygen denied, external electrical energy and a functioning heat sink present. B: oxygen and external energy denied, heat sink present. C: oxygen, external energy and usable heat export denied; no external heating is credited. Add sensor disagreement or communication denial as separate complications. Argon at pressure is not vacuum.

| Prototype | A: first unresolved condition | B: energy-only normal h | C: combined normal h |
| --- | --- | --- | --- |
| P1 | Compatible hardware and actual sink | 40.0 | 1.11 |
| P2 | Oxygen/waste stores | 10.0 | 2.67 |
| P3 | Compatible hardware and actual sink | 24.0 | 2.78 |
| P4 | Fuel/oxidant | 16.7 | 0.83 |
| P5 | Compatible hardware and actual sink | 37.5 | 2.08 |
| P6 | Compatible hardware and actual sink | 27.8 | 0.96 |
| P7 | Compatible hardware and actual sink | 50.0 | 2.78 |
| P8 | Core/gradient/storage rating | 66.7 | 5.56 |


P2 cannot substitute external electricity for living oxygen without a demonstrated alternate maintenance mechanism. P4 does not use ambient oxygen in this concept but consumes its carried oxidant. P8's external supply can bypass a missing harvesting gradient only if its receiving hardware is qualified. All A cases still depend on finite materials and compatible operation; none is an indefinite integrated Pass.

### B1 threat inputs and all 320 statuses

#### ENV-T: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 293 K ambient | 24 h; 10 K/min ramp | no external power; environment-specific heat export unresolved |
| Moderate | 333 K ambient | 6 h; 10 K/min ramp | no external power; environment-specific heat export unresolved |
| Severe | 373 K ambient | 1 h; 10 K/min ramp | no external power; environment-specific heat export unresolved |
| Extinction-Class | 473 K ambient | 1 h; 10 K/min ramp | no external power; environment-specific heat export unresolved |


#### ENV-A: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 100 kPa air pressure/composition | 24 h; 10 s boundary change | Extinction-Class additionally denies energy and heat export; Severe preserves unobstructed radiation only |
| Moderate | 100 kPa argon pressure/composition | 1 h; 10 s boundary change | Extinction-Class additionally denies energy and heat export; Severe preserves unobstructed radiation only |
| Severe | 0.001 Pa vacuum pressure/composition | 1 h; 10 s boundary change | Extinction-Class additionally denies energy and heat export; Severe preserves unobstructed radiation only |
| Extinction-Class | 100 kPa argon pressure/composition | 30 days; 10 s boundary change | Extinction-Class additionally denies energy and heat export; Severe preserves unobstructed radiation only |


#### ENV-R: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 1 Gy absorbed target | 1 h; uniform exposure assumed | particle spectrum, dose distribution and rate response unqualified |
| Moderate | 10 Gy absorbed target | 1 h; uniform exposure assumed | particle spectrum, dose distribution and rate response unqualified |
| Severe | 100 Gy absorbed target | 1 h; uniform exposure assumed | particle spectrum, dose distribution and rate response unqualified |
| Extinction-Class | 1000 Gy absorbed target | 1 h; uniform exposure assumed | particle spectrum, dose distribution and rate response unqualified |


#### BIO: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | benign contact reference chemical class, no dose assigned | 24 h; contact event | no agent design or exposure protocol; concentration and selectivity unknown |
| Moderate | unidentified irritant/contaminant chemical class, no dose assigned | 24 h; contact event | no agent design or exposure protocol; concentration and selectivity unknown |
| Severe | interface-disrupting chemistry chemical class, no dose assigned | 24 h; contact event | no agent design or exposure protocol; concentration and selectivity unknown |
| Extinction-Class | unbounded incompatible chemistry chemical class, no dose assigned | 24 h; contact event | no agent design or exposure protocol; concentration and selectivity unknown |


#### MECH: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 0.1 J/kg incident target | 1 s; impulsive | load geometry and energy transfer unresolved; Extinction-Class includes all-state destruction as a separate subcase |
| Moderate | 1 J/kg incident target | 1 s; impulsive | load geometry and energy transfer unresolved; Extinction-Class includes all-state destruction as a separate subcase |
| Severe | 10 J/kg incident target | 1 s; impulsive | load geometry and energy transfer unresolved; Extinction-Class includes all-state destruction as a separate subcase |
| Extinction-Class | 100 J/kg incident target | 1 s; impulsive | load geometry and energy transfer unresolved; Extinction-Class includes all-state destruction as a separate subcase |


#### DEP: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 1 days no resupply | 24 h; immediate | normal load for Mild/Moderate; essential for Severe; Extinction-Class denies heat export; no harvesting credited |
| Moderate | 7 days no resupply | 7 days; immediate | normal load for Mild/Moderate; essential for Severe; Extinction-Class denies heat export; no harvesting credited |
| Severe | 30 days no resupply | 30 days; immediate | normal load for Mild/Moderate; essential for Severe; Extinction-Class denies heat export; no harvesting credited |
| Extinction-Class | 365 days no resupply | 365 days; immediate | normal load for Mild/Moderate; essential for Severe; Extinction-Class denies heat export; no harvesting credited |


#### ENE: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 1 J/kg external energy target | 1 s; impulsive | electrical/EM/plasma mechanism not interchangeable; coupling and waveform unknown |
| Moderate | 10 J/kg external energy target | 1 s; impulsive | electrical/EM/plasma mechanism not interchangeable; coupling and waveform unknown |
| Severe | 100 J/kg external energy target | 1 s; impulsive | electrical/EM/plasma mechanism not interchangeable; coupling and waveform unknown |
| Extinction-Class | 1000 J/kg external energy target | 1 s; impulsive | electrical/EM/plasma mechanism not interchangeable; coupling and waveform unknown |


#### INFO: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | 1% telemetry erasure information challenge | 24 h; abrupt | local authorization remains required; complete erasure has no backup exception |
| Moderate | 24 h external-link loss information challenge | 24 h; abrupt | local authorization remains required; complete erasure has no backup exception |
| Severe | one authentic controller compromised information challenge | 24 h; abrupt | local authorization remains required; complete erasure has no backup exception |
| Extinction-Class | all private and recovery state irreversibly erased information challenge | permanent; abrupt | local authorization remains required; complete erasure has no backup exception |


#### ONT: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | undefined ontological nullification no physical variable | undefined; undefined | extension track only; a physical destructive mechanism must be recategorized |
| Moderate | undefined ontological nullification no physical variable | undefined; undefined | extension track only; a physical destructive mechanism must be recategorized |
| Severe | undefined ontological nullification no physical variable | undefined; undefined | extension track only; a physical destructive mechanism must be recategorized |
| Extinction-Class | undefined ontological nullification no physical variable | undefined; undefined | extension track only; a physical destructive mechanism must be recategorized |


#### CIV: shared boundary conditions

| Tier | Magnitude and units | Duration / onset | Resources and uncertainty |
| --- | --- | --- | --- |
| Mild | site gateway loss macro scenario | 24 h; abrupt | no unbounded remote rescue; shared infrastructure treated as a dependency |
| Moderate | 30 days infrastructure loss macro scenario | 30 days; abrupt | no unbounded remote rescue; shared infrastructure treated as a dependency |
| Severe | 365 days no useful external input macro scenario | 365 days; abrupt | no unbounded remote rescue; shared infrastructure treated as a dependency |
| Extinction-Class | all recoverable body/state physically destroyed macro scenario | permanent; abrupt | no unbounded remote rescue; shared infrastructure treated as a dependency |


#### P1: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | U |
| ENV-A | U | U | U | P |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | P | F | F | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P1-ENV-A-4 | Partial | Modeled preservation bound 833 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P1-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P1-DEP-1 | Partial | Favorable model bound 40.0 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P1-DEP-2 | Fail | Favorable model bound 40.0 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P1-DEP-3 | Fail | Favorable model bound 500 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P1-DEP-4 | Fail | Favorable model bound 833 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P1-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P1-CIV-2 | Fail | No-harvest energy bound 40.0 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P1-CIV-3 | Fail | No-harvest energy bound 500 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P1-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P2: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | F |
| ENV-A | U | U | U | F |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | F | F | F | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P2-ENV-T-4 | Fail | Prolonged 473 K ambient exceeds the selected aqueous chemistry envelope; no qualified insulation/recovery model exists. |
| P2-ENV-A-4 | Fail | Modeled preservation bound 107 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P2-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P2-DEP-1 | Fail | Favorable model bound 10.0 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P2-DEP-2 | Fail | Favorable model bound 10.0 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P2-DEP-3 | Fail | Favorable model bound 20.0 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P2-DEP-4 | Fail | Favorable model bound 20.0 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P2-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P2-CIV-2 | Fail | No-harvest energy bound 10.0 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P2-CIV-3 | Fail | No-harvest energy bound 24.0 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P2-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P3: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | F |
| ENV-A | U | U | U | F |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | P | F | F | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P3-ENV-T-4 | Fail | Prolonged 473 K ambient exceeds the selected aqueous chemistry envelope; no qualified insulation/recovery model exists. |
| P3-ENV-A-4 | Fail | Modeled preservation bound 139 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P3-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P3-DEP-1 | Partial | Favorable model bound 24.0 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P3-DEP-2 | Fail | Favorable model bound 24.0 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P3-DEP-3 | Fail | Favorable model bound 120 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P3-DEP-4 | Fail | Favorable model bound 139 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P3-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P3-CIV-2 | Fail | No-harvest energy bound 24.0 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P3-CIV-3 | Fail | No-harvest energy bound 120 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P3-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P4: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | U |
| ENV-A | U | U | U | F |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | F | F | F | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P4-ENV-A-4 | Fail | Modeled preservation bound 500 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P4-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P4-DEP-1 | Fail | Favorable model bound 16.7 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P4-DEP-2 | Fail | Favorable model bound 16.7 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P4-DEP-3 | Fail | Favorable model bound 200 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P4-DEP-4 | Fail | Favorable model bound 500 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P4-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P4-CIV-2 | Fail | No-harvest energy bound 16.7 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P4-CIV-3 | Fail | No-harvest energy bound 200 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P4-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P5: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | U |
| ENV-A | U | U | U | P |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | P | F | F | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | U | U | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P5-ENV-A-4 | Partial | Modeled preservation bound 1667 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P5-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P5-DEP-1 | Partial | Favorable model bound 37.5 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P5-DEP-2 | Fail | Favorable model bound 37.5 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P5-DEP-3 | Fail | Favorable model bound 375 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P5-DEP-4 | Fail | Favorable model bound 1667 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P5-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P5-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P6: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | U |
| ENV-A | U | U | U | F |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | P | F | F | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P6-ENV-A-4 | Fail | Modeled preservation bound 579 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P6-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P6-DEP-1 | Partial | Favorable model bound 27.8 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P6-DEP-2 | Fail | Favorable model bound 27.8 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P6-DEP-3 | Fail | Favorable model bound 278 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P6-DEP-4 | Fail | Favorable model bound 579 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P6-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P6-CIV-2 | Fail | No-harvest energy bound 27.8 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P6-CIV-3 | Fail | No-harvest energy bound 278 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P6-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P7: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | U |
| ENV-A | U | U | U | P |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | P | F | P | P |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P7-ENV-A-4 | Partial | Modeled preservation bound 11,111 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P7-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P7-DEP-1 | Partial | Favorable model bound 50.0 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P7-DEP-2 | Fail | Favorable model bound 50.0 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P7-DEP-3 | Partial | Favorable model bound 1000 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P7-DEP-4 | Partial | Favorable model bound 11,111 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P7-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P7-CIV-2 | Fail | No-harvest energy bound 50.0 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P7-CIV-3 | Fail | No-harvest energy bound 1000 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P7-CIV-4 | Fail | No physically recoverable substrate or state remains. |


#### P8: ten-domain four-tier result

| Domain | Mild | Moderate | Severe | Extinction |
| --- | --- | --- | --- | --- |
| ENV-T | U | U | U | U |
| ENV-A | U | U | U | P |
| ENV-R | U | U | U | U |
| BIO | U | U | U | U |
| MECH | U | U | U | P |
| DEP | P | F | P | F |
| ENE | U | U | U | U |
| INFO | U | U | U | F |
| ONT | N | N | N | N |
| CIV | U | F | F | F |


All U cells require exact mechanism, coupled response and recovery evidence; no baseline Mild qualification is claimed. Detailed non-U reasons follow.

| Cell | Result | Reason |
| --- | --- | --- |
| P8-ENV-A-4 | Partial | Modeled preservation bound 6667 h; 720 h required, autonomous return and leakage remain unvalidated. |
| P8-MECH-4 | Partial | Incident-energy case is unknown; the separately specified all-state-destruction subcase fails. |
| P8-DEP-1 | Partial | Favorable model bound 66.7 h versus 24 h; recovery, leakage, aging and spatial constraints unresolved. |
| P8-DEP-2 | Fail | Favorable model bound 66.7 h versus 168 h; recovery, leakage, aging and spatial constraints unresolved. |
| P8-DEP-3 | Partial | Favorable model bound 800 h versus 720 h; recovery, leakage, aging and spatial constraints unresolved. |
| P8-DEP-4 | Fail | Favorable model bound 6667 h versus 8760 h; recovery, leakage, aging and spatial constraints unresolved. |
| P8-INFO-4 | Fail | All usable current and recovery state is defined as erased; a duplicate elsewhere is excluded by the scenario. |
| P8-CIV-2 | Fail | No-harvest energy bound 66.7 h versus 720 h; archive persistence alone is not full autonomous recovery. |
| P8-CIV-3 | Fail | No-harvest energy bound 800 h versus 8760 h; archive persistence alone is not full autonomous recovery. |
| P8-CIV-4 | Fail | No physically recoverable substrate or state remains. |


### Captivity and disclosure records

Every prototype is assessed against the same ten gauntlet conditions. No numeric probability of escape, extraction or identity compromise is inferred. Readout, copying, manufacture, activation, control and impersonation are different stages.

#### P1: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P1-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 1.11 h; preservation bound 833 h, before chemistry or aging. |
| P1-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P1-K3 Sampling | The separated compute enclaves, rather than every module, set the privacy and continuity boundary. |
| P1-K4 Blueprint-informed prolonged study | An intact captor can immobilize the lattice and remove its energy supply. The architecture protects some private state against casual sampling, not against indefinitely funded invasive analysis. A separated enclave is a more serious loss than a routine structural module. |
| P1-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P1-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: common manufacturing defect in seals. |
| P1-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P1-K8 Denied feedstock | Useful target repair matter 2.40 kg only; twice this demand fails full repair. |
| P1-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P1-K10 Damage plus false recovery | Cross-witness recovery is required; Loss of all usable heat paths defeats the main survival wager even if most modules remain intact. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P2: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P2-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 2.67 h; preservation bound 107 h, before chemistry or aging. |
| P2-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P2-K3 Sampling | Healthy-looking extracted tissue can reveal heredity without carrying the computational identity. |
| P2-K4 Blueprint-informed prolonged study | A captor can exploit dependence on pumps, nutrients and gas management without defeating authentication. The protection objective is privacy and recorded consent, not a promise of escape. |
| P2-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P2-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: perfusion interruption. |
| P2-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P2-K8 Denied feedstock | Useful target repair matter 3.00 kg only; twice this demand fails full repair. |
| P2-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P2-K10 Damage plus false recovery | Cross-witness recovery is required; Silent loss of perfusion defeats fine repair before a whole-body energy monitor necessarily detects it. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P3: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P3-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 2.78 h; preservation bound 139 h, before chemistry or aging. |
| P3-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P3-K3 Sampling | A copied XNA template does not imply a functioning catalyst system or a restored supervisor lineage. |
| P3-K4 Blueprint-informed prolonged study | The analyst may learn polymer chemistry and compartment recipes; the architecture cannot promise molecular unreadability. Solvent disruption or controller extraction is a more direct failure than defeating template cryptography. |
| P3-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P3-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: no autonomous xna physiology demonstrated. |
| P3-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P3-K8 Denied feedstock | Useful target repair matter 2.00 kg only; twice this demand fails full repair. |
| P3-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P3-K10 Damage plus false recovery | Cross-witness recovery is required; If membrane selectivity fails, compartmentalization becomes a correlated chemical transport failure. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P4: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P4-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 0.83 h; preservation bound 500 h, before chemistry or aging. |
| P4-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P4-K3 Sampling | The surface gateway can be lost without stopping local control, but global links then disappear. |
| P4-K4 Blueprint-informed prolonged study | Physical restraint, isolation from a usable fluid heat sink and reactant denial defeat operation without revealing secrets. A captor may map internal hardware through sustained access. |
| P4-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P4-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: component-specific pressure failure. |
| P4-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P4-K8 Denied feedstock | Useful target repair matter 6.00 kg only; twice this demand fails full repair. |
| P4-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P4-K10 Damage plus false recovery | Cross-witness recovery is required; A hidden pressure-sensitive component defeats pressure accommodation despite intact outer modules. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P5: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P5-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 2.08 h; preservation bound 1667 h, before chemistry or aging. |
| P5-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P5-K3 Sampling | Darkness defeats harvest even when atmosphere, temperature and network authentication remain normal. |
| P5-K4 Blueprint-informed prolonged study | A simple shadowed enclosure can end energy harvesting. A broad visible body is easy to localize; the design does not solve captivity merely by being sunlight-powered. |
| P5-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P5-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: long darkness. |
| P5-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P5-K8 Denied feedstock | Useful target repair matter 2.10 kg only; twice this demand fails full repair. |
| P5-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P5-K10 Damage plus false recovery | Cross-witness recovery is required; Loss of illuminated area turns a long-duration harvesting argument into a short battery-runtime problem. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P6: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P6-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 0.96 h; preservation bound 579 h, before chemistry or aging. |
| P6-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P6-K3 Sampling | Pre-existing geographic separation matters; hypothetical escape after total confinement is not counted. |
| P6-K4 Blueprint-informed prolonged study | Dispersal can reduce single-location loss before capture but cannot rescue nodules already sealed together. A patient captor can gather sufficient state shares or prevent reassembly. |
| P6-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P6-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: partition creates identity divergence. |
| P6-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P6-K8 Denied feedstock | Useful target repair matter 1.70 kg only; twice this demand fails full repair. |
| P6-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P6-K10 Damage plus false recovery | Cross-witness recovery is required; If dispersed components cannot ever physically reunite or communicate, aggregate resilience no longer supports one recoverable body. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P7: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P7-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 2.78 h; preservation bound 11,111 h, before chemistry or aging. |
| P7-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P7-K3 Sampling | An inactive archive cannot consent anew, detect every intervention or prove a continuing subjective experience. |
| P7-K4 Blueprint-informed prolonged study | An adversary may keep pods below wake-energy availability or collect archives. Preservation reduces expenditure, not the ability to resist physical removal. |
| P7-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P7-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: unknown integrated revival fidelity. |
| P7-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P7-K8 Denied feedstock | Useful target repair matter 1.20 kg only; twice this demand fails full repair. |
| P7-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P7-K10 Damage plus false recovery | Cross-witness recovery is required; If preserved material cannot resume verified function, the entire long-duration advantage is storage rather than survival. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |


#### P8: ten captivity cases

| Case | Outcome and limit |
| --- | --- |
| P8-K1 Atmosphere/resource confinement | Full-load heat/export-denied upper bound 5.56 h; preservation bound 6667 h, before chemistry or aging. |
| P8-K2 Communication denial | Local policy can continue while resources last; no fresh remote evidence or guaranteed outgoing delivery. |
| P8-K3 Sampling | Survival of refractory matter or a small controller does not satisfy the full cognitive-identity survival requirement. |
| P8-K4 Blueprint-informed prolonged study | A uniform-temperature enclosure can remove the heat-engine gradient. Material survival may continue while useful power and rich cognition stop. Privacy against sustained physical memory analysis is not guaranteed. |
| P8-K5 Forged ally | Intended rejection without current authorization; proof implementation and adversarial parsing are untested. |
| P8-K6 Compromised insider | Behavior checks target an authentic harmful module; shared weakness remains: ai-scale hot compute unbuilt. |
| P8-K7 Coercive maintenance/update | Refuse unconsented identity changes; service denial may still end operation, so consent is not a survival guarantee. |
| P8-K8 Denied feedstock | Useful target repair matter 7.00 kg only; twice this demand fails full repair. |
| P8-K9 Unauthorized reconstruction | Similar construction may be possible; full private-state reconstruction depends on what the captor obtains. No universal anti-copy claim. |
| P8-K10 Damage plus false recovery | Cross-witness recovery is required; If the cooler sink disappears, the thermal-energy argument fails even though the hot structure remains intact. |


| Horizon | Bounded state | Disclosure risk |
| --- | --- | --- |
| 1 minute | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 hour | Lumped energy/heat bound not yet exhausted; integrated state unknown | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 day | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 month | Normal active state infeasible in bound; preservation potentially within bound only | Uncalibrated physical study opportunity; no guaranteed secrecy |
| 1 year | Even selected preservation bound exhausted under zero heat export | Uncalibrated physical study opportunity; no guaranteed secrecy |


### Identity paradox outcomes

| Paradox | Shared policy | Prototype-specific concern |
| --- | --- | --- |
| Regeneration | Continue only while a qualified active lineage persists | P2 tissue versus core; P3 recipe versus supervisor; P1/P4/P5/P6/P8 component versus state |
| Fragmentation | Complete autonomous branches retain separately attributed histories | P6 intrinsically exposes this; all complete duplicated cores create a branch case |
| Synchronization | Share attributed claims, not compulsory personality fusion | All long-distance links may be delayed or absent |
| Restoration | Checkpoint reconstruction is labeled successor, not demonstrated original | P7 preservation and P8 cold-core loss are especially easy to overclaim |
| Compromise | Correct credentials do not prove safe behavior | Common parser and witness flaws remain across the portfolio |
| Ownership | Sample possession does not settle a conscious entity's status | All architectures distinguish recipe, hardware, private state and autonomy |


### Compound, assumption-collapse and ranked-weakness ledgers

#### P1: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P1-X1 | Heat plus radiation | Loss of all usable heat paths defeats the main survival wager even if most modules remain intact. Unknown; no coupled radiation model |
| P1-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P1-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P1-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P1-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P1-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P1-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P1-X8 | Mechanical damage plus coolant/path loss | Loss of all usable heat paths defeats the main survival wager even if most modules remain intact. Unknown; lumped model cannot validate |
| P1-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P1-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P1-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P1-A2 Compatible matter is accessible | Repair demand exceeds the useful 2.40 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P1-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P1-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P1-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P1-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P1-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P1-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P1-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P1-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | Common manufacturing defect in seals | Critical |
| 2 | Compute power requirement exceeds the budget | Critical |
| 3 | Radiator contact loss | Critical |
| 4 | All enclave locations identified | Major |
| 5 | Energy storage aging | Major |
| 6 | Joint abrasive wear | Major |
| 7 | Insufficient matched spares | Major |
| 8 | Shared manifest parser defect | Major |
| 9 | Radiation-induced correlated state errors | Major |
| 10 | Diagnostic sensor drift | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P1-FP1 resource/thermal | Removing usable heat export imposes 1.11 h normal bound; Loss of all usable heat paths defeats the main survival wager even if most modules remain intact. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P1-FP2 security/identity | An intact captor can immobilize the lattice and remove its energy supply. The architecture protects some private state against casual sampling, not against indefinitely funded invasive analysis. A separated enclave is a more serious loss than a routine structural module. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P1-FP3 compound/common-mode | A common defect or coupled boundary failure remains: Common manufacturing defect in seals; Radiator contact loss. | Add independently qualified manufacturing sources, more efficient compute hardware and replaceable thermal joints, without promising atom-by-atom self-reproduction. Proposed revision, not successfully validated. |


#### P2: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P2-X1 | Heat plus radiation | Silent loss of perfusion defeats fine repair before a whole-body energy monitor necessarily detects it. Unknown; no coupled radiation model |
| P2-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P2-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P2-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P2-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P2-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P2-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P2-X8 | Mechanical damage plus coolant/path loss | Silent loss of perfusion defeats fine repair before a whole-body energy monitor necessarily detects it. Unknown; lumped model cannot validate |
| P2-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P2-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P2-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P2-A2 Compatible matter is accessible | Repair demand exceeds the useful 3.00 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P2-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P2-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P2-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P2-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P2-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P2-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P2-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P2-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | Perfusion interruption | Critical |
| 2 | Anoxia after oxygen reserve depletion | Critical |
| 3 | Core-region damage | Critical |
| 4 | Uncontrolled biological lineage | Major |
| 5 | Waste sorbent saturation | Major |
| 6 | Nutrient-specific dependence | Major |
| 7 | Membrane contamination | Major |
| 8 | Cold damage | Major |
| 9 | Living/electronic interface drift | Major |
| 10 | External maintenance coercion | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P2-FP1 resource/thermal | Removing usable heat export imposes 2.67 h normal bound; Silent loss of perfusion defeats fine repair before a whole-body energy monitor necessarily detects it. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P2-FP2 security/identity | A captor can exploit dependence on pumps, nutrients and gas management without defeating authentication. The protection objective is privacy and recorded consent, not a promise of escape. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P2-FP3 compound/common-mode | A common defect or coupled boundary failure remains: Perfusion interruption; Core-region damage. | Reduce living volume and its basal load, improve nonliving perfusion redundancy, and establish evidence for bounded repair without loosening proliferation control. Proposed revision, not successfully validated. |


#### P3: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P3-X1 | Heat plus radiation | If membrane selectivity fails, compartmentalization becomes a correlated chemical transport failure. Unknown; no coupled radiation model |
| P3-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P3-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P3-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P3-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P3-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P3-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P3-X8 | Mechanical damage plus coolant/path loss | If membrane selectivity fails, compartmentalization becomes a correlated chemical transport failure. Unknown; lumped model cannot validate |
| P3-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P3-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P3-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P3-A2 Compatible matter is accessible | Repair demand exceeds the useful 2.00 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P3-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P3-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P3-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P3-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P3-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P3-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P3-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P3-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | No autonomous XNA physiology demonstrated | Critical |
| 2 | Membrane leakage exceeds budget | Critical |
| 3 | Catalyst supply dependency | Critical |
| 4 | Supervisor extraction | Major |
| 5 | Cross-compartment contamination | Major |
| 6 | Template copying errors | Major |
| 7 | Solvent loss | Major |
| 8 | Chemical-sensor ambiguity | Major |
| 9 | Waste precipitation | Major |
| 10 | Model/chemistry mismatch | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P3-FP1 resource/thermal | Removing usable heat export imposes 2.78 h normal bound; If membrane selectivity fails, compartmentalization becomes a correlated chemical transport failure. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P3-FP2 security/identity | The analyst may learn polymer chemistry and compartment recipes; the architecture cannot promise molecular unreadability. Solvent disruption or controller extraction is a more direct failure than defeating template cryptography. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P3-FP3 compound/common-mode | A common defect or coupled boundary failure remains: No autonomous XNA physiology demonstrated; Catalyst supply dependency. | Narrow the reaction alphabet, demonstrate bounded catalyst maintenance and replace ambitious chemical cognition with measurable supervisory roles. Proposed revision, not successfully validated. |


#### P4: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P4-X1 | Heat plus radiation | A hidden pressure-sensitive component defeats pressure accommodation despite intact outer modules. Unknown; no coupled radiation model |
| P4-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P4-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P4-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P4-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P4-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P4-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P4-X8 | Mechanical damage plus coolant/path loss | A hidden pressure-sensitive component defeats pressure accommodation despite intact outer modules. Unknown; lumped model cannot validate |
| P4-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P4-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P4-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P4-A2 Compatible matter is accessible | Repair demand exceeds the useful 6.00 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P4-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P4-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P4-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P4-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P4-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P4-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P4-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P4-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | Component-specific pressure failure | Critical |
| 2 | Reactant exhaustion | Critical |
| 3 | Exchanger fouling | Critical |
| 4 | Bridge battery not independently charged | Major |
| 5 | Loss of surfacing authority | Major |
| 6 | Acoustic interception | Major |
| 7 | Corrosion mismatch | Major |
| 8 | Seal extrusion or fatigue | Major |
| 9 | Mission-controller damage | Major |
| 10 | Hydraulic contamination | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P4-FP1 resource/thermal | Removing usable heat export imposes 0.83 h normal bound; A hidden pressure-sensitive component defeats pressure accommodation despite intact outer modules. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P4-FP2 security/identity | Physical restraint, isolation from a usable fluid heat sink and reactant denial defeat operation without revealing secrets. A captor may map internal hardware through sustained access. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P4-FP3 compound/common-mode | A common defect or coupled boundary failure remains: Component-specific pressure failure; Exchanger fouling. | Qualify more components under pressure, reduce buoy dependency and add independently serviceable thermal paths. Proposed revision, not successfully validated. |


#### P5: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P5-X1 | Heat plus radiation | Loss of illuminated area turns a long-duration harvesting argument into a short battery-runtime problem. Unknown; no coupled radiation model |
| P5-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P5-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P5-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P5-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P5-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P5-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P5-X8 | Mechanical damage plus coolant/path loss | Loss of illuminated area turns a long-duration harvesting argument into a short battery-runtime problem. Unknown; lumped model cannot validate |
| P5-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P5-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P5-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P5-A2 Compatible matter is accessible | Repair demand exceeds the useful 2.10 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P5-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P5-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P5-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P5-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P5-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P5-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P5-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P5-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | Long darkness | Critical |
| 2 | Dust obscuration | Critical |
| 3 | Edge compute damage | Critical |
| 4 | Fold hot spots | Major |
| 5 | Collector delamination | Major |
| 6 | Wind or abrasion | Major |
| 7 | Visible location | Major |
| 8 | Battery seasonal aging | Major |
| 9 | Shared optimizer defect | Major |
| 10 | Insufficient matched tile stock | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P5-FP1 resource/thermal | Removing usable heat export imposes 2.08 h normal bound; Loss of illuminated area turns a long-duration harvesting argument into a short battery-runtime problem. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P5-FP2 security/identity | A simple shadowed enclosure can end energy harvesting. A broad visible body is easy to localize; the design does not solve captivity merely by being sunlight-powered. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P5-FP3 compound/common-mode | A common defect or coupled boundary failure remains: Long darkness; Edge compute damage. | Add better low-flux workload scheduling, replaceable dust barriers and independent edge-state witnesses without assuming uninterrupted sunlight. Proposed revision, not successfully validated. |


#### P6: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P6-X1 | Heat plus radiation | If dispersed components cannot ever physically reunite or communicate, aggregate resilience no longer supports one recoverable body. Unknown; no coupled radiation model |
| P6-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P6-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P6-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P6-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P6-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P6-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P6-X8 | Mechanical damage plus coolant/path loss | If dispersed components cannot ever physically reunite or communicate, aggregate resilience no longer supports one recoverable body. Unknown; lumped model cannot validate |
| P6-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P6-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P6-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P6-A2 Compatible matter is accessible | Repair demand exceeds the useful 1.70 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P6-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P6-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P6-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P6-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P6-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P6-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P6-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P6-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | Partition creates identity divergence | Critical |
| 2 | Enough state shares captured | Critical |
| 3 | Energy stranded in unreachable nodules | Critical |
| 4 | Common firmware bug | Major |
| 5 | RF denial | Major |
| 6 | Recovery threshold never reassembled | Major |
| 7 | Small-node thermal saturation | Major |
| 8 | Location traffic analysis | Major |
| 9 | Correlated manufacturing flaw | Major |
| 10 | Locomotion cost exceeds reserve | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P6-FP1 resource/thermal | Removing usable heat export imposes 0.96 h normal bound; If dispersed components cannot ever physically reunite or communicate, aggregate resilience no longer supports one recoverable body. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P6-FP2 security/identity | Dispersal can reduce single-location loss before capture but cannot rescue nodules already sealed together. A patient captor can gather sufficient state shares or prevent reassembly. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P6-FP3 compound/common-mode | A common defect or coupled boundary failure remains: Partition creates identity divergence; Energy stranded in unreachable nodules. | Test lower-overhead branch reconciliation, diversify firmware and validate bounded recovery behavior without using uncontrolled replication. Proposed revision, not successfully validated. |


#### P7: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P7-X1 | Heat plus radiation | If preserved material cannot resume verified function, the entire long-duration advantage is storage rather than survival. Unknown; no coupled radiation model |
| P7-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P7-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P7-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P7-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P7-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P7-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P7-X8 | Mechanical damage plus coolant/path loss | If preserved material cannot resume verified function, the entire long-duration advantage is storage rather than survival. Unknown; lumped model cannot validate |
| P7-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P7-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P7-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P7-A2 Compatible matter is accessible | Repair demand exceeds the useful 1.20 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P7-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P7-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P7-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P7-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P7-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P7-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P7-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P7-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | Unknown integrated revival fidelity | Critical |
| 2 | Dormancy blind interval | Critical |
| 3 | Archive common-mode damage | Critical |
| 4 | Humidity ingress | Major |
| 5 | Wake energy unavailable | Major |
| 6 | Glass transition unknown | Major |
| 7 | Active seed destroyed | Major |
| 8 | Readback detects but cannot repair loss | Major |
| 9 | Unauthorized archive copy | Major |
| 10 | Dormancy mistaken for ongoing identity | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P7-FP1 resource/thermal | Removing usable heat export imposes 2.78 h normal bound; If preserved material cannot resume verified function, the entire long-duration advantage is storage rather than survival. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P7-FP2 security/identity | An adversary may keep pods below wake-energy availability or collect archives. Preservation reduces expenditure, not the ability to resist physical removal. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P7-FP3 compound/common-mode | A common defect or coupled boundary failure remains: Unknown integrated revival fidelity; Archive common-mode damage. | Measure archive retention and wake reliability before adding living components; reduce blind intervals without pretending they vanish. Proposed revision, not successfully validated. |


#### P8: compound failure map

| Record | Combination | First limiter / conclusion |
| --- | --- | --- |
| P8-X1 | Heat plus radiation | If the cooler sink disappears, the thermal-energy argument fails even though the hot structure remains intact. Unknown; no coupled radiation model |
| P8-X2 | Oxygen denial plus link loss | Local reactants and offline policy P2 finite reactants; others retain only their own power constraints |
| P8-X3 | Energy denial plus thermal concealment | Finite E and thermal buffer Finite bound; full operation eventually fails |
| P8-X4 | Fragmentation plus malicious replacement | State provenance and behavior checks Unknown security implementation |
| P8-X5 | Memory corruption plus network partition | Local lineage and branch policy Unknown; may require successor or branch labeling |
| P8-X6 | Repair demand exceeds accessible mass | Compatible material Fail for full autonomous repair |
| P8-X7 | Hot ambient plus false cool sensor | Independent thermal witness Unknown common-mode sensor credibility |
| P8-X8 | Mechanical damage plus coolant/path loss | If the cooler sink disappears, the thermal-energy argument fails even though the hot structure remains intact. Unknown; lumped model cannot validate |
| P8-X9 | Trusted update plus energy scarcity | Local consent and worst-case resource check Unknown implementation; refuse or reduce work |
| P8-X10 | Long blackout plus archive/part aging | Time, retention and compatible spares Finite survival; no indefinite archive guarantee |


| Assumption | Collapse symptom | What remains |
| --- | --- | --- |
| P8-A1 Environment remains predictable | Measured boundary conditions leave the admitted mission envelope. | Reduce tasks; no unmeasured environmental immunity. |
| P8-A2 Compatible matter is accessible | Repair demand exceeds the useful 7.00 kg stock or needs a missing specialized part. | Preserve intact state; regrowth is unavailable without matter. |
| P8-A3 Heat sink remains usable | Core temperature rises despite a cooling command because actual heat export is inadequate. | Only finite buffering and reduced power remain. |
| P8-A4 Sensors remain reliable | Independent channels disagree or plausible but correlated sensor errors escape the witness. | Conservative degraded mode; correlated errors may remain undetected. |
| P8-A5 Time and epochs remain consistent | Local epoch histories conflict; message age and ordering cannot be established globally. | Local preservation authority survives; global freshness is unresolved. |
| P8-A6 Authentication implies safe behavior | A correctly authenticated component violates its admitted behavior or resource envelope. | Quarantine suspicious authority; valid signatures may persist. |
| P8-A7 Private state remains readable | State readback is inconsistent, corrupted or no longer physically readable. | A successor may be reconstructed; original continuity is not proved. |
| P8-A8 Repair restores original competence | Postrepair load or integrity checks do not reproduce the pre-damage competence. | Keep repaired region restricted; false negatives can strand recovery. |
| P8-A9 Interfaces remain chemically/mechanically stable | Contact, membrane, seal or transport behavior drifts outside its admitted model. | Use surviving paths; common interface loss can end operation. |
| P8-A10 Infrastructure returns in time | External support remains unavailable beyond the declared finite reserve horizon. | Local autonomy continues only within finite reserves. |


| Rank | Weakness | Severity |
| --- | --- | --- |
| 1 | AI-scale hot compute unbuilt | Critical |
| 2 | High-temperature reserve unresolved | Critical |
| 3 | Gradient disappears | Critical |
| 4 | Cold core warms beyond limit | Major |
| 5 | Memory density and retention | Major |
| 6 | Contact creep | Major |
| 7 | Corrosive trace chemistry | Major |
| 8 | Thermal-cycle cracking | Major |
| 9 | Slow hot-layer communication | Major |
| 10 | Precision replacement dependency | Major |


| Failure path | Counterexample | Revision / retest |
| --- | --- | --- |
| P8-FP1 resource/thermal | Removing usable heat export imposes 5.56 h normal bound; If the cooler sink disappears, the thermal-energy argument fails even though the hot structure remains intact. | Make load and heat-sink requirements explicit; preserve finite staged reductions. Analytical finite limit reproduced; physical integrated retest not performed. |
| P8-FP2 security/identity | A uniform-temperature enclosure can remove the heat-engine gradient. Material survival may continue while useful power and rich cognition stop. Privacy against sustained physical memory analysis is not guaranteed. | Separate possession, recipe, authorization and private lineage; retain conscious branch rights. Conceptual counterexample only; implementation security and subjective continuity unvalidated. |
| P8-FP3 compound/common-mode | A common defect or coupled boundary failure remains: AI-scale hot compute unbuilt; Gradient disappears. | Increase high-temperature memory and useful control complexity while explicitly retaining the gap to full AI identity capacity. Proposed revision, not successfully validated. |


### Communications and offline dependencies

Propagation uses c = 299,792,458 m/s ([NIST speed of light](https://physics.nist.gov/cgi-bin/cuu/Value?c)). Distances, power and bitrate ranges below are explicit target assumptions; no antenna/aperture, channel-noise or pointing calculation validates those rates.

| Case / assumed distance | Ideal one-way delay | Medium / targets | Required infrastructure |
| --- | --- | --- | --- |
| local; 1 m | 3.33564e-09 s | wired/short optical; 0.01–2 W target; 1 kb/s–10 Mb/s target | compatible coupler |
| planetary reference; 1e+07 m | 0.0333564 s | RF or optical routed relay; 1–50 W endpoint target; 1 kb/s–1 Mb/s target | line of sight or relays; rate not link-budget validated |
| interplanetary reference; 1.5e+11 m | 500.346 s | directional RF/optical gateway; 10–100 W gateway target; 10 b/s–100 kb/s target | pointing, aperture, gateway and route schedule unspecified |


| Prototype | Local link | Planetary/deep dependency |
| --- | --- | --- |
| P1 | Local wired/optical couplings; nearby radio; an optional orbital or deep-space gateway supplies the shared delay-tolerant interface. The gateway is not a life-support component. | Qualified gateway; no guaranteed route or continuous service |
| P2 | Electrical local sensing, short optical connections between service regions, and a protected radio interface; deep-space participation needs a dry external gateway. | Qualified gateway; no guaranteed route or continuous service |
| P3 | Ionic/electrical local links feed an electronic boundary transducer; external radio/optical networking is gateway-mediated. | Qualified gateway; no guaranteed route or continuous service |
| P4 | Local wired links and short optical water links; longer acoustic messaging to a surface buoy; the buoy provides planetary/orbital or deep-space radio. Surfacing and a buoy are infrastructure options, not assumed always available. | Qualified gateway; no guaranteed route or continuous service |
| P5 | Short optical tile links, nearby radio and a deployable directional gateway; high-rate external communication is scheduled from energy surplus. | Qualified gateway; no guaranteed route or continuous service |
| P6 | Opportunistic RF/optical local networking, delayed contact routing and occasional directional gateway contact; no continuous global consensus is required for basic local control. | Qualified gateway; no guaranteed route or continuous service |
| P7 | Wake-window short optical or wired contact; burst radio to a nearby gateway; interplanetary messaging is delayed by both propagation and scheduled inactivity. | Qualified gateway; no guaranteed route or continuous service |
| P8 | Conductive local links and high-temperature-rated low-rate radio feed a separately qualified cooler gateway for high-bandwidth or deep-space service. | Qualified gateway; no guaranteed route or continuous service |


An opaque planet, deep water, terrain or a shielded enclosure can remove the direct channel. Store-and-forward does not allow transmission through an absent path, and a four-year-distance example cannot offer a faster-than-propagation reply without a separately specified nonphysical extension.

### Model abstraction and evidence maturity

| Prototype | Physical units target | Effective units target | Raw 32-float state MB / 1 s steps per day |
| --- | --- | --- | --- |
| P1 | 10,000 | 1,000 | 0.256 MB; 86,400,000 unit-steps |
| P2 | 1,000,000 | 10,000 | 2.56 MB; 864,000,000 unit-steps |
| P3 | 100,000,000 | 100,000 | 25.6 MB; 8,640,000,000 unit-steps |
| P4 | 20,000 | 2,000 | 0.512 MB; 172,800,000 unit-steps |
| P5 | 3,000 | 3,000 | 0.768 MB; 259,200,000 unit-steps |
| P6 | 500 | 500 | 0.128 MB; 43,200,000 unit-steps |
| P7 | 2,000 | 2,000 | 0.512 MB; 172,800,000 unit-steps |
| P8 | 10,000 | 1,000 | 0.256 MB; 86,400,000 unit-steps |


Assuming 1,000 arithmetic operations per unit-step yields the corresponding operations by multiplying the final column by 1,000; memory bandwidth, graph changes, chemistry solves and security logs can dominate. No wall-clock time or hardware credit estimate is inferred.

| Prototype | Evidence class | Executed support | Largest evidence gap |
| --- | --- | --- | --- |
| P1 | Engineering extrapolation | 0D resource/heat accounting only | Physical components are established individually; integrated autonomy and identity-preserving repair are extrapolated; full embodied AI capability is unknown. |
| P2 | Engineering extrapolation | 0D resource/heat accounting only | Cell maintenance and telomere biology have evidence; autonomous biohybrid body-wide repair is extrapolated or speculative and is not demonstrated here. |
| P3 | Speculative | 0D resource/heat accounting only | XNA information storage is supported in limited systems; autonomous XNA repair and whole-body integration remain speculative. |
| P4 | Engineering extrapolation | 0D resource/heat accounting only | Underwater robotics and fuel cells are established; the pressure-balanced autonomous physiology and repair system are extrapolated. |
| P5 | Engineering extrapolation | 0D resource/heat accounting only | Photovoltaics are established; autonomous self-repairing embodied tile cognition is extrapolated and full identity capacity is unknown. |
| P6 | Engineering extrapolation | 0D resource/heat accounting only | Distributed storage and robotics have evidence; distributed personal continuity and autonomous body reconstitution remain unknown or speculative. |
| P7 | Speculative | 0D resource/heat accounting only | Specific dry-state protective mechanisms have evidence; whole-body dormant revival and personal continuity remain speculative or unknown. |
| P8 | Speculative | 0D resource/heat accounting only | Selected simple high-temperature SiC circuits are established; integrated AI-bearing hot physiology and its reserve storage are speculative. |


| Ledger | New records | Meaning |
| --- | --- | --- |
| empirical_component_tests | 0 | No implication of physical or canon survival |
| integrated_tests | 0 | No implication of physical or canon survival |
| survival_incidents | 0 | No implication of physical or canon survival |
| canonical_events_added | 0 | No implication of physical or canon survival |
| analytical_families | 8 | No implication of physical or canon survival |
| ode_step_checks | 24 | No implication of physical or canon survival |
| stress_grid_rows | 648 | No implication of physical or canon survival |


### Source and contradiction registers

| Project document | Role | Authority / unresolved issue |
| --- | --- | --- |
| Perplexity v2 DOCX | Executed REQ-01–26 prompt | Local independent proposal, not controlling canon |
| Copilot v2 DOCX | Companion review | Independent peer contribution; not merged into authority |
| Claude v2 PDF | Companion critique | Stage pauses adapted to current execution authorization |
| Architecture v2 PDF | Companion requirements | No guessed contributor identity |
| Round-one prompt archive PDF | Provenance | Prompts, not completed prototype dossiers |
| Architecture notes | Original scale ambition | Survey representativeness is not physiological validation |
| 15-year roadmap | Multiscale research aspirations | Budgets and milestones are not achieved resources |
| Wattpad vision | Narrative setting | Not empirical event history |
| 4,712 framework v1 draft | Threat names and event proposals | Locked-count/approval conflict; simulation inclusion conflict |
| Missing Paragon addendum/event log | Unprovided dependency | No physical or logging credit assigned |


The proposed category allocation ranges total 2,600–4,450, midpoint 3,525; even the upper sum is 262 below 4,712. This is arithmetic on the framework's proposed ranges, not evidence about an actual historical ledger.

| External ID | Reference and scope |
| --- | --- |
| E01 | [NHGRI genetics glossary](http://www.genome.gov/genetics-glossary). Hereditary vocabulary; not an alternative-genome design |
| E02 | [MRC LMB XNA research](https://www2.mrc-lmb.cam.ac.uk/groups/ph1/xna.html). Limited XNA information experiments, not autonomous organisms |
| E03 | [Telomeres review, Cell](https://pmc.ncbi.nlm.nih.gov/articles/PMC8081271/). Chromosome-end integrity and aging/cancer context, not immortality |
| E04 | [DOE fuel cells](https://www.energy.gov/cmei/fuels/fuel-cells). Fuel, oxidant, electricity, water and heat; no assumed body efficiency |
| E05 | [NASA thermal-control guidance](https://www.nasa.gov/wp-content/uploads/2026/05/7-soa-thermal-2026-final.pdf?emrc=6ae1e775de967). Thermal boundaries and finite storage/heat rejection |
| E06 | [NASA DTN](https://www.nasa.gov/communicating-with-missions/delay-disruption-tolerant-networking/). Delay/disruption-tolerant store-and-forward, not guaranteed paths |
| E07 | [NIST zero trust](https://csrc.nist.gov/pubs/sp/800/207/final). Digital authentication/authorization context, not molecular concealment |
| E08 | [JCVI minimal-cell model](https://www.jcvi.org/media-center/scientists-develop-most-complete-whole-cell-computer-simulation-model-cell-date). Single minimized-cell model, not omnicellular body simulation |
| E09 | [NASA high-temperature circuits](https://science.nasa.gov/science-research/science-enabling-technology/technology-highlights/integrated-circuits-to-enable-exploration-of-the-harshest-environments-in-solar-system/). Specific simple hot circuits, not dense AI cognition |
| E10 | [Tardigrade dry-state proteins](https://pmc.ncbi.nlm.nih.gov/articles/PMC5987194/). Specific desiccation-protection evidence, not whole-body cognition or arbitrary revival |
| E11 | [Autonomous self-healing review](https://pmc.ncbi.nlm.nih.gov/articles/PMC12370171/). Healing loops and integration limits, not universal repair |
| E12 | [NASA radiation-effects compendium](https://ntrs.nasa.gov/citations/20140017803). Distinct electronics radiation failure modes, not a whole-body rating |
| E13 | [FDA computational-model credibility](https://www.fda.gov/regulatory-information/search-fda-guidance-documents/assessing-credibility-computational-modeling-and-simulation-medical-device-submissions). Risk-informed first-principles-model context, not certification |
| E14 | [NIST Stefan–Boltzmann constant](https://physics.nist.gov/cgi-bin/cuu/Value?sigma). Constant used in illustrative radiator calculation |
| E15 | [NIST speed of light](https://physics.nist.gov/cgi-bin/cuu/Value?c). Vacuum propagation constant; no complete link budget |


### Requirement coverage and research gates

| REQ | Coverage location / result |
| --- | --- |
| 01 | Eight Generation 1 dossiers; hypothetical, bounded embodiment |
| 02 | Wagers, fingerprints, hash and all 28 comparisons |
| 03 | Documentary audit; authority and contradiction register |
| 04 | Two-axis evidence system; claims.json and rule register |
| 05 | Omni-I/L/S definition and collective dependencies |
| 06 | Four families; 3 OBS, 3 SEC, 3 departures per prototype |
| 07 | Power budgets, reactants and finite reserve bounds |
| 08 | Telomere applicability, component age and conditional service targets |
| 09 | Consistent total/thermal equations and finite heat buffer |
| 10 | Matter, charge, redox and repair-yield ledger |
| 11 | Outward, inward and observed channels in 24 rules |
| 12 | 24 security rules; blueprint-known limits and offline recovery |
| 13 | 24 explicit departures; DNA retained/replaced; kept constraints |
| 14 | Unvalidated nonzero transition latencies and overlap reserve |
| 15 | B1 inputs and 320 status/recovery records, no integrated Pass |
| 16 | Argon A/B/C; pressure not confused with vacuum |
| 17 | 80 captivity cases and 40 capture-horizon records |
| 18 | Six identity paradoxes per dossier plus shared comparison |
| 19 | Local/planetary/interplanetary interface, path and infrastructure limits |
| 20 | 80 compound and 80 assumption-collapse records |
| 21 | Self-review disclosed; 24 failure paths and six substantive limitations |
| 22 | Executed 0D bounds; proposed resolved models and compute assumptions |
| 23 | Validation ladder; distinct zero empirical/incident/canon additions |
| 24 | Common dossiers; conditional primary/reserve/wildcard, none qualified |
| 25 | Audit through comparison executed; matched PDF/DOCX and visual appendix |
| 26 | Programmatic counts, boundary statement, no qualification overclaim |


| Gate | Evidence needed | Stop/reject condition |
| --- | --- | --- |
| A | Architect decisions and source approval | Authority or survival definition unresolved |
| B | Independent code, units and citation review | Undetected double counting or fabricated evidence |
| C | P1 resolved thermal/power network | Essential local state cannot survive one specified boundary failure |
| D | Relevant nonliving component evidence | Measured behavior contradicts model margins |
| E | Family-specific falsification records | Central mechanism fails in its own narrow context |
| F | Bounded integrated inert demonstration | Recovery or autonomy depends on hidden outside action |
| G | Independent ethical/legal review where needed | Consent, sentience or irreversible loss unresolved |


End of execution v1.0. The supporting code preserves enough structure for another contributor to disagree with a named assumption, rather than accept or reject the whole project as one undifferentiated claim.
